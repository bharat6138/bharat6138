# AURA Agent V1

Application Unified Runtime Analyzer — **Intelligent Application Health Inspector**.

See [PROJECT_GUIDE.md](PROJECT_GUIDE.md) for architecture and packaging, and [AURA_SECURITY_DASHBOARD.md](AURA_SECURITY_DASHBOARD.md) for the detailed security, technology, package, CDN, and script dashboard.
