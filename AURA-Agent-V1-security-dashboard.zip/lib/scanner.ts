import path from 'node:path';
import type { Browser } from 'playwright';
import type { AssetInventory, Finding, PageResult, ScanReport, ScriptAsset, SecurityCheck, SecurityPageDetail, SecurityReport, TlsDetail } from './types';

const MAX_PAGES = 15;
const TIMEOUT = 20000;
const MAX_ASSETS = 150;

type PageAssets = {
  scripts: { url: string; type: string; async: boolean; defer: boolean; integrity: boolean }[];
  inlineScripts: number;
  stylesheets: string[];
  resources: { url: string; kind: string }[];
  insecureForms: string[];
  passwordFields: number;
  runtimePackages: { name: string; version?: string; evidence: string }[];
  generator: string;
  markers: string[];
};

type SecurityObservation = SecurityPageDetail & {
  tls?: TlsDetail;
  exposedHeaders: string[];
  passwordFields: number;
  cookies: { key: string; secure: boolean; httpOnly: boolean; sameSite: boolean }[];
};

const CDN_PROVIDERS: [RegExp, string][] = [
  [/(^|\.)cdn\.jsdelivr\.net$/, 'jsDelivr'], [/(^|\.)unpkg\.com$/, 'UNPKG'],
  [/(^|\.)cdnjs\.cloudflare\.com$/, 'cdnjs / Cloudflare'], [/(^|\.)static\.cloudflareinsights\.com$/, 'Cloudflare Insights'],
  [/(^|\.)ajax\.googleapis\.com$/, 'Google Hosted Libraries'], [/(^|\.)(fonts\.googleapis\.com|fonts\.gstatic\.com)$/, 'Google Fonts'],
  [/(^|\.)cdn\.tailwindcss\.com$/, 'Tailwind CDN'], [/(^|\.)cdn\.shopify\.com$/, 'Shopify CDN'],
  [/(^|\.)res\.cloudinary\.com$/, 'Cloudinary'], [/(^|\.)esm\.sh$/, 'esm.sh'],
  [/(^|\.)skypack\.dev$/, 'Skypack'], [/(^|\.)jspm\.io$/, 'JSPM'],
  [/\.cloudfront\.net$/, 'Amazon CloudFront'], [/\.akamaized\.net$/, 'Akamai'], [/\.fastly\.net$/, 'Fastly']
];

export function normalizeTarget(input: string) {
  const value = input.trim();
  const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Only HTTP and HTTPS URLs are supported.');
  url.hash = '';
  return url;
}
export async function scanApplication(input: string): Promise<ScanReport> {
  const target = normalizeTarget(input); const started = Date.now(); const findings: Finding[] = []; const pages: PageResult[] = [];
  const technologies = new Map<string, Set<string>>();
  const packages = new Map<string, { name: string; version?: string; evidence: Set<string> }>();
  const cdns = new Map<string, { hosts: Set<string>; resources: Set<string> }>();
  const scripts = new Map<string, ScriptAsset & { pages: string[] }>();
  const stylesheets = new Map<string, { url: string; pages: string[] }>();
  const externalHosts = new Set<string>();
  const securityObservations: SecurityObservation[] = [];
  let inlineScripts = 0;
  let browser: Browser | undefined;
  try {
    // The install script keeps Chromium inside node_modules so electron-builder can
    // bundle it. Packaged Electron sets its own resource path before starting the
    // server; local Next.js runs need to point Playwright at that same local cache.
    process.env.PLAYWRIGHT_BROWSERS_PATH ??= path.join(process.cwd(), 'node_modules', 'playwright-core', '.local-browsers');
    const { chromium } = await import('playwright');
    browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({ ignoreHTTPSErrors: false, userAgent: 'AURA-Agent-V1/1.0' });
    const queue = [target.href]; const seen = new Set<string>();
    while (queue.length && pages.length < MAX_PAGES) {
      const url = queue.shift()!; if (seen.has(url)) continue; seen.add(url);
      const page = await context.newPage(); const consoleErrors: string[] = [];
      page.on('console', m => { if (m.type() === 'error' && consoleErrors.length < 10) consoleErrors.push(m.text()); });
      const began = Date.now(); let status: number | null = null; let title = ''; let links: string[] = [];
      try {
        const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: TIMEOUT }); status = response?.status() ?? null;
        title = await page.title();
        links = await page.locator('a[href]').evaluateAll((els) => els.map(a => (a as HTMLAnchorElement).href));
        const h1 = await page.locator('h1').count(); const descriptionTag = page.locator('meta[name="description"]').first();
        const description = await descriptionTag.count() ? await descriptionTag.getAttribute('content') : null;
        const imagesMissingAlt = await page.locator('img:not([alt]), img[alt=""]').count();
        const assets = await page.evaluate<PageAssets>(() => {
          const scripts = Array.from(document.scripts).filter(s => s.src).map(s => ({
            url: s.src, type: s.type || 'classic', async: s.async, defer: s.defer, integrity: Boolean(s.integrity)
          }));
          const stylesheets = Array.from(document.querySelectorAll<HTMLLinkElement>('link[rel~="stylesheet"][href]')).map(l => l.href);
          const resources = performance.getEntriesByType('resource').map(entry => {
            const resource = entry as PerformanceResourceTiming;
            return { url: resource.name, kind: resource.initiatorType || 'other' };
          });
          const markers: string[] = [];
          const runtimePackages: { name: string; version?: string; evidence: string }[] = [];
          const runtime = window as typeof window & { jQuery?: { fn?: { jquery?: string } }; Vue?: { version?: string }; React?: { version?: string } };
          if (document.querySelector('#__next') || document.querySelector('script[src*="/_next/"]')) markers.push('Next.js', 'React');
          if (document.querySelector('#__nuxt') || document.querySelector('script[src*="/_nuxt/"]')) markers.push('Nuxt', 'Vue.js');
          const angularRoot = document.querySelector('[ng-version]');
          if (angularRoot) { markers.push('Angular'); runtimePackages.push({ name: '@angular/core', version: angularRoot.getAttribute('ng-version') ?? undefined, evidence: 'ng-version attribute' }); }
          if (document.querySelector('[data-svelte-h]')) markers.push('Svelte');
          if (document.querySelector('astro-island, astro-slot')) markers.push('Astro');
          if (document.querySelector('script[src*="wp-content"], link[href*="wp-content"]')) markers.push('WordPress');
          if ('Shopify' in window || document.querySelector('script[src*="cdn.shopify.com"]')) markers.push('Shopify');
          if (runtime.jQuery) { markers.push('jQuery'); runtimePackages.push({ name: 'jquery', version: runtime.jQuery.fn?.jquery, evidence: 'window.jQuery.fn.jquery' }); }
          if (runtime.Vue?.version) runtimePackages.push({ name: 'vue', version: runtime.Vue.version, evidence: 'window.Vue.version' });
          if (runtime.React?.version) runtimePackages.push({ name: 'react', version: runtime.React.version, evidence: 'window.React.version' });
          return {
            scripts,
            inlineScripts: Array.from(document.scripts).filter(s => !s.src).length,
            stylesheets,
            resources,
            insecureForms: Array.from(document.forms).map(f => f.action || location.href).filter(action => action.startsWith('http:')),
            passwordFields: document.querySelectorAll('input[type="password"]').length,
            runtimePackages,
            generator: document.querySelector<HTMLMetaElement>('meta[name="generator"]')?.content || '',
            markers
          };
        });
        inlineScripts += assets.inlineScripts;
        collectAssets(url, target.hostname, assets, { technologies, packages, cdns, scripts, stylesheets, externalHosts });
        const responseHeaders = response ? await response.allHeaders() : {};
        const tlsRaw = await response?.securityDetails();
        const cookies = await context.cookies([url]);
        const pageProtocol = new URL(url).protocol;
        const mixedContent = pageProtocol === 'https:' ? [...new Set([...assets.scripts.map(x => x.url), ...assets.stylesheets, ...assets.resources.map(x => x.url)].filter(x => x.startsWith('http:')))].slice(0, 20) : [];
        const thirdPartyScriptsWithoutIntegrity = assets.scripts.filter(s => { try { return new URL(s.url).hostname !== new URL(url).hostname && !s.integrity; } catch { return false; } }).map(s => s.url).slice(0, 20);
        const securityHeaders = ['content-security-policy','strict-transport-security','x-content-type-options','referrer-policy','permissions-policy','x-frame-options','cross-origin-opener-policy','cross-origin-resource-policy'];
        const selectedHeaders = Object.fromEntries(securityHeaders.filter(name => responseHeaders[name]).map(name => [name, responseHeaders[name]]));
        securityObservations.push({
          url, https: pageProtocol === 'https:', headers: selectedHeaders,
          cookieTotal: cookies.length, insecureCookies: cookies.filter(x => !x.secure).length,
          cookiesWithoutHttpOnly: cookies.filter(x => !x.httpOnly).length,
          mixedContent, insecureForms: assets.insecureForms,
          thirdPartyScriptsWithoutIntegrity,
          passwordFields: assets.passwordFields,
          exposedHeaders: ['server','x-powered-by'].filter(name => responseHeaders[name]).map(name => `${name}: ${responseHeaders[name]}`),
          cookies: cookies.map(x => ({ key: `${x.name}|${x.domain}|${x.path}`, secure: x.secure, httpOnly: x.httpOnly, sameSite: Boolean(x.sameSite) })),
          tls: pageProtocol === 'https:' && tlsRaw?.protocol ? { url, protocol: tlsRaw.protocol, issuer: tlsRaw.issuer ?? 'Unknown', subjectName: tlsRaw.subjectName ?? new URL(url).hostname, validFrom: tlsRaw.validFrom ?? 0, validTo: tlsRaw.validTo ?? 0 } : undefined
        });
        if (!title.trim()) findings.push(f('warning','SEO','Missing page title',`No title was found on ${url}.`,url,'Add a concise, unique document title.'));
        if (!description?.trim()) findings.push(f('info','SEO','Missing meta description',`No meta description was found on ${url}.`,url,'Add a useful summary for search and link previews.'));
        if (h1 === 0) findings.push(f('warning','Structure','Missing H1',`The page has no primary heading.`,url,'Add one clear H1 describing the page.'));
        if (imagesMissingAlt) findings.push(f('warning','Accessibility','Images missing alt text',`${imagesMissingAlt} image(s) have no useful alt attribute.`,url,'Add meaningful alt text; use empty alt only for decorative images.'));
        if ((status ?? 0) >= 400) findings.push(f('critical','Availability',`HTTP ${status}`,`The page returned an error status.`,url,'Fix the route or redirect users to a working page.'));
        const loadMs = Date.now() - began; if (loadMs > 4000) findings.push(f('warning','Performance','Slow initial load',`DOM content loaded in ${(loadMs/1000).toFixed(1)} seconds.`,url,'Profile server response and critical resources.'));
        if (consoleErrors.length) findings.push(f('warning','Runtime','Browser console errors',`${consoleErrors.length} console error(s) appeared while loading.`,url,'Review the page details and resolve runtime errors.'));
        const pageHosts = uniqueHosts([...assets.scripts.map(x => x.url), ...assets.stylesheets, ...assets.resources.map(x => x.url)], target.hostname);
        pages.push({ url, title: title || '(untitled)', status, loadMs, linksFound: links.length, scriptsFound: assets.scripts.length + assets.inlineScripts, stylesheetsFound: assets.stylesheets.length, externalHosts: pageHosts, consoleErrors });
        for (const raw of links) { try { const link = new URL(raw); link.hash=''; if (link.origin === target.origin && !seen.has(link.href) && queue.length < MAX_PAGES * 3) queue.push(link.href); } catch {} }
      } catch (error) {
        findings.push(f('critical','Availability','Page could not be loaded',error instanceof Error ? error.message : 'Unknown navigation error',url,'Confirm the URL, network access, TLS certificate, and server availability.'));
        pages.push({ url, title: '(unavailable)', status, loadMs: Date.now()-began, linksFound: 0, scriptsFound: 0, stylesheetsFound: 0, externalHosts: [], consoleErrors });
      } finally { await page.close(); }
    }
    await context.close();
  } finally { await browser?.close(); }
  const critical = findings.filter(x=>x.severity==='critical').length, warnings = findings.filter(x=>x.severity==='warning').length;
  const score = Math.max(0, Math.min(100, 100 - critical*20 - warnings*6 - findings.filter(x=>x.severity==='info').length*2));
  if (!findings.length) findings.push(f('passed','Overview','No common issues detected','AURA completed its V1 checks without identifying an issue.',target.href,'Continue deeper functional, security, and accessibility testing.'));
  const inventory = buildInventory(technologies, packages, cdns, scripts, stylesheets, externalHosts, inlineScripts);
  const security = buildSecurityReport(securityObservations);
  const finished=Date.now(); return { target:target.href, startedAt:new Date(started).toISOString(), finishedAt:new Date(finished).toISOString(), durationMs:finished-started, score, summary:{pages:pages.length, passed:Math.max(0,pages.length-critical-warnings),warnings,critical}, findings, inventory, security, pages, limitations:['V1 inspects public pages reachable without authentication.','Technology and package detection uses client-visible runtime evidence; bundled or server-only dependencies may not expose names or versions.','Security checks cover browser-visible transport, headers, cookies, forms, mixed content, and script integrity signals; they are not a penetration test or CVE proof.','Results are heuristic and do not replace security, accessibility, load, or compliance audits.','Client-rendered links are followed only when present after DOMContentLoaded.'] };
}
function f(severity: Finding['severity'],category:string,title:string,detail:string,url:string,recommendation:string):Finding { return {severity,category,title,detail,url,recommendation}; }

type Collections = {
  technologies: Map<string, Set<string>>;
  packages: Map<string, { name: string; version?: string; evidence: Set<string> }>;
  cdns: Map<string, { hosts: Set<string>; resources: Set<string> }>;
  scripts: Map<string, ScriptAsset & { pages: string[] }>;
  stylesheets: Map<string, { url: string; pages: string[] }>;
  externalHosts: Set<string>;
};

function collectAssets(pageUrl: string, firstPartyHost: string, assets: PageAssets, c: Collections) {
  const resourceUrls = new Set([...assets.scripts.map(x => x.url), ...assets.stylesheets, ...assets.resources.map(x => x.url)]);
  for (const marker of assets.markers) addEvidence(c.technologies, marker, 'Page runtime marker');
  if (assets.generator) addEvidence(c.technologies, assets.generator, 'meta[name="generator"]');
  for (const detected of assets.runtimePackages) {
    const key = `${detected.name}@${detected.version ?? ''}`;
    const entry = c.packages.get(key) ?? { name: detected.name, version: detected.version, evidence: new Set<string>() };
    entry.evidence.add(detected.evidence); c.packages.set(key, entry);
  }

  for (const item of assets.scripts) {
    const existing = c.scripts.get(item.url);
    if (existing) { if (!existing.pages.includes(pageUrl)) existing.pages.push(pageUrl); }
    else if (c.scripts.size < MAX_ASSETS) {
      let thirdParty = false; try { thirdParty = new URL(item.url).hostname !== firstPartyHost; } catch {}
      c.scripts.set(item.url, { ...item, thirdParty, pages: [pageUrl] });
    }
  }
  for (const url of assets.stylesheets) {
    const existing = c.stylesheets.get(url);
    if (existing) { if (!existing.pages.includes(pageUrl)) existing.pages.push(pageUrl); }
    else if (c.stylesheets.size < MAX_ASSETS) c.stylesheets.set(url, { url, pages: [pageUrl] });
  }

  for (const raw of resourceUrls) {
    let parsed: URL;
    try { parsed = new URL(raw); } catch { continue; }
    if (parsed.hostname !== firstPartyHost) c.externalHosts.add(parsed.hostname);
    const cdn = CDN_PROVIDERS.find(([pattern]) => pattern.test(parsed.hostname));
    if (cdn) {
      const entry = c.cdns.get(cdn[1]) ?? { hosts: new Set<string>(), resources: new Set<string>() };
      entry.hosts.add(parsed.hostname); entry.resources.add(parsed.href); c.cdns.set(cdn[1], entry);
    }
    const detectedPackage = packageFromUrl(parsed);
    if (detectedPackage) {
      const key = `${detectedPackage.name}@${detectedPackage.version ?? ''}`;
      const entry = c.packages.get(key) ?? { ...detectedPackage, evidence: new Set<string>() };
      if (entry.evidence.size < 3) entry.evidence.add(parsed.href); c.packages.set(key, entry);
    }
    detectTechnologyFromUrl(parsed.href, c.technologies);
  }
}

function packageFromUrl(url: URL): { name: string; version?: string } | undefined {
  const host = url.hostname.replace(/^www\./, '');
  let parts = url.pathname.split('/').filter(Boolean);
  if (host === 'cdn.jsdelivr.net') { const npmIndex = parts.indexOf('npm'); if (npmIndex < 0) return; parts = parts.slice(npmIndex + 1); }
  else if (host === 'unpkg.com') { /* package starts at the first segment */ }
  else if (host === 'cdnjs.cloudflare.com' && parts[0] === 'ajax' && parts[1] === 'libs' && parts[2]) return { name: parts[2], version: parts[3] };
  else if (host === 'ajax.googleapis.com' && parts[0] === 'ajax' && parts[1] === 'libs' && parts[2]) return { name: parts[2], version: parts[3] };
  else if (host === 'esm.sh') { if (/^v\d+$/.test(parts[0] ?? '')) parts = parts.slice(1); }
  else if (host.endsWith('skypack.dev')) { parts = parts.filter(x => !x.startsWith('-')); }
  else if (host === 'jspm.io') { const npmIndex = parts.indexOf('npm:'); if (npmIndex >= 0) parts = parts.slice(npmIndex + 1); }
  else return packageFromCommonFilename(url.pathname);
  if (!parts.length) return;
  if (parts[0].startsWith('@') && parts[1]) {
    const split = splitPackageVersion(parts[1]); return { name: `${parts[0]}/${split.name}`, version: split.version };
  }
  return splitPackageVersion(parts[0]);
}

function splitPackageVersion(value: string) {
  const index = value.lastIndexOf('@');
  return index > 0 ? { name: value.slice(0, index), version: value.slice(index + 1) || undefined } : { name: value };
}

function packageFromCommonFilename(pathname: string) {
  const filename = pathname.split('/').pop() ?? '';
  const known: [RegExp, string][] = [
    [/^jquery(?:[-.]\d[^.]*)?(?:\.min)?\.js/i, 'jquery'], [/^bootstrap(?:\.bundle)?(?:\.min)?\.(?:js|css)/i, 'bootstrap'],
    [/^react(?:-dom)?(?:\.production\.min|\.development)?\.js/i, 'react'], [/^vue(?:\.global|\.runtime)?(?:\.prod)?\.js/i, 'vue'],
    [/^axios(?:\.min)?\.js/i, 'axios'], [/^lodash(?:\.min)?\.js/i, 'lodash'], [/^moment(?:\.min)?\.js/i, 'moment'],
    [/^three(?:\.min|\.module)?\.js/i, 'three'], [/^gsap(?:\.min)?\.js/i, 'gsap']
  ];
  const match = known.find(([pattern]) => pattern.test(filename));
  return match ? { name: match[1] } : undefined;
}

function detectTechnologyFromUrl(url: string, technologies: Map<string, Set<string>>) {
  const rules: [RegExp, string][] = [
    [/\/_next\//i, 'Next.js'], [/\/_nuxt\//i, 'Nuxt'], [/wp-(?:content|includes)/i, 'WordPress'],
    [/jquery/i, 'jQuery'], [/bootstrap/i, 'Bootstrap'], [/tailwind/i, 'Tailwind CSS'], [/react(?:-dom)?/i, 'React'],
    [/vue(?:\.runtime|\.global|\.min|@)/i, 'Vue.js'], [/angular/i, 'Angular'], [/svelte/i, 'Svelte'],
    [/google-analytics\.com|googletagmanager\.com|gtag\/js/i, 'Google Analytics'], [/connect\.facebook\.net/i, 'Meta Pixel'],
    [/browser\.sentry-cdn\.com|sentry\.io/i, 'Sentry'], [/hotjar\.com/i, 'Hotjar'], [/stripe\.com\/v\d/i, 'Stripe']
  ];
  for (const [pattern, name] of rules) if (pattern.test(url)) addEvidence(technologies, name, url);
}

function addEvidence(map: Map<string, Set<string>>, name: string, evidence: string) {
  const values = map.get(name) ?? new Set<string>(); if (values.size < 3) values.add(evidence); map.set(name, values);
}

function uniqueHosts(urls: string[], firstPartyHost: string) {
  const hosts = new Set<string>();
  for (const raw of urls) { try { const host = new URL(raw).hostname; if (host !== firstPartyHost) hosts.add(host); } catch {} }
  return [...hosts].sort();
}

function buildInventory(technologies: Collections['technologies'], packages: Collections['packages'], cdns: Collections['cdns'], scripts: Collections['scripts'], stylesheets: Collections['stylesheets'], externalHosts: Set<string>, inlineScripts: number): AssetInventory {
  return {
    technologies: [...technologies].map(([name, evidence]) => ({ name, evidence: [...evidence] })).sort((a,b) => a.name.localeCompare(b.name)),
    packages: [...packages.values()].map(x => ({ name: x.name, version: x.version, evidence: [...x.evidence] })).sort((a,b) => a.name.localeCompare(b.name)),
    cdns: [...cdns].map(([provider, x]) => ({ provider, hosts: [...x.hosts].sort(), resources: x.resources.size })).sort((a,b) => a.provider.localeCompare(b.provider)),
    scripts: [...scripts.values()].sort((a,b) => a.url.localeCompare(b.url)),
    stylesheets: [...stylesheets.values()].sort((a,b) => a.url.localeCompare(b.url)),
    externalHosts: [...externalHosts].sort(),
    totals: { scripts: scripts.size + inlineScripts, externalScripts: scripts.size, inlineScripts, stylesheets: stylesheets.size, externalHosts: externalHosts.size }
  };
}

function buildSecurityReport(observations: SecurityObservation[]): SecurityReport {
  const checks: SecurityCheck[] = [];
  const add = (status: SecurityCheck['status'], category: string, title: string, detail: string, recommendation: string, affectedUrls: string[] = []) =>
    checks.push({ status, category, title, detail, recommendation, affectedUrls: [...new Set(affectedUrls)].slice(0, 15) });

  if (!observations.length) {
    add('critical', 'Coverage', 'Security inspection unavailable', 'No page completed far enough to collect browser-visible security signals.', 'Resolve availability errors and scan again.');
  } else {
    const insecurePages = observations.filter(x => !x.https);
    add(insecurePages.length ? 'critical' : 'passed', 'Transport', insecurePages.length ? 'Pages served without HTTPS' : 'HTTPS used on inspected pages', insecurePages.length ? `${insecurePages.length} inspected page(s) used unencrypted HTTP.` : 'Every inspected page used HTTPS.', insecurePages.length ? 'Redirect HTTP to HTTPS and enable HSTS after HTTPS is working everywhere.' : 'Keep TLS configuration and certificates current.', insecurePages.map(x => x.url));

    const headerRules: { header: string; title: string; recommendation: string; severity: 'warning' | 'info'; httpsOnly?: boolean }[] = [
      { header: 'content-security-policy', title: 'Content Security Policy', recommendation: 'Add a restrictive Content-Security-Policy and test it in report-only mode first.', severity: 'warning' },
      { header: 'strict-transport-security', title: 'HTTP Strict Transport Security', recommendation: 'Add Strict-Transport-Security on HTTPS responses after confirming all subdomains support HTTPS.', severity: 'warning', httpsOnly: true },
      { header: 'x-content-type-options', title: 'MIME sniffing protection', recommendation: 'Return X-Content-Type-Options: nosniff.', severity: 'warning' },
      { header: 'referrer-policy', title: 'Referrer Policy', recommendation: 'Set an explicit Referrer-Policy appropriate for the application.', severity: 'info' },
      { header: 'permissions-policy', title: 'Permissions Policy', recommendation: 'Restrict browser capabilities the application does not need.', severity: 'info' },
      { header: 'cross-origin-opener-policy', title: 'Cross-Origin Opener Policy', recommendation: 'Consider COOP where cross-origin window isolation is appropriate.', severity: 'info' }
    ];
    for (const rule of headerRules) {
      const eligible = rule.httpsOnly ? observations.filter(x => x.https) : observations;
      const missing = eligible.filter(x => !x.headers[rule.header]);
      if (!eligible.length) continue;
      add(missing.length ? rule.severity : 'passed', 'Headers', missing.length ? `${rule.title} missing` : `${rule.title} present`, missing.length ? `${missing.length} of ${eligible.length} eligible page(s) did not return ${rule.header}.` : `${rule.header} was present on all eligible pages.`, missing.length ? rule.recommendation : 'Keep the policy reviewed as the application changes.', missing.map(x => x.url));
    }
    const frameMissing = observations.filter(x => !x.headers['x-frame-options'] && !/frame-ancestors/i.test(x.headers['content-security-policy'] ?? ''));
    add(frameMissing.length ? 'warning' : 'passed', 'Headers', frameMissing.length ? 'Clickjacking protection not visible' : 'Clickjacking protection present', frameMissing.length ? `${frameMissing.length} page(s) had neither X-Frame-Options nor a CSP frame-ancestors directive.` : 'Every inspected page exposed frame embedding protection.', frameMissing.length ? 'Set CSP frame-ancestors (preferred) or X-Frame-Options.' : 'Keep frame-ancestor rules aligned with intended embedding.', frameMissing.map(x => x.url));

    const httpsPages = observations.filter(x => x.https);
    const mixed = httpsPages.filter(x => x.mixedContent.length);
    if (!httpsPages.length) add('info', 'Content', 'Mixed-content check not applicable', 'No HTTPS page completed, so mixed HTTP/HTTPS subresources could not be evaluated.', 'Enable HTTPS, then scan again.');
    else add(mixed.length ? 'critical' : 'passed', 'Content', mixed.length ? 'Mixed content detected' : 'No mixed content detected', mixed.length ? `${mixed.reduce((n,x) => n + x.mixedContent.length, 0)} HTTP resource(s) were referenced from HTTPS pages.` : 'No HTTP subresources were observed on HTTPS pages.', mixed.length ? 'Serve every script, stylesheet, image, and API resource over HTTPS.' : 'Continue enforcing HTTPS for all subresources.', mixed.map(x => x.url));

    const insecureForms = observations.filter(x => x.insecureForms.length || (!x.https && x.passwordFields > 0));
    add(insecureForms.length ? 'critical' : 'passed', 'Forms', insecureForms.length ? 'Insecure form handling detected' : 'No insecure form transport detected', insecureForms.length ? 'A form submits to HTTP or a password field appears on a non-HTTPS page.' : 'No inspected form exposed an obvious insecure transport pattern.', insecureForms.length ? 'Use HTTPS for pages containing sensitive fields and every form submission target.' : 'Keep authentication and form submissions HTTPS-only.', insecureForms.map(x => x.url));

    const uniqueCookies = new Map<string, SecurityObservation['cookies'][number]>();
    for (const observation of observations) for (const cookie of observation.cookies) uniqueCookies.set(cookie.key, cookie);
    const cookieValues = [...uniqueCookies.values()];
    const insecureCookies = cookieValues.filter(x => !x.secure);
    const scriptReadableCookies = cookieValues.filter(x => !x.httpOnly);
    if (!cookieValues.length) add('info', 'Cookies', 'No cookies observed', 'The inspected pages did not expose cookies to the browser session.', 'Recheck authenticated journeys separately; this scan does not log in.');
    else {
      add(insecureCookies.length ? 'warning' : 'passed', 'Cookies', insecureCookies.length ? 'Cookies missing Secure' : 'Cookies use Secure', `${insecureCookies.length} of ${cookieValues.length} observed cookie(s) lacked the Secure flag.`, insecureCookies.length ? 'Mark sensitive cookies Secure and serve them only over HTTPS.' : 'Keep sensitive cookies restricted to HTTPS.');
      add(scriptReadableCookies.length ? 'warning' : 'passed', 'Cookies', scriptReadableCookies.length ? 'Cookies accessible to JavaScript' : 'Cookies use HttpOnly', `${scriptReadableCookies.length} of ${cookieValues.length} observed cookie(s) lacked HttpOnly.`, scriptReadableCookies.length ? 'Use HttpOnly for session and authentication cookies that JavaScript does not need.' : 'Keep session cookies protected with HttpOnly.');
    }

    const noSri = observations.filter(x => x.thirdPartyScriptsWithoutIntegrity.length);
    if (noSri.length) add('info', 'Scripts', 'Third-party scripts without SRI', `${noSri.reduce((n,x) => n + x.thirdPartyScriptsWithoutIntegrity.length, 0)} third-party script reference(s) had no integrity attribute. Dynamic providers may not support SRI.`, 'For versioned static CDN files, pin versions and add Subresource Integrity plus crossorigin.', noSri.map(x => x.url));
    const exposed = observations.filter(x => x.exposedHeaders.length);
    if (exposed.length) add('info', 'Disclosure', 'Server technology headers exposed', `${exposed.length} page(s) returned Server or X-Powered-By metadata.`, 'Remove unnecessary technology/version response headers to reduce passive fingerprinting.', exposed.map(x => x.url));

    const expiring = observations.filter(x => x.tls && x.tls.validTo * 1000 < Date.now() + 30 * 86400000);
    if (expiring.length) add(expiring.some(x => (x.tls?.validTo ?? 0) * 1000 < Date.now()) ? 'critical' : 'warning', 'TLS', 'TLS certificate expiry requires attention', `${expiring.length} page certificate(s) are expired or expire within 30 days.`, 'Renew the certificate and verify the full certificate chain.', expiring.map(x => x.url));
    else if (observations.some(x => x.tls)) add('passed', 'TLS', 'TLS certificate validity looks healthy', 'Observed TLS certificates were not within 30 days of expiry.', 'Continue automated certificate renewal and monitoring.');
  }

  const penalties = checks.reduce((total, check) => total + (check.status === 'critical' ? 22 : check.status === 'warning' ? 7 : 0), 0);
  const score = Math.max(0, 100 - penalties);
  const grade: SecurityReport['grade'] = score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 65 ? 'C' : score >= 45 ? 'D' : 'F';
  const headerNames = ['content-security-policy','strict-transport-security','x-content-type-options','referrer-policy','permissions-policy','x-frame-options','cross-origin-opener-policy','cross-origin-resource-policy'];
  const headerCoverage = headerNames.map(name => ({ name, present: observations.filter(x => Boolean(x.headers[name])).length, total: observations.length }));
  const cookieMap = new Map<string, SecurityObservation['cookies'][number]>();
  for (const observation of observations) for (const cookie of observation.cookies) cookieMap.set(cookie.key, cookie);
  const cookieValues = [...cookieMap.values()];
  return {
    score, grade, checks, headerCoverage, tls: observations.flatMap(x => x.tls ? [x.tls] : []),
    cookies: { total: cookieValues.length, secure: cookieValues.filter(x => x.secure).length, httpOnly: cookieValues.filter(x => x.httpOnly).length, sameSite: cookieValues.filter(x => x.sameSite).length },
    pages: observations.map(({ cookies: _cookies, exposedHeaders: _headers, passwordFields: _passwords, tls: _tls, ...page }) => page)
  };
}
