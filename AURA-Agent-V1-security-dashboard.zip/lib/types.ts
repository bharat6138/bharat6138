export type Severity = 'critical' | 'warning' | 'info' | 'passed';
export interface Finding { severity: Severity; category: string; title: string; detail: string; url?: string; recommendation: string }
export interface PageResult { url: string; title: string; status: number | null; loadMs: number; linksFound: number; scriptsFound: number; stylesheetsFound: number; externalHosts: string[]; consoleErrors: string[] }
export interface TechnologyDetection { name: string; evidence: string[] }
export interface PackageDetection { name: string; version?: string; evidence: string[] }
export interface CdnDetection { provider: string; hosts: string[]; resources: number }
export interface ScriptAsset { url: string; type: string; async: boolean; defer: boolean; integrity: boolean; thirdParty: boolean; pages: string[] }
export interface StylesheetAsset { url: string; pages: string[] }
export interface AssetInventory {
  technologies: TechnologyDetection[];
  packages: PackageDetection[];
  cdns: CdnDetection[];
  scripts: ScriptAsset[];
  stylesheets: StylesheetAsset[];
  externalHosts: string[];
  totals: { scripts: number; externalScripts: number; inlineScripts: number; stylesheets: number; externalHosts: number };
}
export type SecurityStatus = 'critical' | 'warning' | 'info' | 'passed';
export interface SecurityCheck { status: SecurityStatus; category: string; title: string; detail: string; recommendation: string; affectedUrls: string[] }
export interface HeaderCoverage { name: string; present: number; total: number }
export interface TlsDetail { url: string; protocol: string; issuer: string; subjectName: string; validFrom: number; validTo: number }
export interface SecurityPageDetail { url: string; https: boolean; headers: Record<string, string>; cookieTotal: number; insecureCookies: number; cookiesWithoutHttpOnly: number; mixedContent: string[]; insecureForms: string[]; thirdPartyScriptsWithoutIntegrity: string[] }
export interface SecurityReport {
  score: number;
  grade: 'A' | 'B' | 'C' | 'D' | 'F';
  checks: SecurityCheck[];
  headerCoverage: HeaderCoverage[];
  tls: TlsDetail[];
  cookies: { total: number; secure: number; httpOnly: number; sameSite: number };
  pages: SecurityPageDetail[];
}
export interface ScanReport { target: string; startedAt: string; finishedAt: string; durationMs: number; score: number; summary: { pages: number; passed: number; warnings: number; critical: number }; findings: Finding[]; inventory: AssetInventory; security: SecurityReport; pages: PageResult[]; limitations: string[] }
