# AURA Agent V1

**AURA** means **Application Unified Runtime Analyzer**. Its tagline is **“Intelligent Application Health Inspector.”**

## What it does

AURA Agent is a local desktop-oriented website inspection tool. A user enters a public application URL, selects **Analyze Application**, and receives a human-readable health report. Behind the dashboard, AURA launches a real Chromium browser, loads the starting page, follows same-origin links (up to 15 pages), and checks common availability, browser-runtime, page-structure, basic accessibility, SEO, and initial-load signals.

The report leads with a health score, summary counts, plain-language findings, and recommendations. Raw JSON is only the API transport format; it is not the primary user experience. Page-level technical details remain available in a collapsible section for troubleshooting.

## V1 scope and limitations

V1 is deliberately a lightweight first release. It scans public HTTP/HTTPS pages, follows links on the same origin, records HTTP status and load time, captures browser console errors, and checks titles, meta descriptions, H1 presence, and image alt attributes.

It does not log in, submit forms, execute business workflows, scan source repositories, prove security, run a complete WCAG audit, generate production load, or replace expert review. Results are heuristics and may include false positives or miss issues. The crawler is capped at 15 pages and observes links available after `DOMContentLoaded`; applications that reveal links later or behind interaction may need future scripted journeys.

## AURA and SonarQube

AURA V1 and SonarQube look at different layers. SonarQube primarily performs static analysis of source code and supports code-quality and security workflows integrated with repositories and CI/CD. AURA V1 observes a running public web application through a real browser and presents runtime-facing symptoms to a broad audience. They can complement each other: SonarQube can help teams reason about code before and during delivery, while AURA can provide a quick view of what a deployed web experience exposes at runtime. V1 does not attempt to match SonarQube’s rule depth, language coverage, governance, or enterprise workflow.

## Technology and packages

- **Next.js 14** provides the dashboard and the local `/api/scan` endpoint in one application. Standalone output lets the production server be bundled with the desktop build.
- **React 18 / React DOM** render the interactive scan form and readable report components.
- **Node.js** powers URL validation, scan orchestration, the local Next.js server, and build scripts. During development it comes from the developer machine; in a packaged Electron app, Electron supplies an embedded Node runtime.
- **Playwright** launches headless Chromium, navigates pages, observes console messages, and reads the rendered DOM. Its Chromium binary is copied into the Windows distributable.
- **Electron** provides the native desktop window and embedded runtime so an end user does not install Node.js or npm.
- **electron-builder** creates Windows NSIS installer and portable `.exe` artifacts.
- **Zod** validates scan API input before a browser is launched.
- **concurrently** runs Next.js and Electron together during desktop development.
- **wait-on** waits for the development web server before opening Electron.
- **TypeScript and `@types/*`** provide compile-time checks and editor assistance.

## Project map

```text
app/                 Next.js dashboard, styles, and scan API
lib/                 Playwright scanner and shared report types
electron/            Desktop bootstrap and packaged local-server launcher
scripts/             Standalone-build asset preparation
tests/               Lightweight automated checks
PROJECT_GUIDE.md     This guide
```

## Development run

Prerequisites: Node.js 20 or newer, npm, and internet access for the initial dependency/browser download.

```bash
npm install
node scripts/install-browsers.mjs
npm run dev
```

`npm run dev:web` runs only the browser dashboard at `http://localhost:3000`. The combined `npm run dev` starts that server and opens the Electron window.

## Build and Windows executable

Run the Windows build on Windows for the most predictable result:

```powershell
npm install
npm run package:win
```

The command builds Next.js standalone output, downloads Chromium, and creates both an installer and portable executable in `dist`. The packaged application includes Electron’s Node runtime, the local Next.js server, application files, and Playwright Chromium. Therefore, the other Windows PC does **not** require Node.js or npm. Copy either the installer or portable executable from `dist` to that PC and run it. Windows SmartScreen may warn because a locally built executable is unsigned; production distribution should add code signing.

Cross-building Windows artifacts from macOS/Linux may require Wine and can be less reliable. A Windows CI runner is a good repeatable packaging option.

## Manager demo and test

1. Install or open the portable AURA executable on a Windows test PC.
2. Confirm the window shows **AURA Agent**, the full-form label, and the tagline.
3. Enter a known public test URL, such as `https://example.com`, and select **Analyze Application**.
4. Explain that a local bundled Chromium session is visiting the application; URL data is not sent to an AURA cloud service.
5. Walk through the health score, critical/warning/advisory counts, plain-language recommendations, and page-level details.
6. Test a deliberately broken or incomplete site to demonstrate HTTP failures, missing headings/metadata, or console errors.
7. Confirm the app still launches on a clean Windows PC without Node.js or npm installed.
8. Set expectations: this V1 is a fast runtime health inspection, not a certification, penetration test, full accessibility audit, or source-code platform.

## Responsible use

Scan only applications you own or have permission to test. Even lightweight crawling can create traffic and may be restricted by organizational policy. Avoid sensitive URLs, and do not treat the V1 score as a compliance or security guarantee.
