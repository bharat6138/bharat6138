import { cp, mkdir } from 'node:fs/promises'; import path from 'node:path';
const root=process.cwd(), standalone=path.join(root,'.next','standalone'); await mkdir(path.join(standalone,'.next'),{recursive:true});
await cp(path.join(root,'.next','static'),path.join(standalone,'.next','static'),{recursive:true});
try{await cp(path.join(root,'public'),path.join(standalone,'public'),{recursive:true})}catch{}
console.log('Standalone UI assets copied.');
