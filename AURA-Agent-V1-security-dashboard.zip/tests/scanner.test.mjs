import test from 'node:test'; import assert from 'node:assert/strict';
test('URL behavior expected by scanner',()=>{const u=new URL('https://example.com/#x');u.hash='';assert.equal(u.href,'https://example.com/')});
