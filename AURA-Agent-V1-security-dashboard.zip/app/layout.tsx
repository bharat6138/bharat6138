import './styles.css';
export const metadata = { title: 'AURA Agent', description: 'Intelligent Application Health Inspector' };
export default function Layout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
