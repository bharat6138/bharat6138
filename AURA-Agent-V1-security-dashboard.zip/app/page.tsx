'use client';

import { useState } from 'react';
import type { ScanReport } from '@/lib/types';

export default function Home() {
  const [url, setUrl] = useState('https://example.com');
  const [report, setReport] = useState<ScanReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function scan() {
    setBusy(true); setError(''); setReport(null);
    try {
      const response = await fetch('/api/scan', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ url }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Scan failed');
      setReport(data);
    } catch (scanError) {
      setError(scanError instanceof Error ? scanError.message : 'Scan failed');
    } finally { setBusy(false); }
  }

  return <main>
    <header><div className="brand"><span className="orb">A</span><div><b>AURA Agent</b><small>Intelligent Application Health Inspector</small></div></div><span className="version">V1 • Local analysis</span></header>
    <section className="hero">
      <p className="eyebrow">APPLICATION UNIFIED RUNTIME ANALYZER</p>
      <h1>See what your application exposes.</h1>
      <p>Inspect runtime health, security posture, technologies, public package versions, CDN providers, scripts, stylesheets, and third-party hosts from one browser-powered scan.</p>
      <div className="scanbar"><input aria-label="Application URL" value={url} onChange={event => setUrl(event.target.value)} onKeyDown={event => event.key === 'Enter' && !busy && scan()} /><button onClick={scan} disabled={busy}>{busy ? 'AURA is analyzing…' : 'Analyze Application'}</button></div>
      {error && <div className="error">{error}</div>}
    </section>
    {busy && <section className="loading"><div className="pulse"/><h2>Inspecting the application</h2><p>Launching Chromium, visiting pages, fingerprinting public assets, and reviewing security signals…</p></section>}
    {report && <Report report={report}/>}<footer>AURA performs local heuristic checks. It does not replace penetration testing, authenticated testing, or a formal compliance audit.</footer>
  </main>;
}

function Report({ report }: { report: ScanReport }) {
  const host = new URL(report.target).hostname;
  return <section className="report">
    <div className="reportHead">
      <div><p className="eyebrow">AGENT ASSESSMENT</p><h2>{host}</h2><p>{report.summary.pages} page(s) inspected in {(report.durationMs / 1000).toFixed(1)}s</p><div className="reportActions"><button onClick={() => downloadHtmlReport(report)}>Download report</button><button className="secondary" onClick={() => downloadJsonReport(report)}>Download JSON</button></div></div>
      <div className="scoreGroup"><Score value={report.score} label="Health"/><Score value={report.security.score} label={`Security ${report.security.grade}`}/></div>
    </div>

    <div className="metrics"><Metric n={report.summary.critical} label="Critical"/><Metric n={report.summary.warnings} label="Warnings"/><Metric n={report.inventory.technologies.length} label="Technologies"/><Metric n={report.inventory.totals.externalHosts} label="External hosts"/></div>

    <section className="dashboardSection">
      <div className="sectionTitle"><div><p className="eyebrow">SECURITY POSTURE</p><h3>Browser-visible security inspection</h3></div><span className={`grade grade-${report.security.grade.toLowerCase()}`}>{report.security.grade}</span></div>
      <div className="securityStats"><Metric n={report.security.headerCoverage.filter(x => x.present === x.total && x.total > 0).length} label="Headers covered"/><Metric n={report.security.cookies.total} label="Cookies"/><Metric n={report.security.cookies.secure} label="Secure cookies"/><Metric n={report.security.tls.length} label="TLS pages"/></div>
      <div className="securityChecks">{report.security.checks.map((check, index) => <article className={`securityCheck ${check.status}`} key={`${check.title}-${index}`}><span className="statusDot"/><div><small>{check.category} · {check.status}</small><h4>{check.title}</h4><p>{check.detail}</p><p className="recommend"><b>Recommended:</b> {check.recommendation}</p>{check.affectedUrls.length > 0 && <code>{check.affectedUrls.join(' • ')}</code>}</div></article>)}</div>
      <details><summary>Security header coverage</summary><div className="coverageGrid">{report.security.headerCoverage.map(header => <div key={header.name}><code>{header.name}</code><b>{header.present}/{header.total}</b></div>)}</div></details>
      {report.security.tls.length > 0 && <details><summary>TLS certificate details</summary><div className="dataList">{report.security.tls.map((tls, index) => <div key={`${tls.url}-${index}`}><b>{tls.protocol} · {tls.issuer || 'Unknown issuer'}</b><span>{tls.subjectName} · expires {new Date(tls.validTo * 1000).toLocaleDateString()}</span><code>{tls.url}</code></div>)}</div></details>}
    </section>

    <section className="dashboardSection">
      <div className="sectionTitle"><div><p className="eyebrow">TECHNOLOGY INVENTORY</p><h3>Tech, packages, CDN and assets</h3></div><span className="inventoryHint">runtime evidence</span></div>
      <div className="inventoryStats"><Metric n={report.inventory.technologies.length} label="Technologies"/><Metric n={report.inventory.packages.length} label="Public packages"/><Metric n={report.inventory.cdns.length} label="CDN providers"/><Metric n={report.inventory.totals.scripts} label="Scripts"/><Metric n={report.inventory.totals.stylesheets} label="Stylesheets"/></div>

      <h4 className="subheading">Detected technologies</h4>
      {report.inventory.technologies.length ? <div className="chips">{report.inventory.technologies.map(tech => <span className="chip" title={tech.evidence.join('\n')} key={tech.name}>{tech.name}</span>)}</div> : <Empty text="No recognizable framework marker was exposed."/>}

      <div className="splitPanels">
        <div><h4 className="subheading">Packages and versions</h4>{report.inventory.packages.length ? <div className="packageList">{report.inventory.packages.map(pkg => <div key={`${pkg.name}-${pkg.version ?? ''}`}><b>{pkg.name}</b><span>{pkg.version ? `v${pkg.version}` : 'version hidden'}</span><code title={pkg.evidence.join('\n')}>{pkg.evidence[0]}</code></div>)}</div> : <Empty text="No package name/version was visible in public asset URLs. Bundled dependencies stay hidden."/>}</div>
        <div><h4 className="subheading">CDN providers</h4>{report.inventory.cdns.length ? <div className="packageList">{report.inventory.cdns.map(cdn => <div key={cdn.provider}><b>{cdn.provider}</b><span>{cdn.resources} resource(s)</span><code>{cdn.hosts.join(', ')}</code></div>)}</div> : <Empty text="No recognized CDN provider was observed."/>}</div>
      </div>

      <details open><summary>Loaded scripts ({report.inventory.totals.externalScripts} external + {report.inventory.totals.inlineScripts} inline)</summary><div className="assetList">{report.inventory.scripts.length ? report.inventory.scripts.map(script => <div key={script.url}><div className="assetFlags"><span>{script.thirdParty ? 'third-party' : 'first-party'}</span><span>{script.type}</span>{script.async && <span>async</span>}{script.defer && <span>defer</span>}<span className={script.integrity ? 'safeFlag' : ''}>{script.thirdParty ? (script.integrity ? 'SRI' : 'no SRI') : 'same-origin'}</span></div><code title={script.url}>{script.url}</code></div>) : <Empty text="No external scripts were found."/>}</div></details>
      <details><summary>Stylesheets ({report.inventory.stylesheets.length})</summary><div className="assetList">{report.inventory.stylesheets.length ? report.inventory.stylesheets.map(sheet => <div key={sheet.url}><code title={sheet.url}>{sheet.url}</code><span>{sheet.pages.length} page(s)</span></div>) : <Empty text="No linked stylesheet was found."/>}</div></details>
      <details><summary>External resource hosts ({report.inventory.externalHosts.length})</summary>{report.inventory.externalHosts.length ? <div className="chips hostChips">{report.inventory.externalHosts.map(hostname => <span className="chip" key={hostname}>{hostname}</span>)}</div> : <Empty text="No external resource host was observed."/>}</details>
      <p className="disclaimer">Package versions are reported only when a public URL or runtime marker exposes them. Bundled, renamed, server-only, or private dependencies cannot be reliably enumerated from a website scan.</p>
    </section>

    <section className="dashboardSection"><p className="eyebrow">QUALITY FINDINGS</p><h3>What AURA found</h3><div className="findings">{report.findings.map((finding, index) => <article className={`finding ${finding.severity}`} key={index}><div className="badge">{finding.severity}</div><div><small>{finding.category}</small><h4>{finding.title}</h4><p>{finding.detail}</p><p className="recommend"><b>Recommended:</b> {finding.recommendation}</p>{finding.url && <code>{finding.url}</code>}</div></article>)}</div></section>

    <details><summary>Page-by-page technical details</summary><div className="pages">{report.pages.map(page => <div key={page.url}><b>{page.title}</b><span>HTTP {page.status ?? '—'} · {page.loadMs} ms · {page.linksFound} links · {page.scriptsFound} scripts · {page.stylesheetsFound} stylesheets</span>{page.externalHosts.length > 0 && <small>External: {page.externalHosts.join(', ')}</small>}<code>{page.url}</code></div>)}</div></details>
    <details><summary>Inspection limitations</summary><ul>{report.limitations.map(item => <li key={item}>{item}</li>)}</ul></details>
  </section>;
}

function Score({ value, label }: { value: number; label: string }) { return <div className={`score ${value >= 80 ? 'good' : value >= 50 ? 'fair' : 'poor'}`}><strong>{value}</strong><span>{label}</span></div>; }
function Metric({ n, label }: { n: number; label: string }) { return <div><strong>{n}</strong><span>{label}</span></div>; }
function Empty({ text }: { text: string }) { return <p className="empty">{text}</p>; }

function downloadJsonReport(report: ScanReport) {
  saveReportFile(report, 'json', JSON.stringify(report, null, 2), 'application/json');
}

function downloadHtmlReport(report: ScanReport) {
  const target = new URL(report.target);
  const securityChecks = report.security.checks.map(check => `<article class="check ${escapeHtml(check.status)}"><div><span>${escapeHtml(check.category)} · ${escapeHtml(check.status)}</span><h3>${escapeHtml(check.title)}</h3><p>${escapeHtml(check.detail)}</p><p><b>Recommended:</b> ${escapeHtml(check.recommendation)}</p>${check.affectedUrls.length ? `<code>${check.affectedUrls.map(escapeHtml).join('<br>')}</code>` : ''}</div></article>`).join('');
  const technologies = report.inventory.technologies.map(item => `<span class="chip">${escapeHtml(item.name)}</span>`).join('') || '<p>No recognizable technology marker was exposed.</p>';
  const packages = report.inventory.packages.map(item => `<tr><td>${escapeHtml(item.name)}</td><td>${escapeHtml(item.version ?? 'Version hidden')}</td><td><code>${escapeHtml(item.evidence[0] ?? '')}</code></td></tr>`).join('') || '<tr><td colspan="3">No public package/version was exposed.</td></tr>';
  const cdns = report.inventory.cdns.map(item => `<tr><td>${escapeHtml(item.provider)}</td><td>${item.resources}</td><td>${item.hosts.map(escapeHtml).join(', ')}</td></tr>`).join('') || '<tr><td colspan="3">No recognized CDN provider was observed.</td></tr>';
  const scripts = report.inventory.scripts.map(item => `<tr><td><code>${escapeHtml(item.url)}</code></td><td>${item.thirdParty ? 'Third-party' : 'First-party'}</td><td>${escapeHtml(item.type)}</td><td>${item.thirdParty ? (item.integrity ? 'SRI' : 'No SRI') : 'Same-origin'}</td></tr>`).join('') || '<tr><td colspan="4">No external script was found.</td></tr>';
  const pages = report.pages.map(page => `<tr><td><code>${escapeHtml(page.url)}</code></td><td>${page.status ?? '—'}</td><td>${page.loadMs} ms</td><td>${page.scriptsFound}</td><td>${page.stylesheetsFound}</td></tr>`).join('');
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>AURA Report — ${escapeHtml(target.hostname)}</title><style>
  :root{color-scheme:dark;--bg:#07101d;--panel:#101d2e;--ink:#edf5ff;--muted:#94a9c0;--accent:#6ae4ff;--good:#50dba8;--warn:#ffc45d;--bad:#ff7885}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 system-ui,sans-serif}main{max-width:1050px;margin:auto;padding:42px 28px}header{display:flex;justify-content:space-between;gap:24px;border-bottom:1px solid #29405b;padding-bottom:26px}h1{font-size:36px;margin:5px 0}.eyebrow{color:var(--accent);font-weight:800;letter-spacing:.16em;font-size:11px}.scores{display:flex;gap:12px}.score{min-width:110px;padding:18px;background:var(--panel);border-radius:16px;text-align:center}.score b{font-size:32px;display:block}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:24px 0}.metric,.section{background:var(--panel);border:1px solid #203750;border-radius:16px;padding:20px}.metric b{display:block;font-size:25px}.metric span,small{color:var(--muted)}.section{margin:20px 0}.check{border-top:1px solid #263b53;padding:14px 0}.check span{text-transform:uppercase;font-size:10px;color:var(--muted)}.check.critical h3{color:var(--bad)}.check.warning h3{color:var(--warn)}.check.passed h3{color:var(--good)}.chip{display:inline-block;margin:4px;padding:7px 10px;background:#17304a;border-radius:999px}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{text-align:left;vertical-align:top;border-bottom:1px solid #263b53;padding:10px 8px}th{color:var(--accent)}code{font-size:11px;color:#9bc1df;overflow-wrap:anywhere}.note{color:var(--muted);border-left:3px solid #567a9d;padding:10px 14px}@media print{body{background:#fff;color:#111}.section,.metric,.score{background:#fff;border-color:#bbb}code,th,.eyebrow{color:#24506d}.check{break-inside:avoid}}@media(max-width:700px){header{display:block}.scores{margin-top:18px}.grid{grid-template-columns:1fr 1fr}table{font-size:11px}}
  </style></head><body><main><header><div><div class="eyebrow">AURA SECURITY & TECHNOLOGY REPORT</div><h1>${escapeHtml(target.hostname)}</h1><p>${escapeHtml(report.target)}<br>Generated ${escapeHtml(new Date(report.finishedAt).toLocaleString())} · ${report.summary.pages} page(s) · ${(report.durationMs / 1000).toFixed(1)}s</p></div><div class="scores"><div class="score"><b>${report.score}</b>Health</div><div class="score"><b>${report.security.score}</b>Security ${report.security.grade}</div></div></header>
  <div class="grid"><div class="metric"><b>${report.summary.critical}</b><span>Critical</span></div><div class="metric"><b>${report.summary.warnings}</b><span>Warnings</span></div><div class="metric"><b>${report.inventory.technologies.length}</b><span>Technologies</span></div><div class="metric"><b>${report.inventory.totals.externalHosts}</b><span>External hosts</span></div></div>
  <section class="section"><div class="eyebrow">SECURITY POSTURE</div><h2>Security checks</h2>${securityChecks}</section>
  <section class="section"><div class="eyebrow">TECHNOLOGY INVENTORY</div><h2>Detected technologies</h2><div>${technologies}</div><h2>Packages and versions</h2><table><thead><tr><th>Package</th><th>Version</th><th>Evidence</th></tr></thead><tbody>${packages}</tbody></table><h2>CDN providers</h2><table><thead><tr><th>Provider</th><th>Resources</th><th>Hosts</th></tr></thead><tbody>${cdns}</tbody></table><h2>Scripts</h2><table><thead><tr><th>URL</th><th>Source</th><th>Type</th><th>Integrity</th></tr></thead><tbody>${scripts}</tbody></table></section>
  <section class="section"><div class="eyebrow">PAGE DETAILS</div><table><thead><tr><th>URL</th><th>HTTP</th><th>Load</th><th>Scripts</th><th>CSS</th></tr></thead><tbody>${pages}</tbody></table></section>
  <section class="section"><div class="eyebrow">LIMITATIONS</div><ul>${report.limitations.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul><p class="note">This report is a browser-visible heuristic inspection, not a penetration test, authenticated audit, CVE proof, or compliance certification.</p></section>
  </main></body></html>`;
  saveReportFile(report, 'html', html, 'text/html');
}

function saveReportFile(report: ScanReport, extension: string, content: string, type: string) {
  const host = new URL(report.target).hostname.replace(/[^a-z0-9.-]+/gi, '-');
  const date = report.finishedAt.slice(0, 10);
  const objectUrl = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement('a'); anchor.href = objectUrl; anchor.download = `AURA-${host}-${date}.${extension}`;
  document.body.appendChild(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character] ?? character);
}
