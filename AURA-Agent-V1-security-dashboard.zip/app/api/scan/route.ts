import { NextResponse } from 'next/server'; import { z } from 'zod'; import { scanApplication } from '@/lib/scanner';
export const runtime = 'nodejs'; export const dynamic = 'force-dynamic';
export async function POST(request: Request) {
  try { const { url } = z.object({url:z.string().min(1).max(2048)}).parse(await request.json()); return NextResponse.json(await scanApplication(url)); }
  catch (error) { return NextResponse.json({error:error instanceof Error?error.message:'Scan failed.'},{status:400}); }
}
