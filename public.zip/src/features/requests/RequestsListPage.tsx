import { startTransition, useDeferredValue, useEffect, useState } from 'react';
import FilterListRoundedIcon from '@mui/icons-material/FilterListRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import {
  Box,
  Button,
  Chip,
  CircularProgress,
  InputAdornment,
  Paper,
  Stack,
  TextField
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { EmptyState } from '@/components/ui/EmptyState';
import { RequestCard } from '@/components/ui/RequestCard';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { loadRequests } from '@/features/requests/requestsSlice';
import type { RequestStatus, UserRole } from '@/types/models';

type FilterKey = 'all' | 'pending' | 'in_review' | 'approved' | 'installed' | 'assigned' | 'in_progress';

function filterOptions(role: UserRole): Array<{ key: FilterKey; label: string }> {
  if (role === 'vendor') {
    return [
      { key: 'all', label: 'All' },
      { key: 'assigned', label: 'Assigned' },
      { key: 'in_progress', label: 'In Progress' },
      { key: 'installed', label: 'Installed' }
    ];
  }

  return [
    { key: 'all', label: 'All' },
    { key: 'pending', label: 'Pending' },
    { key: 'in_review', label: 'In Review' },
    { key: 'approved', label: 'Approved' },
    { key: 'installed', label: 'Installed' }
  ];
}

function matchesFilter(filter: FilterKey, status: RequestStatus) {
  switch (filter) {
    case 'all':
      return true;
    case 'pending':
      return ['submitted'].includes(status);
    case 'in_review':
      return status === 'in_review';
    case 'approved':
      return ['approved', 'assigned', 'in_progress'].includes(status);
    case 'installed':
      return status === 'installed';
    case 'assigned':
      return status === 'assigned';
    case 'in_progress':
      return status === 'in_progress';
    default:
      return true;
  }
}

export function RequestsListPage({
  role,
  overline,
  title
}: {
  role: UserRole;
  overline: string;
  title: string;
}) {
  const dispatch = useAppDispatch();
  const user = useAppSelector((state) => state.auth.user);
  const requests = useAppSelector((state) => state.requests.items);
  const status = useAppSelector((state) => state.requests.status);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterKey>('all');
  const deferredSearch = useDeferredValue(search);
  const isLoading = status === 'loading' || status === 'idle';

  useEffect(() => {
    if (user) {
      void dispatch(loadRequests(user));
    }
  }, [dispatch, user]);

  if (!user) {
    return null;
  }

  const visibleRequests = requests.filter((request) => {
    const normalizedQuery = deferredSearch.trim().toLowerCase();
    const matchesSearch =
      normalizedQuery.length === 0 ||
      [request.storeName, request.id, request.storeCode].some((field) =>
        field.toLowerCase().includes(normalizedQuery)
      );

    return matchesSearch && matchesFilter(filter, request.status);
  });

  return (
    <Stack spacing={2.2}>
      <SectionHeader overline={overline} title={title} />

      <Stack direction="row" spacing={1.2}>
        <TextField
          fullWidth
          placeholder="Search by store or ID"
          value={search}
          onChange={(event) => {
            const nextValue = event.target.value;
            startTransition(() => setSearch(nextValue));
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon color="disabled" />
              </InputAdornment>
            )
          }}
        />
        <Button variant="outlined" color="inherit" sx={{ minWidth: 54, px: 0 }}>
          <FilterListRoundedIcon />
        </Button>
      </Stack>

      <Stack direction="row" spacing={1} useFlexGap flexWrap="wrap">
        {filterOptions(role).map((option) => (
          <Chip
            key={option.key}
            label={option.label}
            clickable
            onClick={() => setFilter(option.key)}
            sx={{
              bgcolor: filter === option.key ? '#141414' : '#FFF',
              color: filter === option.key ? '#FFF' : '#141414',
              border: '1px solid rgba(20,20,20,0.1)'
            }}
          />
        ))}
      </Stack>

      {isLoading ? (
        <Paper sx={{ p: 4, display: 'grid', placeItems: 'center' }}>
          <CircularProgress />
        </Paper>
      ) : null}

      {!isLoading && visibleRequests.length === 0 ? (
        <EmptyState
          title="No requests match yet"
          subtitle="Try a different search term or filter, or start a new request."
          action={
            role === 'customer' ? (
              <Button component={RouterLink} to="/customer/new" variant="contained">
                Start new request
              </Button>
            ) : null
          }
        />
      ) : null}

      <Stack spacing={1.6}>
        {visibleRequests.map((request) => (
          <RequestCard
            key={request.id}
            request={request}
            to={`/${role}/requests/${request.id}`}
          />
        ))}
      </Stack>
    </Stack>
  );
}
