import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { requestService } from '@/services/requestService';
import type { RequestDraft, SetupRequest, UploadedPhoto, User, VendorAssignment } from '@/types/models';

interface RequestsState {
  items: SetupRequest[];
  current: SetupRequest | null;
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: RequestsState = {
  items: [],
  current: null,
  status: 'idle',
  error: null
};

export const loadRequests = createAsyncThunk('requests/loadRequests', async (user: User) =>
  requestService.getForUser(user)
);

export const loadRequestById = createAsyncThunk('requests/loadById', async (id: string) =>
  requestService.getById(id)
);

export const submitDraftRequest = createAsyncThunk(
  'requests/submitDraft',
  async (payload: { draft: RequestDraft; user: User }) =>
    requestService.submitDraft(payload.draft, payload.user)
);

export const updateRequestStatus = createAsyncThunk(
  'requests/updateStatus',
  async (payload: { id: string; status: SetupRequest['status']; actor: string; description: string }) =>
    requestService.updateStatus(payload.id, payload.status, payload.actor, payload.description)
);

export const assignVendorToRequest = createAsyncThunk(
  'requests/assignVendor',
  async (payload: { id: string; assignment: VendorAssignment; actor: string }) =>
    requestService.assignVendor(payload.id, payload.assignment, payload.actor)
);

export const uploadRequestProof = createAsyncThunk(
  'requests/uploadProof',
  async (payload: { id: string; photos: UploadedPhoto[]; actor: string }) =>
    requestService.uploadProof(payload.id, payload.photos, payload.actor)
);

function upsertRequest(items: SetupRequest[], request: SetupRequest): SetupRequest[] {
  const exists = items.some((item) => item.id === request.id);
  if (!exists) {
    return [request, ...items];
  }

  return items.map((item) => (item.id === request.id ? request : item));
}

const requestsSlice = createSlice({
  name: 'requests',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(loadRequests.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(loadRequests.fulfilled, (state, action) => {
        state.items = action.payload;
        state.status = 'succeeded';
      })
      .addCase(loadRequests.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message ?? 'Unable to load requests.';
      })
      .addCase(loadRequestById.fulfilled, (state, action) => {
        state.current = action.payload ?? null;
        if (action.payload) {
          state.items = upsertRequest(state.items, action.payload);
        }
      })
      .addCase(submitDraftRequest.fulfilled, (state, action) => {
        state.items = upsertRequest(state.items, action.payload);
        state.current = action.payload;
      })
      .addCase(updateRequestStatus.fulfilled, (state, action) => {
        state.items = upsertRequest(state.items, action.payload);
        state.current = action.payload;
      })
      .addCase(assignVendorToRequest.fulfilled, (state, action) => {
        state.items = upsertRequest(state.items, action.payload);
        state.current = action.payload;
      })
      .addCase(uploadRequestProof.fulfilled, (state, action) => {
        state.items = upsertRequest(state.items, action.payload);
        state.current = action.payload;
      });
  }
});

export default requestsSlice.reducer;

