import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import AssignmentIndRoundedIcon from '@mui/icons-material/AssignmentIndRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import CloudUploadRoundedIcon from '@mui/icons-material/CloudUploadRounded';
import PendingActionsRoundedIcon from '@mui/icons-material/PendingActionsRounded';
import StraightenRoundedIcon from '@mui/icons-material/StraightenRounded';
import {
  Box,
  Button,
  Divider,
  IconButton,
  MenuItem,
  Paper,
  Stack,
  TextField,
  Typography
} from '@mui/material';
import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { LayoutPreview } from '@/components/ui/LayoutPreview';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { StatusChip } from '@/components/ui/StatusChip';
import {
  assignVendorToRequest,
  loadRequestById,
  updateRequestStatus,
  uploadRequestProof
} from '@/features/requests/requestsSlice';
import { seedLayouts } from '@/services/mockData';
import { vendorService } from '@/services/vendorService';
import type { Vendor } from '@/types/models';
import { filesToPhotos } from '@/utils/files';
import { formatCategoryLabel, formatRelativeDate } from '@/utils/format';

export function RequestDetailPage() {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { requestId = '' } = useParams();
  const user = useAppSelector((state) => state.auth.user);
  const request = useAppSelector(
    (state) =>
      state.requests.items.find((candidate) => candidate.id === requestId) ??
      (state.requests.current?.id === requestId ? state.requests.current : null)
  );
  const [loading, setLoading] = useState(true);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [selectedVendorId, setSelectedVendorId] = useState('');
  const [busy, setBusy] = useState(false);
  const proofInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    let active = true;

    async function load() {
      setLoading(true);
      await dispatch(loadRequestById(requestId));
      if (user?.role === 'admin') {
        const nextVendors = await vendorService.getAll();
        if (active) {
          setVendors(nextVendors);
        }
      }
      if (active) {
        setLoading(false);
      }
    }

    void load();
    return () => {
      active = false;
    };
  }, [dispatch, requestId, user?.role]);

  useEffect(() => {
    if (request?.vendorAssignment?.vendorId) {
      setSelectedVendorId(request.vendorAssignment.vendorId);
    }
  }, [request?.vendorAssignment?.vendorId]);

  if (!user) {
    return null;
  }

  if (loading) {
    return (
      <Paper sx={{ p: 3 }}>
        <Typography>Loading request...</Typography>
      </Paper>
    );
  }

  if (!request) {
    return (
      <Paper sx={{ p: 3 }}>
        <Typography variant="h3">Request not found</Typography>
        <Button sx={{ mt: 2 }} variant="contained" onClick={() => navigate(-1)}>
          Go back
        </Button>
      </Paper>
    );
  }

  const hasAccess =
    user.role === 'admin' ||
    (user.role === 'customer' && request.createdBy === user.id) ||
    (user.role === 'vendor' && request.vendorAssignment?.vendorId === user.id);

  if (!hasAccess) {
    return (
      <Paper sx={{ p: 3 }}>
        <Typography variant="h3">This request is not available for your role.</Typography>
        <Button sx={{ mt: 2 }} variant="contained" onClick={() => navigate(-1)}>
          Go back
        </Button>
      </Paper>
    );
  }

  const selectedLayout = seedLayouts.find((layout) => layout.id === request.layoutId);
  const timeline = [...request.timeline].sort((left, right) => right.createdAt.localeCompare(left.createdAt));

  async function runAction(action: () => Promise<void>) {
    try {
      setBusy(true);
      await action();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Stack spacing={2.2}>
      <Stack direction="row" alignItems="center" spacing={1}>
        <IconButton onClick={() => navigate(-1)} sx={{ border: '1px solid rgba(20,20,20,0.1)' }}>
          <ArrowBackRoundedIcon />
        </IconButton>
        <Box>
          <Typography variant="caption" sx={{ letterSpacing: '0.22em', color: 'text.secondary' }}>
            {user.role.toUpperCase()} VIEW
          </Typography>
          <Typography variant="h2">{request.storeName}</Typography>
        </Box>
      </Stack>

      <Paper sx={{ p: 2.3 }}>
        <Stack direction="row" justifyContent="space-between" spacing={1.5}>
          <Box>
            <Typography variant="caption" sx={{ letterSpacing: '0.16em', color: 'text.secondary' }}>
              {request.id}
            </Typography>
            <Typography variant="h3" sx={{ mt: 0.7 }}>
              {request.storeName}
            </Typography>
            <Typography color="text.secondary" sx={{ mt: 0.7 }}>
              {request.city} - {request.storeCode} - {formatCategoryLabel(request.category)}
            </Typography>
          </Box>
          <StatusChip status={request.status} />
        </Stack>
      </Paper>

      {(user.role === 'admin' || user.role === 'vendor') && (
        <Paper sx={{ p: 2.3 }}>
          <SectionHeader title="Actions" />
          <Stack spacing={1.2}>
            {user.role === 'admin' && (
              <>
                {request.status === 'submitted' ? (
                  <Button
                    variant="contained"
                    disabled={busy}
                    onClick={() =>
                      runAction(async () => {
                        await dispatch(
                          updateRequestStatus({
                            id: request.id,
                            status: 'in_review',
                            actor: user.name,
                            description: 'Request has entered the detailed review queue.'
                          })
                        ).unwrap();
                      })
                    }
                  >
                    Start review
                  </Button>
                ) : null}

                {['submitted', 'in_review'].includes(request.status) ? (
                  <Stack direction="row" spacing={1.2}>
                    <Button
                      fullWidth
                      variant="contained"
                      color="success"
                      disabled={busy}
                      onClick={() =>
                        runAction(async () => {
                          await dispatch(
                            updateRequestStatus({
                              id: request.id,
                              status: 'approved',
                              actor: user.name,
                              description: 'Approved for vendor scheduling and execution.'
                            })
                          ).unwrap();
                        })
                      }
                    >
                      Approve
                    </Button>
                    <Button
                      fullWidth
                      variant="outlined"
                      color="inherit"
                      disabled={busy}
                      onClick={() =>
                        runAction(async () => {
                          await dispatch(
                            updateRequestStatus({
                              id: request.id,
                              status: 'rejected',
                              actor: user.name,
                              description: 'Rejected pending updated scope or site inputs.'
                            })
                          ).unwrap();
                        })
                      }
                    >
                      Reject
                    </Button>
                  </Stack>
                ) : null}

                {['approved', 'assigned', 'in_progress'].includes(request.status) ? (
                  <Stack spacing={1.2}>
                    <TextField
                      select
                      label="Assign vendor"
                      value={selectedVendorId}
                      onChange={(event) => setSelectedVendorId(event.target.value)}
                    >
                      {vendors.map((vendor) => (
                        <MenuItem key={vendor.id} value={vendor.id}>
                          {vendor.teamName} - {vendor.name}
                        </MenuItem>
                      ))}
                    </TextField>
                    <Button
                      variant="contained"
                      disabled={busy || !selectedVendorId}
                      onClick={() =>
                        runAction(async () => {
                          const selectedVendor = vendors.find((vendor) => vendor.id === selectedVendorId);
                          if (!selectedVendor) {
                            return;
                          }

                          await dispatch(
                            assignVendorToRequest({
                              id: request.id,
                              assignment: {
                                vendorId: selectedVendor.id,
                                vendorName: selectedVendor.name,
                                teamName: selectedVendor.teamName,
                                assignedAt: new Date().toISOString()
                              },
                              actor: user.name
                            })
                          ).unwrap();
                        })
                      }
                    >
                      Assign vendor
                    </Button>
                  </Stack>
                ) : null}
              </>
            )}

            {user.role === 'vendor' && (
              <>
                {request.status === 'assigned' ? (
                  <Button
                    variant="contained"
                    disabled={busy}
                    onClick={() =>
                      runAction(async () => {
                        await dispatch(
                          updateRequestStatus({
                            id: request.id,
                            status: 'in_progress',
                            actor: user.name,
                            description: 'Vendor reached site and started installation.'
                          })
                        ).unwrap();
                      })
                    }
                  >
                    Mark in progress
                  </Button>
                ) : null}

                {['assigned', 'in_progress'].includes(request.status) ? (
                  <>
                    <input
                      ref={proofInputRef}
                      hidden
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={async (event) => {
                        const files = Array.from(event.target.files ?? []);
                        if (files.length === 0) {
                          return;
                        }

                        await runAction(async () => {
                          const photos = await filesToPhotos(files, 'proof');
                          await dispatch(
                            uploadRequestProof({
                              id: request.id,
                              photos,
                              actor: user.name
                            })
                          ).unwrap();
                        });
                      }}
                    />
                    <Button
                      variant="outlined"
                      color="inherit"
                      startIcon={<CloudUploadRoundedIcon />}
                      disabled={busy}
                      onClick={() => proofInputRef.current?.click()}
                    >
                      Upload completion proof
                    </Button>
                  </>
                ) : null}

                {request.status === 'in_progress' ? (
                  <Button
                    variant="contained"
                    color="success"
                    disabled={busy}
                    onClick={() =>
                      runAction(async () => {
                        await dispatch(
                          updateRequestStatus({
                            id: request.id,
                            status: 'installed',
                            actor: user.name,
                            description: 'Vendor marked the installation as complete.'
                          })
                        ).unwrap();
                      })
                    }
                  >
                    Mark installed
                  </Button>
                ) : null}
              </>
            )}
          </Stack>
        </Paper>
      )}

      <Paper sx={{ p: 2.3 }}>
        <SectionHeader title="Store and measurements" />
        <Stack spacing={1.4}>
          <Stack direction="row" spacing={1.2}>
            <Paper sx={{ p: 1.6, flex: 1, boxShadow: 'none' }}>
              <Typography variant="caption" sx={{ letterSpacing: '0.16em', color: 'text.secondary' }}>
                HEIGHT
              </Typography>
              <Typography variant="h3" sx={{ mt: 0.8 }}>
                {request.measurements.wallHeight}
                <Typography component="span" color="text.secondary">
                  {' '}
                  {request.measurements.unit}
                </Typography>
              </Typography>
            </Paper>
            <Paper sx={{ p: 1.6, flex: 1, boxShadow: 'none' }}>
              <Typography variant="caption" sx={{ letterSpacing: '0.16em', color: 'text.secondary' }}>
                WIDTH
              </Typography>
              <Typography variant="h3" sx={{ mt: 0.8 }}>
                {request.measurements.wallWidth}
                <Typography component="span" color="text.secondary">
                  {' '}
                  {request.measurements.unit}
                </Typography>
              </Typography>
            </Paper>
            <Paper sx={{ p: 1.6, flex: 1, boxShadow: 'none' }}>
              <Typography variant="caption" sx={{ letterSpacing: '0.16em', color: 'text.secondary' }}>
                DEPTH
              </Typography>
              <Typography variant="h3" sx={{ mt: 0.8 }}>
                {request.measurements.floorDepth}
                <Typography component="span" color="text.secondary">
                  {' '}
                  {request.measurements.unit}
                </Typography>
              </Typography>
            </Paper>
          </Stack>
          <Stack direction="row" spacing={1} alignItems="center">
            <StraightenRoundedIcon color="disabled" />
            <Typography color="text.secondary">
              Updated {formatRelativeDate(request.updatedAt)}
            </Typography>
          </Stack>
        </Stack>
      </Paper>

      {selectedLayout ? (
        <Paper sx={{ overflow: 'hidden' }}>
          <LayoutPreview layout={selectedLayout} />
          <Box sx={{ p: 2.3 }}>
            <SectionHeader
              title={request.layoutName}
              action={
                <Typography color="text.secondary" fontWeight={600}>
                  {`${String(Math.max(request.recommendedLayoutIds.indexOf(request.layoutId) + 1, 1)).padStart(2, '0')} / ${String(
                    Math.max(request.recommendedLayoutIds.length, 1)
                  ).padStart(2, '0')}`}
                </Typography>
              }
            />
            <Typography color="text.secondary">{request.layoutReason}</Typography>
          </Box>
        </Paper>
      ) : null}

      <Paper sx={{ p: 2.3 }}>
        <SectionHeader title="Elements and materials" />
        <Stack spacing={1.3}>
          {request.materialChoices.map((choice, index) => (
            <Box key={choice.elementId}>
              <Stack direction="row" justifyContent="space-between" alignItems="center">
                <Box>
                  <Typography fontWeight={700}>{choice.elementName}</Typography>
                  <Typography color="text.secondary">
                    {choice.materialName} - {choice.finish}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    width: 28,
                    height: 28,
                    borderRadius: '50%',
                    bgcolor: choice.swatch,
                    border: '2px solid rgba(20,20,20,0.08)'
                  }}
                />
              </Stack>
              {index < request.materialChoices.length - 1 ? <Divider sx={{ mt: 1.3 }} /> : null}
            </Box>
          ))}
        </Stack>
      </Paper>

      <Paper sx={{ p: 2.3 }}>
        <SectionHeader title="Captured photos" />
        <Stack direction="row" spacing={1.2} sx={{ overflowX: 'auto', pb: 0.6 }}>
          {request.photos.map((photo) => (
            <Box
              key={photo.id}
              component="img"
              src={photo.dataUrl}
              alt={photo.name}
              sx={{ width: 108, height: 90, objectFit: 'cover', borderRadius: 3, flex: '0 0 auto' }}
            />
          ))}
        </Stack>
      </Paper>

      {request.proofPhotos.length > 0 ? (
        <Paper sx={{ p: 2.3 }}>
          <SectionHeader title="Completion proof" />
          <Stack direction="row" spacing={1.2} sx={{ overflowX: 'auto', pb: 0.6 }}>
            {request.proofPhotos.map((photo) => (
              <Box
                key={photo.id}
                component="img"
                src={photo.dataUrl}
                alt={photo.name}
                sx={{ width: 108, height: 90, objectFit: 'cover', borderRadius: 3, flex: '0 0 auto' }}
              />
            ))}
          </Stack>
        </Paper>
      ) : null}

      {request.vendorAssignment ? (
        <Paper sx={{ p: 2.3 }}>
          <SectionHeader title="Vendor assignment" />
          <Stack direction="row" spacing={1.4} alignItems="center">
            <AssignmentIndRoundedIcon color="disabled" />
            <Box>
              <Typography fontWeight={700}>{request.vendorAssignment.teamName}</Typography>
              <Typography color="text.secondary">
                {request.vendorAssignment.vendorName}
              </Typography>
            </Box>
          </Stack>
        </Paper>
      ) : null}

      <Paper sx={{ p: 2.3 }}>
        <SectionHeader title="Timeline" />
        <Stack spacing={1.6}>
          {timeline.map((event) => (
            <Stack key={event.id} direction="row" spacing={1.4} alignItems="flex-start">
              <Box
                sx={{
                  width: 36,
                  height: 36,
                  borderRadius: '50%',
                  bgcolor: '#EEF3F8',
                  display: 'grid',
                  placeItems: 'center',
                  flexShrink: 0
                }}
              >
                {event.type === 'approved' || event.type === 'installed' ? (
                  <CheckCircleRoundedIcon color="success" fontSize="small" />
                ) : (
                  <PendingActionsRoundedIcon color="primary" fontSize="small" />
                )}
              </Box>
              <Box>
                <Typography fontWeight={700}>{event.title}</Typography>
                <Typography color="text.secondary">{event.description}</Typography>
                <Typography variant="caption" color="text.secondary">
                  {event.actor} - {formatRelativeDate(event.createdAt)}
                </Typography>
              </Box>
            </Stack>
          ))}
        </Stack>
      </Paper>
    </Stack>
  );
}
