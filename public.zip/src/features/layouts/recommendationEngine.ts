import type {
  LayoutRecommendation,
  LayoutRecommendationInput,
  RequestCategory,
  StoreTier
} from '@/types/models';

function toneReason(category: RequestCategory): string {
  switch (category) {
    case 'fixture':
      return 'Balances hero product display and circulation for fixture-heavy rollouts.';
    case 'gsb':
      return 'Optimizes sightlines and frontage space for stronger branding impact.';
    case 'isb':
      return 'Keeps communication surfaces visible without overcrowding the floor.';
    case 'furniture':
      return 'Creates a warmer, slower browse journey with stronger zoning.';
    default:
      return 'Offers a balanced layout for the submitted store profile.';
  }
}

function storeTierBonus(layoutTiers: StoreTier[], storeTier: StoreTier): number {
  return layoutTiers.includes(storeTier) ? 35 : 0;
}

export function buildLayoutRecommendations(
  input: LayoutRecommendationInput
): LayoutRecommendation[] {
  const { store, category, measurements, photoCount, layouts } = input;

  const ranked = layouts
    .map((layout) => {
      let score = 0;
      score += storeTierBonus(layout.recommendedFor, store.type);

      if (layout.categories.includes(category)) {
        score += 30;
      }

      if (photoCount >= 6) {
        score += 10;
      } else if (photoCount >= 3) {
        score += 6;
      }

      if (measurements.wallWidth >= 12) {
        score += layout.elements.length * 2;
      }

      if (store.sizeSqft >= 2000 && layout.name === 'Atelier Grid') {
        score += 12;
      }

      if (store.sizeSqft < 1200 && layout.name === 'Open Concept') {
        score += 12;
      }

      if (store.type === 'flagship' && layout.name === 'Perimeter Flow') {
        score += 8;
      }

      if (store.type === 'compact' && layout.name === 'Gallery Loop') {
        score -= 5;
      }

      return {
        ...layout,
        score,
        rank: 0,
        reason: toneReason(category)
      };
    })
    .sort((left, right) => right.score - left.score)
    .slice(0, 3)
    .map((layout, index) => ({
      ...layout,
      rank: index + 1
    }));

  return ranked;
}

