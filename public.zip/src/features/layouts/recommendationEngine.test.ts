import { buildLayoutRecommendations } from '@/features/layouts/recommendationEngine';
import { seedLayouts, seedStores } from '@/services/mockData';

describe('buildLayoutRecommendations', () => {
  it('returns deterministic flagship recommendations', () => {
    const input = {
      store: seedStores[0],
      category: 'fixture' as const,
      measurements: {
        unit: 'ft' as const,
        wallHeight: 31,
        wallWidth: 13,
        floorDepth: 23
      },
      photoCount: 6,
      layouts: seedLayouts
    };

    const first = buildLayoutRecommendations(input);
    const second = buildLayoutRecommendations(input);

    expect(first.map((layout) => layout.id)).toEqual(second.map((layout) => layout.id));
    expect(first[0]?.id).toBe('layout-atelier-grid');
    expect(first).toHaveLength(3);
  });
});

