import NotificationsNoneRoundedIcon from '@mui/icons-material/NotificationsNoneRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import SparklesRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';
import ArrowOutwardRoundedIcon from '@mui/icons-material/ArrowOutwardRounded';
import ScheduleRoundedIcon from '@mui/icons-material/ScheduleRounded';
import {
  Badge,
  Box,
  Button,
  CircularProgress,
  Grid,
  IconButton,
  Paper,
  Stack,
  Typography
} from '@mui/material';
import { useEffect, useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { MetricCard } from '@/components/ui/MetricCard';
import { RequestCard } from '@/components/ui/RequestCard';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { analyticsService } from '@/services/analyticsService';
import { notificationService } from '@/services/notificationService';
import { formatScheduleTime } from '@/utils/format';
import type { CategorySummary, DashboardMetric, NotificationItem, ScheduleItem, SetupRequest } from '@/types/models';
import { useAppSelector } from '@/app/hooks';

interface DashboardState {
  metrics: DashboardMetric[];
  categories: CategorySummary[];
  todaysInstallations: ScheduleItem[];
  recentRequests: SetupRequest[];
}

export function CustomerHomePage() {
  const user = useAppSelector((state) => state.auth.user);
  const [dashboard, setDashboard] = useState<DashboardState | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  useEffect(() => {
    let active = true;

    async function load() {
      if (!user) {
        return;
      }

      const [nextDashboard, nextNotifications] = await Promise.all([
        analyticsService.getCustomerDashboard(user),
        notificationService.getForRole('customer')
      ]);

      if (active) {
        setDashboard(nextDashboard);
        setNotifications(nextNotifications);
      }
    }

    void load();
    return () => {
      active = false;
    };
  }, [user]);

  if (!user) {
    return null;
  }

  return (
    <Stack spacing={3}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
        <Box>
          <Typography variant="caption" sx={{ letterSpacing: '0.22em', color: 'text.secondary' }}>
            {new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date()).toUpperCase()} -{' '}
            {new Intl.DateTimeFormat('en-US', {
              hour: '2-digit',
              minute: '2-digit'
            }).format(new Date())}
          </Typography>
          <Typography variant="h1" sx={{ mt: 1 }}>
            Good morning,
            <br />
            <Box component="span" sx={{ fontStyle: 'italic' }}>
              {user.name.split(' ')[0]}
            </Box>
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <IconButton sx={{ border: '1px solid rgba(20,20,20,0.1)' }}>
            <SearchRoundedIcon />
          </IconButton>
          <Badge badgeContent={notifications.filter((item) => !item.read).length} color="primary">
            <IconButton sx={{ border: '1px solid rgba(20,20,20,0.1)' }}>
              <NotificationsNoneRoundedIcon />
            </IconButton>
          </Badge>
        </Stack>
      </Stack>

      <Paper
        sx={{
          p: 2.3,
          minHeight: 292,
          background:
            'linear-gradient(180deg, rgba(56,48,43,0.92) 0%, rgba(37,31,28,0.95) 100%), radial-gradient(circle at top, rgba(255,255,255,0.18), transparent 32%)',
          color: '#FFF',
          position: 'relative',
          overflow: 'hidden',
          border: 'none'
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            inset: 0,
            background:
              'linear-gradient(140deg, rgba(255,255,255,0.14) 0%, transparent 26%), linear-gradient(320deg, rgba(184,146,90,0.22) 0%, transparent 34%)'
          }}
        />
        <Stack spacing={2.1} sx={{ position: 'relative' }}>
          <Paper
            sx={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 1,
              alignSelf: 'flex-start',
              py: 0.8,
              px: 1.4,
              borderRadius: 99,
              bgcolor: 'rgba(255,255,255,0.08)',
              color: '#FFF',
              border: '1px solid rgba(255,255,255,0.12)',
              boxShadow: 'none'
            }}
          >
            <SparklesRoundedIcon fontSize="small" />
            <Typography fontWeight={700}>AI-assisted setup</Typography>
          </Paper>

          <Box>
            <Typography variant="h2" sx={{ maxWidth: 260 }}>
              Plan a new store setup
            </Typography>
            <Typography sx={{ mt: 1.2, maxWidth: 280, opacity: 0.82 }}>
              Capture, measure, and let the system suggest the right layout in minutes.
            </Typography>
          </Box>

          <Button
            component={RouterLink}
            to="/customer/new"
            variant="contained"
            sx={{ alignSelf: 'flex-start', bgcolor: '#0F0F0F' }}
          >
            Start new request
          </Button>
        </Stack>
      </Paper>

      {!dashboard ? (
        <Paper sx={{ p: 4, display: 'grid', placeItems: 'center' }}>
          <CircularProgress />
        </Paper>
      ) : (
        <>
          <SectionHeader title="Overview" action="This month" />
          <Grid container spacing={1.4}>
            {dashboard.metrics.map((metric) => (
              <Grid item xs={4} key={metric.id}>
                <MetricCard metric={metric} />
              </Grid>
            ))}
          </Grid>

          <SectionHeader title="Categories" />
          <Grid container spacing={1.6}>
            {dashboard.categories.map((category) => (
              <Grid item xs={6} key={category.id}>
                <Paper sx={{ p: 2.2, minHeight: 144 }}>
                  <Stack justifyContent="space-between" sx={{ height: '100%' }}>
                    <ArrowOutwardRoundedIcon sx={{ color: 'text.secondary' }} />
                    <Box>
                      <Typography variant="h2">{category.count}</Typography>
                      <Typography color="text.secondary">{category.label}</Typography>
                    </Box>
                  </Stack>
                </Paper>
              </Grid>
            ))}
          </Grid>

          <SectionHeader title="Today's installations" />
          <Stack spacing={1.3}>
            {dashboard.todaysInstallations.map((item) => (
              <Paper key={item.id} sx={{ p: 2 }}>
                <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1.5}>
                  <Stack direction="row" spacing={1.5} alignItems="center">
                    <Box
                      sx={{
                        width: 52,
                        height: 52,
                        borderRadius: 3,
                        bgcolor: '#F1EFEA',
                        display: 'grid',
                        placeItems: 'center'
                      }}
                    >
                      <ScheduleRoundedIcon />
                    </Box>
                    <Box>
                      <Typography fontWeight={700}>{item.title}</Typography>
                      <Typography color="text.secondary">{item.subtitle}</Typography>
                    </Box>
                  </Stack>
                  <Box textAlign="right">
                    <Typography variant="h3">{formatScheduleTime(item.scheduledAt)}</Typography>
                  </Box>
                </Stack>
              </Paper>
            ))}
          </Stack>

          <SectionHeader
            title="Recent requests"
            action={
              <Button component={RouterLink} to="/customer/requests" color="inherit">
                View all
              </Button>
            }
          />
          <Stack spacing={1.5}>
            {dashboard.recentRequests.map((request) => (
              <RequestCard key={request.id} request={request} to={`/customer/requests/${request.id}`} />
            ))}
          </Stack>
        </>
      )}
    </Stack>
  );
}
