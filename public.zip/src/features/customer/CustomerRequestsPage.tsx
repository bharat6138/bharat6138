import { RequestsListPage } from '@/features/requests/RequestsListPage';

export function CustomerRequestsPage() {
  return <RequestsListPage role="customer" overline="OPERATIONS" title="All requests" />;
}

