import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import AutoAwesomeRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';
import CheckRoundedIcon from '@mui/icons-material/CheckRounded';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import PhotoCameraRoundedIcon from '@mui/icons-material/PhotoCameraRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import {
  Alert,
  Box,
  Button,
  Chip,
  Grid,
  IconButton,
  InputAdornment,
  LinearProgress,
  Paper,
  Stack,
  TextField,
  Typography
} from '@mui/material';
import { zodResolver } from '@hookform/resolvers/zod';
import { useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { LayoutPreview } from '@/components/ui/LayoutPreview';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { submitDraftRequest } from '@/features/requests/requestsSlice';
import {
  addPhotos,
  movePhotoToFront,
  removePhoto,
  resetDraft,
  selectLayout,
  setCategory,
  setMaterialChoice,
  setMeasurements,
  setRecommendations,
  setStep,
  setStoreAndCategory
} from '@/features/wizard/wizardSlice';
import { layoutService } from '@/services/layoutService';
import { seedMaterials } from '@/services/mockData';
import { storeService } from '@/services/storeService';
import type {
  LayoutOption,
  LayoutRecommendation,
  MaterialChoice,
  MeasurementSet,
  RequestCategory,
  Store,
  UploadedPhoto
} from '@/types/models';
import { filesToPhotos } from '@/utils/files';

const steps = [
  'Which store needs setup?',
  'Capture the space',
  'Capture measurements',
  'Suggested layouts',
  'Choose materials',
  'Review & submit'
] as const;

const measurementSchema = z.object({
  unit: z.enum(['ft', 'in', 'cm']),
  wallHeight: z.coerce.number().min(1),
  wallWidth: z.coerce.number().min(1),
  floorDepth: z.coerce.number().min(1)
});

type MeasurementValues = z.infer<typeof measurementSchema>;

function StepHeader({
  step,
  title,
  onBack
}: {
  step: number;
  title: string;
  onBack: () => void;
}) {
  return (
    <Stack spacing={2}>
      <Stack direction="row" alignItems="center" justifyContent="space-between">
        <IconButton onClick={onBack} sx={{ border: '1px solid rgba(20,20,20,0.1)' }}>
          <ArrowBackRoundedIcon />
        </IconButton>
        <Typography variant="caption" sx={{ letterSpacing: '0.24em', color: 'text.secondary' }}>
          STEP {step} / 6
        </Typography>
        <Box sx={{ width: 40 }} />
      </Stack>
      <Box>
        <Typography variant="h2">{title}</Typography>
        <LinearProgress
          variant="determinate"
          value={(step / 6) * 100}
          sx={{ mt: 2, height: 4, borderRadius: 999, bgcolor: '#E9E4DB' }}
        />
      </Box>
    </Stack>
  );
}

function StoreSelectionStep({
  stores,
  search,
  setSearch,
  selectedStoreId,
  category,
  onSelectStore,
  onSelectCategory,
  onContinue
}: {
  stores: Store[];
  search: string;
  setSearch: (value: string) => void;
  selectedStoreId: string | null;
  category: RequestCategory;
  onSelectStore: (storeId: string) => void;
  onSelectCategory: (category: RequestCategory) => void;
  onContinue: () => void;
}) {
  const categoryOptions: RequestCategory[] = ['fixture', 'gsb', 'isb', 'furniture'];

  return (
    <Stack spacing={2}>
      <Typography color="text.secondary">Search by name, city or store code.</Typography>
      <TextField
        value={search}
        onChange={(event) => setSearch(event.target.value)}
        placeholder="e.g. Indiranagar or BLR-042"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchRoundedIcon color="disabled" />
            </InputAdornment>
          )
        }}
      />

      <Stack direction="row" spacing={1} useFlexGap flexWrap="wrap">
        {categoryOptions.map((option) => (
          <Chip
            key={option}
            label={option.toUpperCase()}
            onClick={() => onSelectCategory(option)}
            sx={{
              bgcolor: category === option ? '#141414' : '#FFF',
              color: category === option ? '#FFF' : '#141414'
            }}
          />
        ))}
      </Stack>

      <Stack spacing={1.4}>
        {stores.map((store) => {
          const active = selectedStoreId === store.id;
          return (
            <Paper
              key={store.id}
              onClick={() => onSelectStore(store.id)}
              sx={{
                p: 2,
                cursor: 'pointer',
                border: active ? '2px solid #141414' : '1px solid rgba(20,20,20,0.08)',
                boxShadow: active ? '0 10px 24px rgba(20,20,20,0.08)' : undefined
              }}
            >
              <Stack direction="row" spacing={1.5} alignItems="center">
                <Box
                  sx={{
                    width: 48,
                    height: 48,
                    borderRadius: 3,
                    bgcolor: active ? '#141414' : '#F3F1EB',
                    color: active ? '#FFF' : '#141414',
                    display: 'grid',
                    placeItems: 'center'
                  }}
                >
                  {active ? <CheckRoundedIcon /> : <LocationOnOutlinedIcon />}
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="h3">{store.name}</Typography>
                  <Typography color="text.secondary">
                    {store.city} - {store.type} - {store.sizeSqft.toLocaleString()} sqft
                  </Typography>
                </Box>
                <Typography color="text.secondary" sx={{ letterSpacing: '0.16em' }}>
                  {store.code}
                </Typography>
              </Stack>
            </Paper>
          );
        })}
      </Stack>

      <Button variant="contained" fullWidth disabled={!selectedStoreId} onClick={onContinue}>
        Continue
      </Button>
    </Stack>
  );
}

function PhotoStep({
  photos,
  onAdd,
  onRemove,
  onReorder,
  onContinue
}: {
  photos: UploadedPhoto[];
  onAdd: (files: File[]) => Promise<void>;
  onRemove: (id: string) => void;
  onReorder: (id: string) => void;
  onContinue: () => void;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);

  return (
    <Stack spacing={2}>
      <Typography color="text.secondary">
        Add at least 3 photos. Cover entrance, key walls, and ceiling.
      </Typography>

      <Stack direction="row" spacing={1}>
        <Chip label="Daylight ideal" />
        <Chip label="Avoid backlight" />
      </Stack>

      <input
        ref={inputRef}
        hidden
        type="file"
        accept="image/*"
        capture="environment"
        multiple
        onChange={async (event) => {
          const files = Array.from(event.target.files ?? []);
          if (files.length > 0) {
            await onAdd(files);
          }
        }}
      />

      <Paper
        onClick={() => inputRef.current?.click()}
        sx={{
          p: 4,
          borderRadius: 4,
          textAlign: 'center',
          border: '2px dashed rgba(20,20,20,0.55)',
          boxShadow: 'none',
          cursor: 'pointer'
        }}
      >
        <Stack spacing={1.3} alignItems="center">
          <Box
            sx={{
              width: 76,
              height: 76,
              borderRadius: '50%',
              bgcolor: '#141414',
              color: '#FFF',
              display: 'grid',
              placeItems: 'center'
            }}
          >
            <PhotoCameraRoundedIcon />
          </Box>
          <Typography variant="h3">Open camera</Typography>
          <Typography color="text.secondary">or tap to upload</Typography>
        </Stack>
      </Paper>

      {photos.length > 0 ? (
        <>
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Typography variant="h3">{photos.length} photos added</Typography>
            <Button color="inherit" onClick={() => inputRef.current?.click()}>
              Add more
            </Button>
          </Stack>
          <Grid container spacing={1.3}>
            {photos.map((photo, index) => (
              <Grid item xs={4} key={photo.id}>
                <Paper sx={{ p: 0.6, boxShadow: 'none' }}>
                  <Box
                    component="img"
                    src={photo.dataUrl}
                    alt={photo.name}
                    sx={{ width: '100%', aspectRatio: '1 / 1', objectFit: 'cover', borderRadius: 3 }}
                  />
                  <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mt: 0.6 }}>
                    <Chip label={(index + 1).toString().padStart(2, '0')} size="small" />
                    <Stack direction="row" spacing={0.6}>
                      <Button size="small" color="inherit" onClick={() => onReorder(photo.id)}>
                        Cover
                      </Button>
                      <Button size="small" color="inherit" onClick={() => onRemove(photo.id)}>
                        Remove
                      </Button>
                    </Stack>
                  </Stack>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </>
      ) : null}

      <Button variant="contained" fullWidth disabled={photos.length < 3} onClick={onContinue}>
        Continue
      </Button>
    </Stack>
  );
}

function MeasurementStep({
  defaultValues,
  onContinue
}: {
  defaultValues: MeasurementSet;
  onContinue: (values: MeasurementValues) => void;
}) {
  const form = useForm<MeasurementValues>({
    resolver: zodResolver(measurementSchema),
    defaultValues
  });

  useEffect(() => {
    form.reset(defaultValues);
  }, [defaultValues, form]);

  const values = form.watch();

  return (
    <Stack component="form" spacing={2} onSubmit={form.handleSubmit(onContinue)}>
      <Typography color="text.secondary">
        Enter the primary dimensions. You can refine later.
      </Typography>

      <Stack direction="row" spacing={1}>
        {(['ft', 'in', 'cm'] as const).map((unit) => (
          <Chip
            key={unit}
            label={unit}
            onClick={() => form.setValue('unit', unit)}
            sx={{
              bgcolor: values.unit === unit ? '#141414' : '#F0ECE5',
              color: values.unit === unit ? '#FFF' : '#141414',
              minWidth: 52
            }}
          />
        ))}
      </Stack>

      {[
        { name: 'wallHeight' as const, label: 'Wall height', subtitle: 'Floor to ceiling' },
        { name: 'wallWidth' as const, label: 'Wall width', subtitle: 'Primary display wall' },
        { name: 'floorDepth' as const, label: 'Floor depth', subtitle: 'Front to back' }
      ].map((field) => (
        <Paper key={field.name} sx={{ p: 2.2 }}>
          <Stack spacing={1.2}>
            <Typography variant="caption" sx={{ letterSpacing: '0.18em', color: 'text.secondary' }}>
              {field.label}
            </Typography>
            <Typography color="text.secondary">{field.subtitle}</Typography>
            <TextField
              type="number"
              InputProps={{
                endAdornment: <InputAdornment position="end">{values.unit}</InputAdornment>
              }}
              error={Boolean(form.formState.errors[field.name])}
              helperText={form.formState.errors[field.name]?.message}
              {...form.register(field.name, { valueAsNumber: true })}
            />
          </Stack>
        </Paper>
      ))}

      <Paper sx={{ p: 2, bgcolor: '#EEE9E0', boxShadow: 'none' }}>
        <Typography>
          Pro tip: laser-measure tools sync automatically later when a live backend is connected.
        </Typography>
      </Paper>

      <Button type="submit" variant="contained" fullWidth>
        Continue
      </Button>
    </Stack>
  );
}

function LayoutStep({
  recommendations,
  selectedLayoutId,
  onSelect,
  onContinue
}: {
  recommendations: LayoutRecommendation[];
  selectedLayoutId: string | null;
  onSelect: (layoutId: string) => void;
  onContinue: () => void;
}) {
  return (
    <Stack spacing={2}>
      <Chip
        icon={<AutoAwesomeRoundedIcon />}
        label="Generated from your photos & measurements"
        sx={{ alignSelf: 'flex-start' }}
      />
      <Stack spacing={1.6}>
        {recommendations.map((layout) => {
          const active = selectedLayoutId === layout.id;
          return (
            <Paper
              key={layout.id}
              onClick={() => onSelect(layout.id)}
              sx={{
                overflow: 'hidden',
                cursor: 'pointer',
                border: active ? '2px solid #141414' : '1px solid rgba(20,20,20,0.08)'
              }}
            >
              <LayoutPreview layout={layout} />
              <Box sx={{ p: 2.2 }}>
                <Stack direction="row" justifyContent="space-between">
                  <Box>
                    <Chip label={layout.suitabilityLabel} sx={{ mb: 1 }} />
                    <Typography variant="h2">{layout.name}</Typography>
                  </Box>
                  {active ? (
                    <Box
                      sx={{
                        width: 40,
                        height: 40,
                        borderRadius: '50%',
                        bgcolor: '#141414',
                        color: '#FFF',
                        display: 'grid',
                        placeItems: 'center'
                      }}
                    >
                      <CheckRoundedIcon />
                    </Box>
                  ) : null}
                </Stack>
                <Typography color="text.secondary" sx={{ mt: 1 }}>
                  {layout.reason}
                </Typography>
                <Stack direction="row" spacing={1} useFlexGap flexWrap="wrap" sx={{ mt: 1.4 }}>
                  {layout.elements.map((element) => (
                    <Chip key={element.id} label={`${element.name} x${element.quantity}`} />
                  ))}
                </Stack>
              </Box>
            </Paper>
          );
        })}
      </Stack>

      <Button variant="outlined" color="inherit" fullWidth>
        Customize a layout
      </Button>
      <Button variant="contained" fullWidth disabled={!selectedLayoutId} onClick={onContinue}>
        Continue
      </Button>
    </Stack>
  );
}

function MaterialStep({
  layout,
  materialChoices,
  onSelect,
  onContinue
}: {
  layout: LayoutOption;
  materialChoices: MaterialChoice[];
  onSelect: (choice: MaterialChoice) => void;
  onContinue: () => void;
}) {
  const selectedMap = new Map(materialChoices.map((choice) => [choice.elementId, choice.materialId]));

  return (
    <Stack spacing={1.8}>
      <Typography color="text.secondary">Pick a brand-approved finish for each element.</Typography>
      {layout.elements.map((element) => (
        <Paper key={element.id} sx={{ p: 2.1 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Box>
              <Typography variant="caption" sx={{ letterSpacing: '0.2em', color: 'text.secondary' }}>
                {element.type}
              </Typography>
              <Typography variant="h3">
                {element.name} x{element.quantity}
              </Typography>
            </Box>
            <Chip label="Selected" />
          </Stack>
          <Grid container spacing={1.2} sx={{ mt: 0.5 }}>
            {seedMaterials.map((material) => {
              const active = selectedMap.get(element.id) === material.id;
              return (
                <Grid item xs={4} key={material.id}>
                  <Paper
                    onClick={() =>
                      onSelect({
                        elementId: element.id,
                        elementName: element.name,
                        materialId: material.id,
                        materialName: material.name,
                        finish: material.finish,
                        swatch: material.swatch
                      })
                    }
                    sx={{
                      p: 1.1,
                      cursor: 'pointer',
                      border: active ? '2px solid #141414' : '1px solid rgba(20,20,20,0.08)',
                      boxShadow: 'none'
                    }}
                  >
                    <Box
                      sx={{
                        height: 80,
                        borderRadius: 2.5,
                        bgcolor: material.swatch,
                        position: 'relative'
                      }}
                    >
                      {active ? (
                        <Box
                          sx={{
                            position: 'absolute',
                            top: 8,
                            right: 8,
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            bgcolor: '#141414',
                            color: '#FFF',
                            display: 'grid',
                            placeItems: 'center'
                          }}
                        >
                          <CheckRoundedIcon fontSize="small" />
                        </Box>
                      ) : null}
                    </Box>
                    <Typography fontWeight={700} sx={{ mt: 1 }}>
                      {material.name}
                    </Typography>
                    <Typography color="text.secondary">{material.finish}</Typography>
                  </Paper>
                </Grid>
              );
            })}
          </Grid>
        </Paper>
      ))}

      <Button
        variant="contained"
        fullWidth
        disabled={materialChoices.length < layout.elements.length}
        onClick={onContinue}
      >
        Continue
      </Button>
    </Stack>
  );
}

function ReviewStep({
  store,
  photos,
  measurements,
  layout,
  materialChoices,
  onSubmit,
  submitting
}: {
  store: Store | undefined;
  photos: UploadedPhoto[];
  measurements: MeasurementSet;
  layout: LayoutOption | undefined;
  materialChoices: MaterialChoice[];
  onSubmit: () => void;
  submitting: boolean;
}) {
  return (
    <Stack spacing={1.8}>
      <Paper sx={{ p: 2.2 }}>
        <SectionHeader title="Store" />
        <Typography variant="h3">{store?.name ?? 'Store not selected'}</Typography>
        <Typography color="text.secondary">
          {store?.city} - {store?.code}
        </Typography>
      </Paper>

      <Paper sx={{ p: 2.2 }}>
        <SectionHeader title="Photos" />
        <Stack direction="row" spacing={1} sx={{ overflowX: 'auto' }}>
          {photos.slice(0, 4).map((photo) => (
            <Box
              key={photo.id}
              component="img"
              src={photo.dataUrl}
              alt={photo.name}
              sx={{ width: 72, height: 72, borderRadius: 3, objectFit: 'cover', flex: '0 0 auto' }}
            />
          ))}
          {photos.length > 4 ? (
            <Paper
              sx={{
                width: 72,
                height: 72,
                borderRadius: 3,
                display: 'grid',
                placeItems: 'center',
                boxShadow: 'none',
                flex: '0 0 auto'
              }}
            >
              +{photos.length - 4}
            </Paper>
          ) : null}
        </Stack>
      </Paper>

      <Paper sx={{ p: 2.2 }}>
        <SectionHeader title="Measurements" />
        <Stack direction="row" spacing={1.2}>
          {[
            ['Height', measurements.wallHeight],
            ['Width', measurements.wallWidth],
            ['Depth', measurements.floorDepth]
          ].map(([label, value]) => (
            <Paper key={label} sx={{ p: 1.5, flex: 1, boxShadow: 'none' }}>
              <Typography variant="h3">{value}</Typography>
              <Typography color="text.secondary">
                {label} - {measurements.unit}
              </Typography>
            </Paper>
          ))}
        </Stack>
      </Paper>

      <Paper sx={{ p: 2.2 }}>
        <SectionHeader title="Layout" />
        <Typography variant="h3">{layout?.name ?? 'No layout selected'}</Typography>
        <Typography color="text.secondary">{layout?.suitabilityLabel}</Typography>
      </Paper>

      <Paper sx={{ p: 2.2 }}>
        <SectionHeader title="Elements & materials" />
        <Stack spacing={1.1}>
          {materialChoices.map((choice) => (
            <Stack key={choice.elementId} direction="row" justifyContent="space-between" alignItems="center">
              <Typography>{choice.elementName}</Typography>
              <Typography color="text.secondary">{choice.materialName}</Typography>
            </Stack>
          ))}
        </Stack>
      </Paper>

      <Button variant="contained" fullWidth disabled={submitting} onClick={onSubmit}>
        {submitting ? 'Submitting...' : 'Submit request'}
      </Button>
    </Stack>
  );
}

export function CustomerNewRequestPage() {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const user = useAppSelector((state) => state.auth.user);
  const draft = useAppSelector((state) => state.wizard.draft);
  const [allStores, setAllStores] = useState<Store[]>([]);
  const [allLayouts, setAllLayouts] = useState<LayoutOption[]>([]);
  const [recommendations, setRecommendationsState] = useState<LayoutRecommendation[]>([]);
  const [search, setSearch] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const deferredSearch = useDeferredValue(search);

  useEffect(() => {
    let active = true;

    async function loadInitial() {
      const [storeResults, layouts] = await Promise.all([storeService.getAll(), layoutService.getLayouts()]);
      if (active) {
        setAllStores(storeResults);
        setAllLayouts(layouts);
      }
    }

    void loadInitial();
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    async function loadRecommendations() {
      if (draft.step !== 4 || !draft.storeId || draft.photos.length < 3) {
        return;
      }

      const nextRecommendations = await layoutService.getRecommendations({
        storeId: draft.storeId,
        category: draft.category,
        measurements: draft.measurements,
        photoCount: draft.photos.length
      });

      if (active) {
        setRecommendationsState(nextRecommendations);
        dispatch(setRecommendations(nextRecommendations.map((layout) => layout.id)));
        if (!draft.selectedLayoutId && nextRecommendations[0]) {
          dispatch(selectLayout(nextRecommendations[0].id));
        }
      }
    }

    void loadRecommendations();
    return () => {
      active = false;
    };
  }, [
    dispatch,
    draft.category,
    draft.measurements,
    draft.photos.length,
    draft.selectedLayoutId,
    draft.step,
    draft.storeId
  ]);

  useEffect(() => {
    if (draft.step === 5) {
      const selectedLayout = allLayouts.find((layout) => layout.id === draft.selectedLayoutId);
      if (!selectedLayout) {
        return;
      }

      selectedLayout.elements.forEach((element) => {
        const exists = draft.materialChoices.some((choice) => choice.elementId === element.id);
        if (!exists) {
          dispatch(
            setMaterialChoice({
              elementId: element.id,
              elementName: element.name,
              materialId: seedMaterials[0].id,
              materialName: seedMaterials[0].name,
              finish: seedMaterials[0].finish,
              swatch: seedMaterials[0].swatch
            })
          );
        }
      });
    }
  }, [allLayouts, dispatch, draft.materialChoices, draft.selectedLayoutId, draft.step]);

  if (!user) {
    return null;
  }

  const selectedStore = allStores.find((store) => store.id === draft.storeId);
  const selectedLayout = allLayouts.find((layout) => layout.id === draft.selectedLayoutId);
  const visibleStores = allStores.filter((store) => {
    const normalizedQuery = deferredSearch.trim().toLowerCase();
    if (!normalizedQuery) {
      return true;
    }

    return [store.name, store.city, store.code].some((field) =>
      field.toLowerCase().includes(normalizedQuery)
    );
  });

  const back = () => {
    if (draft.step === 1) {
      navigate(-1);
      return;
    }

    dispatch(setStep(draft.step - 1));
  };

  const next = () => dispatch(setStep(Math.min(6, draft.step + 1)));

  return (
    <Stack spacing={2.4}>
      <StepHeader step={draft.step} title={steps[draft.step - 1]} onBack={back} />

      {error ? <Alert severity="error">{error}</Alert> : null}

      {draft.step === 1 ? (
        <StoreSelectionStep
          stores={visibleStores}
          search={search}
          setSearch={setSearch}
          selectedStoreId={draft.storeId}
          category={draft.category}
          onSelectStore={(storeId) => dispatch(setStoreAndCategory({ storeId, category: draft.category }))}
          onSelectCategory={(category) => dispatch(setCategory(category))}
          onContinue={next}
        />
      ) : null}

      {draft.step === 2 ? (
        <PhotoStep
          photos={draft.photos}
          onAdd={async (files) => {
            const photos = await filesToPhotos(files, 'space');
            dispatch(addPhotos(photos));
          }}
          onRemove={(id) => dispatch(removePhoto(id))}
          onReorder={(id) => dispatch(movePhotoToFront(id))}
          onContinue={next}
        />
      ) : null}

      {draft.step === 3 ? (
        <MeasurementStep
          defaultValues={draft.measurements}
          onContinue={(values) => {
            dispatch(setMeasurements(values));
            next();
          }}
        />
      ) : null}

      {draft.step === 4 ? (
        recommendations.length > 0 ? (
          <LayoutStep
            recommendations={recommendations}
            selectedLayoutId={draft.selectedLayoutId}
            onSelect={(layoutId) => dispatch(selectLayout(layoutId))}
            onContinue={next}
          />
        ) : (
          <Alert severity="info">Recommendations will appear once the store, photos, and measurements are available.</Alert>
        )
      ) : null}

      {draft.step === 5 ? (
        selectedLayout ? (
          <MaterialStep
            layout={selectedLayout}
            materialChoices={draft.materialChoices}
            onSelect={(choice) => dispatch(setMaterialChoice(choice))}
            onContinue={next}
          />
        ) : (
          <Alert severity="warning">Select a layout first to choose materials.</Alert>
        )
      ) : null}

      {draft.step === 6 ? (
        <ReviewStep
          store={selectedStore}
          photos={draft.photos}
          measurements={draft.measurements}
          layout={selectedLayout}
          materialChoices={draft.materialChoices}
          submitting={submitting}
          onSubmit={async () => {
            try {
              setSubmitting(true);
              setError(null);
              const created = await dispatch(
                submitDraftRequest({
                  draft,
                  user
                })
              ).unwrap();
              dispatch(resetDraft());
              navigate(`/customer/requests/${created.id}`);
            } catch (submitError) {
              setError(submitError instanceof Error ? submitError.message : 'Unable to submit request.');
            } finally {
              setSubmitting(false);
            }
          }}
        />
      ) : null}
    </Stack>
  );
}
