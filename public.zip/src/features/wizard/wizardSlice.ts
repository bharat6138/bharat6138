import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { MaterialChoice, MeasurementSet, RequestCategory, RequestDraft, UploadedPhoto } from '@/types/models';
import { readDraft } from '@/services/storage';

export function createEmptyDraft(): RequestDraft {
  return {
    step: 1,
    storeId: null,
    category: 'fixture',
    photos: [],
    measurements: {
      unit: 'ft',
      wallHeight: 31,
      wallWidth: 13,
      floorDepth: 23
    },
    recommendedLayoutIds: [],
    selectedLayoutId: null,
    materialChoices: [],
    notes: ''
  };
}

interface WizardState {
  draft: RequestDraft;
}

const initialState: WizardState = {
  draft: readDraft() ?? createEmptyDraft()
};

function upsertMaterialChoice(choices: MaterialChoice[], incoming: MaterialChoice): MaterialChoice[] {
  const existingIndex = choices.findIndex((choice) => choice.elementId === incoming.elementId);

  if (existingIndex === -1) {
    return [...choices, incoming];
  }

  return choices.map((choice, index) => (index === existingIndex ? incoming : choice));
}

export const wizardSlice = createSlice({
  name: 'wizard',
  initialState,
  reducers: {
    hydrateDraft(state) {
      state.draft = readDraft() ?? createEmptyDraft();
    },
    setStep(state, action: PayloadAction<number>) {
      state.draft.step = action.payload;
    },
    setStoreAndCategory(
      state,
      action: PayloadAction<{ storeId: string; category: RequestCategory }>
    ) {
      state.draft.storeId = action.payload.storeId;
      state.draft.category = action.payload.category;
      state.draft.recommendedLayoutIds = [];
      state.draft.selectedLayoutId = null;
      state.draft.materialChoices = [];
    },
    setCategory(state, action: PayloadAction<RequestCategory>) {
      state.draft.category = action.payload;
      state.draft.recommendedLayoutIds = [];
      state.draft.selectedLayoutId = null;
      state.draft.materialChoices = [];
    },
    addPhotos(state, action: PayloadAction<UploadedPhoto[]>) {
      state.draft.photos = [...state.draft.photos, ...action.payload].slice(0, 10);
      state.draft.recommendedLayoutIds = [];
      state.draft.selectedLayoutId = null;
      state.draft.materialChoices = [];
    },
    removePhoto(state, action: PayloadAction<string>) {
      state.draft.photos = state.draft.photos.filter((photo) => photo.id !== action.payload);
      state.draft.recommendedLayoutIds = [];
      state.draft.selectedLayoutId = null;
      state.draft.materialChoices = [];
    },
    movePhotoToFront(state, action: PayloadAction<string>) {
      const photo = state.draft.photos.find((item) => item.id === action.payload);
      if (!photo) {
        return;
      }

      state.draft.photos = [
        photo,
        ...state.draft.photos.filter((item) => item.id !== action.payload)
      ];
    },
    setMeasurements(state, action: PayloadAction<MeasurementSet>) {
      state.draft.measurements = action.payload;
      state.draft.recommendedLayoutIds = [];
      state.draft.selectedLayoutId = null;
      state.draft.materialChoices = [];
    },
    setRecommendations(state, action: PayloadAction<string[]>) {
      state.draft.recommendedLayoutIds = action.payload;
    },
    selectLayout(state, action: PayloadAction<string>) {
      state.draft.selectedLayoutId = action.payload;
      state.draft.materialChoices = [];
    },
    setMaterialChoice(state, action: PayloadAction<MaterialChoice>) {
      state.draft.materialChoices = upsertMaterialChoice(state.draft.materialChoices, action.payload);
    },
    setNotes(state, action: PayloadAction<string>) {
      state.draft.notes = action.payload;
    },
    resetDraft(state) {
      state.draft = createEmptyDraft();
    }
  }
});

export const {
  hydrateDraft,
  setStep,
  setStoreAndCategory,
  setCategory,
  addPhotos,
  removePhoto,
  movePhotoToFront,
  setMeasurements,
  setRecommendations,
  selectLayout,
  setMaterialChoice,
  setNotes,
  resetDraft
} = wizardSlice.actions;

export default wizardSlice.reducer;
