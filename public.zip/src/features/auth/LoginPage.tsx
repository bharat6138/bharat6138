import { Alert, Box, Button, Paper, Stack, TextField, Typography } from '@mui/material';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { login } from '@/features/auth/authSlice';

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

type LoginValues = z.infer<typeof loginSchema>;

const quickFillAccounts = [
  { label: 'Customer', email: 'customer@test.com', password: '123456' },
  { label: 'Vendor', email: 'vendor@test.com', password: '123456' },
  { label: 'Admin', email: 'admin@test.com', password: '123456' }
];

export function LoginPage() {
  const dispatch = useAppDispatch();
  const auth = useAppSelector((state) => state.auth);
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors }
  } = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: 'customer@test.com',
      password: '123456'
    }
  });

  const onSubmit = handleSubmit(async (values) => {
    await dispatch(login(values));
  });

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'grid',
        placeItems: 'center',
        px: 2
      }}
    >
      <Paper sx={{ width: '100%', maxWidth: 420, p: 3.2 }}>
        <Stack spacing={2.3}>
          <Box>
            <Typography variant="caption" sx={{ letterSpacing: '0.2em', color: 'text.secondary' }}>
              LUMEN OPERATIONS
            </Typography>
            <Typography variant="h1" sx={{ mt: 1.1 }}>
              Store setup, shaped for every role.
            </Typography>
            <Typography sx={{ mt: 1.5, color: 'text.secondary' }}>
              Sign in with a seeded demo account to explore the customer, vendor, and admin flows.
            </Typography>
          </Box>

          <Stack direction="row" spacing={1} useFlexGap flexWrap="wrap">
            {quickFillAccounts.map((account) => (
              <Button
                key={account.label}
                variant="outlined"
                color="inherit"
                onClick={() => {
                  setValue('email', account.email);
                  setValue('password', account.password);
                }}
                sx={{ minHeight: 42 }}
              >
                {account.label}
              </Button>
            ))}
          </Stack>

          {auth.error ? <Alert severity="error">{auth.error}</Alert> : null}

          <Stack component="form" spacing={1.6} onSubmit={onSubmit}>
            <TextField
              label="Email"
              placeholder="customer@test.com"
              error={Boolean(errors.email)}
              helperText={errors.email?.message}
              {...register('email')}
            />
            <TextField
              label="Password"
              type="password"
              error={Boolean(errors.password)}
              helperText={errors.password?.message}
              {...register('password')}
            />
            <Button type="submit" variant="contained" fullWidth disabled={auth.status === 'loading'}>
              {auth.status === 'loading' ? 'Signing in...' : 'Continue'}
            </Button>
          </Stack>

          <Paper
            sx={{
              p: 2,
              background:
                'linear-gradient(135deg, rgba(20,20,20,0.98) 0%, rgba(62,52,43,0.95) 100%)',
              color: '#FFF',
              border: 'none'
            }}
          >
            <Typography variant="body2" sx={{ opacity: 0.82 }}>
              Demo credentials
            </Typography>
            <Typography sx={{ mt: 0.8, fontWeight: 700 }}>Customer / Vendor / Admin</Typography>
            <Typography variant="body2" sx={{ opacity: 0.82 }}>
              `123456` for each seeded role
            </Typography>
          </Paper>
        </Stack>
      </Paper>
    </Box>
  );
}

