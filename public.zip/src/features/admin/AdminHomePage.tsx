import AssignmentTurnedInRoundedIcon from '@mui/icons-material/AssignmentTurnedInRounded';
import StorefrontRoundedIcon from '@mui/icons-material/StorefrontRounded';
import { Box, CircularProgress, Grid, Paper, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import { MetricCard } from '@/components/ui/MetricCard';
import { RequestCard } from '@/components/ui/RequestCard';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { analyticsService } from '@/services/analyticsService';
import type { DashboardMetric, SetupRequest } from '@/types/models';

interface AdminDashboardState {
  metrics: DashboardMetric[];
  reviewQueue: SetupRequest[];
  storeCount: number;
}

export function AdminHomePage() {
  const [dashboard, setDashboard] = useState<AdminDashboardState | null>(null);

  useEffect(() => {
    let active = true;

    async function load() {
      const data = await analyticsService.getAdminDashboard();
      if (active) {
        setDashboard(data);
      }
    }

    void load();
    return () => {
      active = false;
    };
  }, []);

  return (
    <Stack spacing={2.4}>
      <Box>
        <Typography variant="caption" sx={{ letterSpacing: '0.22em', color: 'text.secondary' }}>
          OPERATIONS CONTROL
        </Typography>
        <Typography variant="h1" sx={{ mt: 1 }}>
          Admin command
        </Typography>
        <Typography color="text.secondary" sx={{ mt: 1 }}>
          Approvals, vendor orchestration, and live setup visibility across the network.
        </Typography>
      </Box>

      <Paper
        sx={{
          p: 2.4,
          background: 'linear-gradient(135deg, #151515 0%, #2F2B28 100%)',
          color: '#FFF',
          border: 'none'
        }}
      >
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Box>
            <Typography variant="h3">Daily operations pulse</Typography>
            <Typography sx={{ mt: 0.8, opacity: 0.82 }}>
              Keep approvals moving and vendors aligned before installs slip.
            </Typography>
          </Box>
          <AssignmentTurnedInRoundedIcon sx={{ fontSize: 42, opacity: 0.72 }} />
        </Stack>
      </Paper>

      {!dashboard ? (
        <Paper sx={{ p: 4, display: 'grid', placeItems: 'center' }}>
          <CircularProgress />
        </Paper>
      ) : (
        <>
          <Grid container spacing={1.4}>
            {dashboard.metrics.map((metric) => (
              <Grid item xs={4} key={metric.id}>
                <MetricCard metric={metric} />
              </Grid>
            ))}
          </Grid>

          <SectionHeader title="Needs review" />
          <Stack spacing={1.5}>
            {dashboard.reviewQueue.map((request) => (
              <RequestCard key={request.id} request={request} to={`/admin/requests/${request.id}`} />
            ))}
          </Stack>

          <SectionHeader title="Network snapshot" />
          <Paper sx={{ p: 2.2 }}>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <Box
                sx={{
                  width: 54,
                  height: 54,
                  borderRadius: 3,
                  bgcolor: '#F3EFE7',
                  display: 'grid',
                  placeItems: 'center'
                }}
              >
                <StorefrontRoundedIcon />
              </Box>
              <Box>
                <Typography fontWeight={700}>{dashboard.storeCount} stores in active coverage</Typography>
                <Typography color="text.secondary">
                  Mobile-first operations with shared request data across customers, vendors, and admins.
                </Typography>
              </Box>
            </Stack>
          </Paper>
        </>
      )}
    </Stack>
  );
}

