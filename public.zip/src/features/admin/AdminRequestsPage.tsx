import { RequestsListPage } from '@/features/requests/RequestsListPage';

export function AdminRequestsPage() {
  return <RequestsListPage role="admin" overline="OPERATIONS" title="Review queue" />;
}

