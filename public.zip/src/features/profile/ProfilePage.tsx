import ApartmentRoundedIcon from '@mui/icons-material/ApartmentRounded';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import PrivacyTipRoundedIcon from '@mui/icons-material/PrivacyTipRounded';
import SettingsRoundedIcon from '@mui/icons-material/SettingsRounded';
import { Avatar, Box, Button, List, ListItem, ListItemIcon, ListItemText, Paper, Stack, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { logout } from '@/features/auth/authSlice';

export function ProfilePage() {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const user = useAppSelector((state) => state.auth.user);

  if (!user) {
    return null;
  }

  return (
    <Stack spacing={2.2}>
      <Typography variant="h1">Profile</Typography>

      <Paper sx={{ p: 2.2 }}>
        <Stack direction="row" spacing={2} alignItems="center">
          <Avatar
            sx={{
              width: 64,
              height: 64,
              bgcolor: '#141414',
              color: '#FFF',
              fontWeight: 800,
              fontSize: 32
            }}
          >
            {user.name[0]}
          </Avatar>
          <Box>
            <Typography variant="h3">{user.name}</Typography>
            <Typography color="text.secondary">
              {user.title} - {user.location}
            </Typography>
          </Box>
        </Stack>
      </Paper>

      <Paper sx={{ overflow: 'hidden' }}>
        <List disablePadding>
          {[
            {
              icon: <ApartmentRoundedIcon />,
              label: 'Organization',
              value: user.organization
            },
            {
              icon: <NotificationsRoundedIcon />,
              label: 'Notifications',
              value: 'On'
            },
            {
              icon: <PrivacyTipRoundedIcon />,
              label: 'Privacy',
              value: 'Manage'
            },
            {
              icon: <SettingsRoundedIcon />,
              label: 'Preferences',
              value: user.role === 'admin' ? 'Ops default' : 'Mobile first'
            }
          ].map((item, index) => (
            <ListItem
              key={item.label}
              divider={index < 3}
              secondaryAction={
                <Typography color="text.secondary" fontWeight={500}>
                  {item.value}
                </Typography>
              }
            >
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.label} />
            </ListItem>
          ))}
        </List>
      </Paper>

      <Button
        variant="outlined"
        color="inherit"
        startIcon={<LogoutRoundedIcon />}
        onClick={async () => {
          await dispatch(logout());
          navigate('/login', { replace: true });
        }}
      >
        Sign out
      </Button>
    </Stack>
  );
}
