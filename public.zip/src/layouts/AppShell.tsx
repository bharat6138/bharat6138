import { Box } from '@mui/material';
import type { PropsWithChildren } from 'react';
import type { UserRole } from '@/types/models';
import { BottomTabNav } from '@/components/ui/BottomTabNav';

export function AppShell({
  role,
  children
}: PropsWithChildren<{ role: UserRole }>) {
  return (
    <Box
      sx={{
        minHeight: '100vh',
        px: { xs: 0, sm: 3 },
        py: { xs: 0, sm: 3 },
        display: 'flex',
        justifyContent: 'center'
      }}
    >
      <Box
        sx={{
          width: '100%',
          maxWidth: 460,
          minHeight: '100vh',
          bgcolor: '#FBF9F5',
          position: 'relative',
          boxShadow: { xs: 'none', sm: '0 18px 60px rgba(20,20,20,0.12)' },
          overflow: 'hidden',
          borderRadius: { xs: 0, sm: 8 }
        }}
      >
        <Box sx={{ px: 2.5, pt: 2.5, pb: 13 }}>{children}</Box>
        <BottomTabNav role={role} />
      </Box>
    </Box>
  );
}

