import { createId } from '@/utils/id';
import type { UploadedPhoto } from '@/types/models';

function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error(`Unable to read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

export async function filesToPhotos(
  files: File[],
  kind: UploadedPhoto['kind']
): Promise<UploadedPhoto[]> {
  const items = await Promise.all(
    files.map(async (file) => ({
      id: createId(kind),
      name: file.name,
      dataUrl: await readFile(file),
      createdAt: new Date().toISOString(),
      kind
    }))
  );

  return items;
}

