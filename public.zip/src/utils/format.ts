import type { RequestCategory, RequestStatus } from '@/types/models';

const categoryLabelMap: Record<RequestCategory, string> = {
  fixture: 'Fixture',
  gsb: 'GSB',
  isb: 'ISB',
  furniture: 'Furniture'
};

const statusLabelMap: Record<RequestStatus, string> = {
  draft: 'Draft',
  submitted: 'Pending',
  in_review: 'In Review',
  approved: 'Approved',
  assigned: 'Pending',
  in_progress: 'Approved',
  installed: 'Installed',
  rejected: 'Rejected'
};

export function formatCategoryLabel(category: RequestCategory): string {
  return categoryLabelMap[category];
}

export function formatStatusLabel(status: RequestStatus): string {
  return statusLabelMap[status];
}

export function formatRelativeDate(input: string): string {
  const target = new Date(input).getTime();
  const now = Date.now();
  const diff = Math.max(0, now - target);
  const days = Math.floor(diff / 86_400_000);
  const hours = Math.floor(diff / 3_600_000);
  const minutes = Math.floor(diff / 60_000);

  if (days > 0) {
    return `${days}d ago`;
  }

  if (hours > 0) {
    return `${hours}h ago`;
  }

  if (minutes > 0) {
    return `${minutes}m ago`;
  }

  return 'Just now';
}

export function formatScheduleTime(input: string): string {
  return new Intl.DateTimeFormat('en-IN', {
    hour: '2-digit',
    minute: '2-digit'
  }).format(new Date(input));
}

export function formatLargeNumber(value: number): string {
  return value.toString().padStart(2, '0');
}

export function titleCase(input: string): string {
  return input
    .split(' ')
    .filter(Boolean)
    .map((token) => token[0]?.toUpperCase() + token.slice(1))
    .join(' ');
}

