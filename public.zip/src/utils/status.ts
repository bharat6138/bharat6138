import type { RequestStatus } from '@/types/models';

export interface StatusMeta {
  label: string;
  foreground: string;
  background: string;
  border: string;
}

const statusMetaMap: Record<RequestStatus, StatusMeta> = {
  draft: {
    label: 'Draft',
    foreground: '#635B4F',
    background: '#EEE7DB',
    border: '#D9CCB7'
  },
  submitted: {
    label: 'Pending',
    foreground: '#8A5B00',
    background: '#FFF2D8',
    border: '#F0CD7A'
  },
  in_review: {
    label: 'In Review',
    foreground: '#1565D8',
    background: '#DCEBFF',
    border: '#9EC2FF'
  },
  approved: {
    label: 'Approved',
    foreground: '#1A8B57',
    background: '#DEF6E8',
    border: '#A1DFC0'
  },
  assigned: {
    label: 'Pending',
    foreground: '#8A5B00',
    background: '#FFF2D8',
    border: '#F0CD7A'
  },
  in_progress: {
    label: 'Approved',
    foreground: '#1A8B57',
    background: '#DEF6E8',
    border: '#A1DFC0'
  },
  installed: {
    label: 'Installed',
    foreground: '#1A8B57',
    background: '#E6F9EE',
    border: '#B8EBCB'
  },
  rejected: {
    label: 'Rejected',
    foreground: '#A33232',
    background: '#FCE4E4',
    border: '#E8B9B9'
  }
};

export function getStatusMeta(status: RequestStatus): StatusMeta {
  return statusMetaMap[status];
}

