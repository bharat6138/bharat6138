export type UserRole = 'customer' | 'vendor' | 'admin';

export type StoreTier = 'flagship' | 'standard' | 'compact';

export type RequestCategory = 'fixture' | 'gsb' | 'isb' | 'furniture';

export type RequestStatus =
  | 'draft'
  | 'submitted'
  | 'in_review'
  | 'approved'
  | 'assigned'
  | 'in_progress'
  | 'installed'
  | 'rejected';

export type MeasurementUnit = 'ft' | 'in' | 'cm';

export type LayoutElementType = 'fixture' | 'gsb' | 'isb' | 'furniture';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  title: string;
  location: string;
  organization: string;
}

export interface Store {
  id: string;
  code: string;
  name: string;
  city: string;
  type: StoreTier;
  sizeSqft: number;
  region: string;
}

export interface UploadedPhoto {
  id: string;
  name: string;
  dataUrl: string;
  createdAt: string;
  kind: 'space' | 'proof';
}

export interface MeasurementSet {
  unit: MeasurementUnit;
  wallHeight: number;
  wallWidth: number;
  floorDepth: number;
}

export interface LayoutElement {
  id: string;
  type: LayoutElementType;
  name: string;
  quantity: number;
}

export interface LayoutOption {
  id: string;
  name: string;
  suitabilityLabel: string;
  previewTone: 'linen' | 'amber' | 'graphite' | 'sand';
  recommendedFor: StoreTier[];
  categories: RequestCategory[];
  elements: LayoutElement[];
}

export interface LayoutRecommendation extends LayoutOption {
  score: number;
  rank: number;
  reason: string;
}

export interface MaterialOption {
  id: string;
  name: string;
  finish: string;
  swatch: string;
  description: string;
}

export interface MaterialChoice {
  elementId: string;
  elementName: string;
  materialId: string;
  materialName: string;
  finish: string;
  swatch: string;
}

export interface Vendor {
  id: string;
  name: string;
  teamName: string;
  city: string;
  specialty: RequestCategory[];
}

export interface VendorAssignment {
  vendorId: string;
  vendorName: string;
  teamName: string;
  assignedAt: string;
}

export interface TimelineEvent {
  id: string;
  type:
    | 'created'
    | 'submitted'
    | 'review_started'
    | 'approved'
    | 'rejected'
    | 'assigned'
    | 'progress'
    | 'proof_uploaded'
    | 'installed'
    | 'note';
  title: string;
  description: string;
  actor: string;
  createdAt: string;
}

export interface SetupRequest {
  id: string;
  storeId: string;
  storeName: string;
  storeCode: string;
  city: string;
  category: RequestCategory;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  submittedAt?: string;
  status: RequestStatus;
  measurements: MeasurementSet;
  photos: UploadedPhoto[];
  recommendedLayoutIds: string[];
  layoutId: string;
  layoutName: string;
  layoutReason: string;
  layoutElements: LayoutElement[];
  materialChoices: MaterialChoice[];
  vendorAssignment?: VendorAssignment;
  proofPhotos: UploadedPhoto[];
  notes: string;
  timeline: TimelineEvent[];
}

export interface RequestDraft {
  step: number;
  storeId: string | null;
  category: RequestCategory;
  photos: UploadedPhoto[];
  measurements: MeasurementSet;
  recommendedLayoutIds: string[];
  selectedLayoutId: string | null;
  materialChoices: MaterialChoice[];
  notes: string;
}

export interface NotificationItem {
  id: string;
  role: UserRole | 'all';
  title: string;
  subtitle: string;
  createdAt: string;
  read: boolean;
}

export interface DashboardMetric {
  id: string;
  title: string;
  value: string;
  helper: string;
  tone: 'neutral' | 'blue' | 'green' | 'gold';
}

export interface CategorySummary {
  id: RequestCategory;
  label: string;
  count: number;
}

export interface ScheduleItem {
  id: string;
  title: string;
  subtitle: string;
  scheduledAt: string;
}

export interface LayoutRecommendationInput {
  store: Store;
  category: RequestCategory;
  measurements: MeasurementSet;
  photoCount: number;
  layouts: LayoutOption[];
}

export interface MockDatabase {
  users: User[];
  stores: Store[];
  vendors: Vendor[];
  layouts: LayoutOption[];
  materials: MaterialOption[];
  requests: SetupRequest[];
  notifications: NotificationItem[];
}

