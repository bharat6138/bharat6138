import { Paper, Stack, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import type { SetupRequest } from '@/types/models';
import { formatCategoryLabel, formatRelativeDate } from '@/utils/format';
import { StatusChip } from '@/components/ui/StatusChip';

export function RequestCard({
  request,
  to
}: {
  request: SetupRequest;
  to: string;
}) {
  return (
    <Paper
      component={RouterLink}
      to={to}
      sx={{
        display: 'block',
        p: 2.3,
        textDecoration: 'none',
        color: 'inherit',
        transition: 'transform 180ms ease, box-shadow 180ms ease',
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: '0 18px 36px rgba(20,20,20,0.09)'
        }
      }}
    >
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={1.5}>
        <Stack spacing={0.75}>
          <Typography variant="caption" sx={{ letterSpacing: '0.18em', color: 'text.secondary' }}>
            {request.id}
          </Typography>
          <Typography variant="h3">{request.storeName}</Typography>
        </Stack>
        <StatusChip status={request.status} />
      </Stack>

      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ mt: 2, pt: 2, borderTop: '1px solid rgba(20,20,20,0.08)' }}
      >
        <Typography color="text.secondary">{formatCategoryLabel(request.category)}</Typography>
        <Typography color="text.secondary">{formatRelativeDate(request.updatedAt)}</Typography>
      </Stack>
    </Paper>
  );
}

