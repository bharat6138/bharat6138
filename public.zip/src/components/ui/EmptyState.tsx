import { Paper, Stack, Typography } from '@mui/material';
import type { ReactNode } from 'react';

export function EmptyState({
  title,
  subtitle,
  action
}: {
  title: string;
  subtitle: string;
  action?: ReactNode;
}) {
  return (
    <Paper sx={{ p: 3, textAlign: 'center' }}>
      <Stack spacing={1.5} alignItems="center">
        <Typography variant="h3">{title}</Typography>
        <Typography color="text.secondary">{subtitle}</Typography>
        {action}
      </Stack>
    </Paper>
  );
}

