import { Box, Paper, Stack, Typography } from '@mui/material';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import ChecklistRoundedIcon from '@mui/icons-material/ChecklistRounded';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import BuildRoundedIcon from '@mui/icons-material/BuildRounded';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import PersonOutlineRoundedIcon from '@mui/icons-material/PersonOutlineRounded';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import type { UserRole } from '@/types/models';

function navConfig(role: UserRole) {
  if (role === 'customer') {
    return [
      { label: 'Home', to: '/customer/home', icon: <HomeRoundedIcon fontSize="small" /> },
      { label: 'Requests', to: '/customer/requests', icon: <ChecklistRoundedIcon fontSize="small" /> },
      { label: 'New', to: '/customer/new', icon: <AddRoundedIcon fontSize="small" />, elevated: true },
      { label: 'Profile', to: '/customer/profile', icon: <PersonOutlineRoundedIcon fontSize="small" /> }
    ];
  }

  if (role === 'vendor') {
    return [
      { label: 'Home', to: '/vendor/home', icon: <HomeRoundedIcon fontSize="small" /> },
      { label: 'Tasks', to: '/vendor/requests', icon: <ChecklistRoundedIcon fontSize="small" /> },
      { label: 'Live', to: '/vendor/home', icon: <BuildRoundedIcon fontSize="small" />, elevated: true },
      { label: 'Profile', to: '/vendor/profile', icon: <PersonOutlineRoundedIcon fontSize="small" /> }
    ];
  }

  return [
    { label: 'Home', to: '/admin/home', icon: <HomeRoundedIcon fontSize="small" /> },
    { label: 'Queue', to: '/admin/requests', icon: <ChecklistRoundedIcon fontSize="small" /> },
    { label: 'Review', to: '/admin/home', icon: <InsightsRoundedIcon fontSize="small" />, elevated: true },
    { label: 'Profile', to: '/admin/profile', icon: <PersonOutlineRoundedIcon fontSize="small" /> }
  ];
}

export function BottomTabNav({ role }: { role: UserRole }) {
  const location = useLocation();
  const items = navConfig(role);

  return (
    <Paper
      sx={{
        position: 'absolute',
        insetInline: 16,
        bottom: 14,
        px: 1.6,
        py: 1.2,
        borderRadius: 4.5
      }}
    >
      <Stack direction="row" justifyContent="space-between" alignItems="flex-end">
        {items.map((item) => {
          const active = location.pathname.startsWith(item.to);

          if (item.elevated) {
            return (
              <Box key={item.label} sx={{ mt: -5 }}>
                <Box
                  component={RouterLink}
                  to={item.to}
                  sx={{
                    width: 62,
                    height: 62,
                    borderRadius: 3.5,
                    bgcolor: '#141414',
                    color: '#FFF',
                    display: 'grid',
                    placeItems: 'center',
                    textDecoration: 'none',
                    boxShadow: '0 14px 24px rgba(20,20,20,0.18)'
                  }}
                >
                  <Stack spacing={0.2} alignItems="center">
                    {item.icon}
                    <Typography variant="caption" sx={{ color: '#FFF', fontWeight: 700 }}>
                      {item.label}
                    </Typography>
                  </Stack>
                </Box>
              </Box>
            );
          }

          return (
            <Box
              key={item.label}
              component={RouterLink}
              to={item.to}
              sx={{
                flex: 1,
                textAlign: 'center',
                textDecoration: 'none',
                color: active ? '#141414' : 'text.secondary'
              }}
            >
              <Stack spacing={0.35} alignItems="center">
                {item.icon}
                <Typography variant="caption" sx={{ fontWeight: active ? 700 : 600 }}>
                  {item.label}
                </Typography>
              </Stack>
            </Box>
          );
        })}
      </Stack>
    </Paper>
  );
}

