import { Chip } from '@mui/material';
import { getStatusMeta } from '@/utils/status';
import type { RequestStatus } from '@/types/models';

export function StatusChip({ status }: { status: RequestStatus }) {
  const meta = getStatusMeta(status);

  return (
    <Chip
      label={meta.label}
      size="small"
      sx={{
        fontWeight: 700,
        color: meta.foreground,
        backgroundColor: meta.background,
        border: `1px solid ${meta.border}`
      }}
    />
  );
}

