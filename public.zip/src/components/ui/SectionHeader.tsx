import { Box, Link, Stack, Typography } from '@mui/material';
import type { ReactNode } from 'react';

export function SectionHeader({
  title,
  overline,
  action
}: {
  title: string;
  overline?: string;
  action?: ReactNode;
}) {
  return (
    <Stack direction="row" alignItems="flex-end" justifyContent="space-between" sx={{ mb: 1.5 }}>
      <Box>
        {overline ? (
          <Typography
            variant="caption"
            sx={{ letterSpacing: '0.22em', color: 'text.secondary', display: 'block', mb: 0.5 }}
          >
            {overline}
          </Typography>
        ) : null}
        <Typography variant="h3">{title}</Typography>
      </Box>
      {typeof action === 'string' ? (
        <Link href="#" underline="none" color="text.secondary" fontWeight={600}>
          {action}
        </Link>
      ) : (
        action
      )}
    </Stack>
  );
}

