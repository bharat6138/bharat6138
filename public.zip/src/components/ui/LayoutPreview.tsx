import { Box } from '@mui/material';
import type { LayoutOption } from '@/types/models';

const toneMap: Record<LayoutOption['previewTone'], { bg: string; floor: string; accent: string }> = {
  linen: { bg: '#F5EEDF', floor: '#CDB9A4', accent: '#D9C5A7' },
  amber: { bg: '#F3DFC3', floor: '#C38D41', accent: '#E6C48C' },
  graphite: { bg: '#E5DDD1', floor: '#A69C91', accent: '#2D2E35' },
  sand: { bg: '#F7E8C9', floor: '#E1B76C', accent: '#F08B3C' }
};

export function LayoutPreview({ layout }: { layout: LayoutOption }) {
  const tone = toneMap[layout.previewTone];

  return (
    <Box
      sx={{
        position: 'relative',
        height: 220,
        overflow: 'hidden',
        borderRadius: 4,
        background: `linear-gradient(180deg, ${tone.bg} 0%, #FFF8EF 100%)`
      }}
    >
      <Box
        sx={{
          position: 'absolute',
          left: '12%',
          top: '18%',
          width: '72%',
          height: '64%',
          borderRadius: 3,
          bgcolor: tone.floor,
          transform: 'skewY(-18deg) rotate(-8deg)',
          opacity: 0.82
        }}
      />
      {layout.elements.map((element, index) => (
        <Box
          key={element.id}
          sx={{
            position: 'absolute',
            left: `${18 + (index % 3) * 21}%`,
            top: `${24 + Math.floor(index / 2) * 19}%`,
            width: 42 + index * 2,
            height: 22 + (index % 2) * 10,
            borderRadius: 2.2,
            bgcolor: index % 2 === 0 ? tone.accent : '#FAF7F2',
            border: '1px solid rgba(20,20,20,0.08)',
            boxShadow: '0 10px 18px rgba(20,20,20,0.09)',
            transform: 'skewY(-18deg) rotate(-8deg)'
          }}
        />
      ))}
    </Box>
  );
}

