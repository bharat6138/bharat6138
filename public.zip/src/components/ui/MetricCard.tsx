import { Paper, Stack, Typography } from '@mui/material';
import type { DashboardMetric } from '@/types/models';

const toneMap = {
  neutral: '#141414',
  blue: '#1565D8',
  green: '#1A8B57',
  gold: '#8A5B00'
} as const;

export function MetricCard({ metric }: { metric: DashboardMetric }) {
  return (
    <Paper sx={{ p: 2.1, minHeight: 136 }}>
      <Stack spacing={1}>
        <Typography variant="caption" sx={{ letterSpacing: '0.18em', textTransform: 'uppercase', color: 'text.secondary' }}>
          {metric.title}
        </Typography>
        <Typography variant="h2" sx={{ color: toneMap[metric.tone] }}>
          {metric.value}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {metric.helper}
        </Typography>
      </Stack>
    </Paper>
  );
}

