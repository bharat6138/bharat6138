import { requestService } from '@/services/requestService';
import { storeService } from '@/services/storeService';
import { formatCategoryLabel, formatLargeNumber } from '@/utils/format';
import type {
  CategorySummary,
  DashboardMetric,
  ScheduleItem,
  SetupRequest,
  User
} from '@/types/models';

function countBy<T>(items: T[], predicate: (item: T) => boolean): number {
  return items.filter(predicate).length;
}

function buildCategorySummaries(requests: SetupRequest[]): CategorySummary[] {
  const categories: CategorySummary['id'][] = ['fixture', 'gsb', 'isb', 'furniture'];

  return categories.map((category) => ({
    id: category,
    label: formatCategoryLabel(category),
    count: countBy(requests, (request) => request.category === category)
  }));
}

function upcomingSchedules(requests: SetupRequest[]): ScheduleItem[] {
  return requests
    .filter((request) => ['assigned', 'in_progress', 'installed'].includes(request.status))
    .slice(0, 3)
    .map((request, index) => ({
      id: request.id,
      title: request.storeName,
      subtitle: `${formatCategoryLabel(request.category)} Install - ${request.vendorAssignment?.teamName ?? 'Ops team'}`,
      scheduledAt: new Date(Date.now() + (index + 1) * 2 * 60 * 60 * 1000).toISOString()
    }));
}

export const analyticsService = {
  async getCustomerDashboard(user: User): Promise<{
    metrics: DashboardMetric[];
    categories: CategorySummary[];
    todaysInstallations: ScheduleItem[];
    recentRequests: SetupRequest[];
  }> {
    const requests = await requestService.getForUser(user);

    return {
      metrics: [
        {
          id: 'total-requests',
          title: 'Total Requests',
          value: formatLargeNumber(requests.length),
          helper: '+12 this week',
          tone: 'neutral'
        },
        {
          id: 'pending-approvals',
          title: 'Pending Approvals',
          value: formatLargeNumber(countBy(requests, (request) => request.status === 'in_review')),
          helper: '3 urgent',
          tone: 'blue'
        },
        {
          id: 'installs-today',
          title: 'Installs Today',
          value: formatLargeNumber(countBy(requests, (request) => request.status === 'in_progress')),
          helper: '2 in progress',
          tone: 'green'
        }
      ],
      categories: buildCategorySummaries(requests),
      todaysInstallations: upcomingSchedules(requests),
      recentRequests: requests.slice(0, 4)
    };
  },

  async getVendorDashboard(user: User): Promise<{
    metrics: DashboardMetric[];
    assignedRequests: SetupRequest[];
  }> {
    const requests = await requestService.getForUser(user);

    return {
      metrics: [
        {
          id: 'assigned',
          title: 'Assigned',
          value: formatLargeNumber(requests.length),
          helper: 'Live queue',
          tone: 'neutral'
        },
        {
          id: 'active',
          title: 'Active Now',
          value: formatLargeNumber(countBy(requests, (request) => request.status === 'in_progress')),
          helper: 'On site today',
          tone: 'blue'
        },
        {
          id: 'completed',
          title: 'Completed',
          value: formatLargeNumber(countBy(requests, (request) => request.status === 'installed')),
          helper: 'This cycle',
          tone: 'green'
        }
      ],
      assignedRequests: requests
    };
  },

  async getAdminDashboard(): Promise<{
    metrics: DashboardMetric[];
    reviewQueue: SetupRequest[];
    storeCount: number;
  }> {
    const requests = await requestService.getAll();
    const stores = await storeService.getAll();

    return {
      metrics: [
        {
          id: 'review',
          title: 'Review Queue',
          value: formatLargeNumber(
            countBy(requests, (request) => ['submitted', 'in_review'].includes(request.status))
          ),
          helper: 'Need action',
          tone: 'blue'
        },
        {
          id: 'active-vendors',
          title: 'Active Vendors',
          value: formatLargeNumber(
            countBy(requests, (request) => ['assigned', 'in_progress'].includes(request.status))
          ),
          helper: 'Across regions',
          tone: 'neutral'
        },
        {
          id: 'installed',
          title: 'Installed',
          value: formatLargeNumber(countBy(requests, (request) => request.status === 'installed')),
          helper: `${stores.length} live stores`,
          tone: 'green'
        }
      ],
      reviewQueue: requests.filter((request) => ['submitted', 'in_review'].includes(request.status)).slice(0, 5),
      storeCount: stores.length
    };
  }
};
