import type {
  LayoutOption,
  MaterialOption,
  MeasurementSet,
  MockDatabase,
  NotificationItem,
  SetupRequest,
  Store,
  TimelineEvent,
  UploadedPhoto,
  User,
  Vendor
} from '@/types/models';

function timeOffset(days: number, hours = 0): string {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000 - hours * 60 * 60 * 1000).toISOString();
}

function interiorPhoto(label: string, accent: string): string {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 220">
      <defs>
        <linearGradient id="bg" x1="0" x2="1">
          <stop offset="0%" stop-color="#F7F1E8"/>
          <stop offset="100%" stop-color="#EFE2CE"/>
        </linearGradient>
      </defs>
      <rect width="320" height="220" fill="url(#bg)"/>
      <rect x="18" y="32" width="284" height="160" rx="20" fill="#FFF8EF" stroke="#E6D7C2"/>
      <rect x="50" y="72" width="54" height="62" rx="6" fill="${accent}" opacity="0.7"/>
      <rect x="118" y="86" width="78" height="22" rx="8" fill="#C9AE82"/>
      <rect x="206" y="62" width="58" height="78" rx="10" fill="#F4D49A"/>
      <rect x="118" y="122" width="48" height="28" rx="8" fill="#5B4B3C" opacity="0.85"/>
      <text x="32" y="192" font-family="Arial, sans-serif" font-size="20" fill="#2C241E">${label}</text>
    </svg>
  `;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function proofPhoto(label: string): string {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 220">
      <rect width="320" height="220" fill="#EEF6F0"/>
      <rect x="26" y="26" width="268" height="168" rx="22" fill="#FFFFFF" stroke="#CFE7D6"/>
      <rect x="60" y="74" width="72" height="52" rx="12" fill="#2B7A4B" opacity="0.78"/>
      <rect x="150" y="62" width="98" height="84" rx="14" fill="#BFE1C9"/>
      <path d="M76 152h168" stroke="#D6E9DB" stroke-width="10" stroke-linecap="round"/>
      <text x="32" y="192" font-family="Arial, sans-serif" font-size="20" fill="#1D5B37">${label}</text>
    </svg>
  `;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function createPhotoSet(kind: 'space' | 'proof', labelPrefix: string, count: number): UploadedPhoto[] {
  return Array.from({ length: count }, (_, index) => ({
    id: `${kind}-${index + 1}-${labelPrefix.toLowerCase().replace(/\s+/g, '-')}`,
    name: `${labelPrefix} ${index + 1}.png`,
    dataUrl:
      kind === 'space'
        ? interiorPhoto(`${labelPrefix} ${index + 1}`, index % 2 === 0 ? '#E8B35B' : '#C4874A')
        : proofPhoto(`${labelPrefix} ${index + 1}`),
    createdAt: timeOffset(index + 1),
    kind
  }));
}

function timeline(base: string, actor: string, offsetDays: number): TimelineEvent[] {
  return [
    {
      id: `${base}-created`,
      type: 'created',
      title: 'Draft started',
      description: 'Initial setup information captured.',
      actor,
      createdAt: timeOffset(offsetDays + 1)
    },
    {
      id: `${base}-submitted`,
      type: 'submitted',
      title: 'Request submitted',
      description: 'Submission entered the review queue.',
      actor,
      createdAt: timeOffset(offsetDays)
    }
  ];
}

const measurementTemplate: MeasurementSet = {
  unit: 'ft',
  wallHeight: 31,
  wallWidth: 13,
  floorDepth: 23
};

export const seedUsers: User[] = [
  {
    id: 'customer-01',
    name: 'Vikrant Rana',
    email: 'customer@test.com',
    password: '123456',
    role: 'customer',
    title: 'Regional Ops',
    location: 'Bengaluru',
    organization: 'Lumen Retail Co.'
  },
  {
    id: 'vendor-01',
    name: 'Asha Verma',
    email: 'vendor@test.com',
    password: '123456',
    role: 'vendor',
    title: 'Installation Lead',
    location: 'Mumbai',
    organization: 'Lumen Retail Co.'
  },
  {
    id: 'admin-01',
    name: 'Meera Kapoor',
    email: 'admin@test.com',
    password: '123456',
    role: 'admin',
    title: 'National Admin',
    location: 'Bengaluru',
    organization: 'Lumen Retail Co.'
  }
];

export const seedStores: Store[] = [
  { id: 'store-01', code: 'BLR-042', name: 'Indiranagar Flagship', city: 'Bengaluru', type: 'flagship', sizeSqft: 2400, region: 'South' },
  { id: 'store-02', code: 'MUM-118', name: 'Bandra West', city: 'Mumbai', type: 'standard', sizeSqft: 1200, region: 'West' },
  { id: 'store-03', code: 'DEL-076', name: 'Connaught Place', city: 'New Delhi', type: 'flagship', sizeSqft: 3100, region: 'North' },
  { id: 'store-04', code: 'HYD-031', name: 'Jubilee Hills', city: 'Hyderabad', type: 'compact', sizeSqft: 800, region: 'South' },
  { id: 'store-05', code: 'PUN-015', name: 'Koregaon Park', city: 'Pune', type: 'standard', sizeSqft: 1500, region: 'West' },
  { id: 'store-06', code: 'CHN-022', name: 'T. Nagar', city: 'Chennai', type: 'standard', sizeSqft: 1350, region: 'South' }
];

export const seedVendors: Vendor[] = [
  {
    id: 'vendor-01',
    name: 'Asha Verma',
    teamName: 'Team Alpha',
    city: 'Mumbai',
    specialty: ['fixture', 'gsb', 'furniture']
  },
  {
    id: 'vendor-02',
    name: 'Karan Sethi',
    teamName: 'Team Bravo',
    city: 'Delhi',
    specialty: ['fixture', 'isb']
  },
  {
    id: 'vendor-03',
    name: 'Nisha Iyer',
    teamName: 'Team Nova',
    city: 'Bengaluru',
    specialty: ['gsb', 'furniture']
  }
];

export const seedMaterials: MaterialOption[] = [
  {
    id: 'material-01',
    name: 'Brushed Walnut',
    finish: 'Matte',
    swatch: '#7A5A43',
    description: 'Warm wood finish with a premium matte coat.'
  },
  {
    id: 'material-02',
    name: 'Powder-coated Steel',
    finish: 'Charcoal',
    swatch: '#3F424B',
    description: 'Durable dark neutral for display frames and edges.'
  },
  {
    id: 'material-03',
    name: 'Natural Oak',
    finish: 'Oiled',
    swatch: '#C9A05B',
    description: 'Brand-approved lighter timber for open layouts.'
  }
];

export const seedLayouts: LayoutOption[] = [
  {
    id: 'layout-atelier-grid',
    name: 'Atelier Grid',
    suitabilityLabel: 'Best for flagship',
    previewTone: 'linen',
    recommendedFor: ['flagship', 'standard'],
    categories: ['fixture', 'gsb'],
    elements: [
      { id: 'atelier-table', type: 'fixture', name: 'Mobile Display Table', quantity: 4 },
      { id: 'atelier-stand', type: 'fixture', name: 'TV Display Stand', quantity: 2 },
      { id: 'atelier-facade', type: 'gsb', name: 'Facade GSB 12ft', quantity: 1 },
      { id: 'atelier-window', type: 'isb', name: 'Window ISB Decals', quantity: 1 }
    ]
  },
  {
    id: 'layout-perimeter-flow',
    name: 'Perimeter Flow',
    suitabilityLabel: 'High visibility',
    previewTone: 'amber',
    recommendedFor: ['flagship'],
    categories: ['gsb', 'furniture'],
    elements: [
      { id: 'perimeter-wall', type: 'fixture', name: 'Wall Display Units', quantity: 6 },
      { id: 'perimeter-backlit', type: 'gsb', name: 'Backlit GSB Strip 18ft', quantity: 1 },
      { id: 'perimeter-wraps', type: 'isb', name: 'Pillar ISB Wraps', quantity: 3 },
      { id: 'perimeter-bench', type: 'furniture', name: 'Reception Bench', quantity: 1 }
    ]
  },
  {
    id: 'layout-open-concept',
    name: 'Open Concept',
    suitabilityLabel: 'Compact stores',
    previewTone: 'sand',
    recommendedFor: ['compact', 'standard'],
    categories: ['fixture', 'furniture'],
    elements: [
      { id: 'open-island', type: 'fixture', name: 'Island Fixture', quantity: 1 },
      { id: 'open-facade', type: 'gsb', name: 'Facade GSB 8ft', quantity: 1 },
      { id: 'open-wall', type: 'isb', name: 'Wall ISB Panel', quantity: 1 },
      { id: 'open-lounge', type: 'furniture', name: 'Lounge Seating', quantity: 1 }
    ]
  },
  {
    id: 'layout-gallery-loop',
    name: 'Gallery Loop',
    suitabilityLabel: 'Story-led display',
    previewTone: 'graphite',
    recommendedFor: ['standard', 'flagship'],
    categories: ['fixture', 'isb'],
    elements: [
      { id: 'gallery-wall', type: 'fixture', name: 'Hero Wall Display', quantity: 2 },
      { id: 'gallery-signage', type: 'gsb', name: 'Suspended Signage', quantity: 1 },
      { id: 'gallery-pod', type: 'furniture', name: 'Lounge Pod', quantity: 1 },
      { id: 'gallery-decals', type: 'isb', name: 'Directional ISB Decals', quantity: 2 }
    ]
  }
];

export const seedNotifications: NotificationItem[] = [
  {
    id: 'notif-01',
    role: 'customer',
    title: 'Layout shortlist ready',
    subtitle: 'Indiranagar Flagship suggestions are ready to review.',
    createdAt: timeOffset(0, 3),
    read: false
  },
  {
    id: 'notif-02',
    role: 'vendor',
    title: 'New task assigned',
    subtitle: 'Connaught Place is ready for vendor scheduling.',
    createdAt: timeOffset(0, 4),
    read: false
  },
  {
    id: 'notif-03',
    role: 'admin',
    title: '3 approvals waiting',
    subtitle: 'Pending requests need attention before EOD.',
    createdAt: timeOffset(0, 1),
    read: false
  }
];

const requestPhotos = createPhotoSet('space', 'Store View', 4);
const installationProofs = createPhotoSet('proof', 'Proof Shot', 2);

export const seedRequests: SetupRequest[] = [
  {
    id: 'RQ-2041',
    storeId: 'store-01',
    storeName: 'Indiranagar Flagship',
    storeCode: 'BLR-042',
    city: 'Bengaluru',
    category: 'fixture',
    createdBy: 'customer-01',
    createdAt: timeOffset(3),
    updatedAt: timeOffset(2),
    submittedAt: timeOffset(2),
    status: 'in_review',
    measurements: measurementTemplate,
    photos: requestPhotos,
    recommendedLayoutIds: ['layout-atelier-grid', 'layout-perimeter-flow', 'layout-open-concept'],
    layoutId: 'layout-atelier-grid',
    layoutName: 'Atelier Grid',
    layoutReason: 'Best fit for flagship circulation and product zoning.',
    layoutElements: seedLayouts[0].elements,
    materialChoices: seedLayouts[0].elements.map((element) => ({
      elementId: element.id,
      elementName: element.name,
      materialId: 'material-01',
      materialName: 'Brushed Walnut',
      finish: 'Matte',
      swatch: '#7A5A43'
    })),
    vendorAssignment: undefined,
    proofPhotos: [],
    notes: 'Customer wants a premium but flexible front-of-house layout.',
    timeline: [
      ...timeline('rq-2041', 'Vikrant Rana', 2),
      {
        id: 'rq-2041-review',
        type: 'review_started',
        title: 'Review in progress',
        description: 'Admin is validating proposed layout and fixture mix.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(1)
      }
    ]
  },
  {
    id: 'RQ-2039',
    storeId: 'store-02',
    storeName: 'Bandra West',
    storeCode: 'MUM-118',
    city: 'Mumbai',
    category: 'gsb',
    createdBy: 'customer-01',
    createdAt: timeOffset(4),
    updatedAt: timeOffset(3),
    submittedAt: timeOffset(3),
    status: 'approved',
    measurements: { unit: 'ft', wallHeight: 24, wallWidth: 14, floorDepth: 18 },
    photos: createPhotoSet('space', 'Branding', 3),
    recommendedLayoutIds: ['layout-perimeter-flow', 'layout-atelier-grid', 'layout-gallery-loop'],
    layoutId: 'layout-perimeter-flow',
    layoutName: 'Perimeter Flow',
    layoutReason: 'High frontage visibility and strong wall signage coverage.',
    layoutElements: seedLayouts[1].elements,
    materialChoices: seedLayouts[1].elements.map((element) => ({
      elementId: element.id,
      elementName: element.name,
      materialId: 'material-02',
      materialName: 'Powder-coated Steel',
      finish: 'Charcoal',
      swatch: '#3F424B'
    })),
    vendorAssignment: undefined,
    proofPhotos: [],
    notes: 'Facade and sidewall branding to align with updated campaign.',
    timeline: [
      ...timeline('rq-2039', 'Vikrant Rana', 3),
      {
        id: 'rq-2039-approved',
        type: 'approved',
        title: 'Approved',
        description: 'Request approved and ready for vendor assignment.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(2)
      }
    ]
  },
  {
    id: 'RQ-2036',
    storeId: 'store-06',
    storeName: 'T. Nagar',
    storeCode: 'CHN-022',
    city: 'Chennai',
    category: 'isb',
    createdBy: 'customer-01',
    createdAt: timeOffset(6),
    updatedAt: timeOffset(5),
    submittedAt: timeOffset(5),
    status: 'submitted',
    measurements: { unit: 'ft', wallHeight: 22, wallWidth: 11, floorDepth: 16 },
    photos: createPhotoSet('space', 'Signage', 3),
    recommendedLayoutIds: ['layout-gallery-loop', 'layout-open-concept'],
    layoutId: 'layout-gallery-loop',
    layoutName: 'Gallery Loop',
    layoutReason: 'Directional messaging needs stronger guided flow.',
    layoutElements: seedLayouts[3].elements,
    materialChoices: seedLayouts[3].elements.map((element) => ({
      elementId: element.id,
      elementName: element.name,
      materialId: 'material-03',
      materialName: 'Natural Oak',
      finish: 'Oiled',
      swatch: '#C9A05B'
    })),
    vendorAssignment: undefined,
    proofPhotos: [],
    notes: 'Focus on directional graphics and decluttering the entrance wall.',
    timeline: timeline('rq-2036', 'Vikrant Rana', 5)
  },
  {
    id: 'RQ-2031',
    storeId: 'store-04',
    storeName: 'Jubilee Hills',
    storeCode: 'HYD-031',
    city: 'Hyderabad',
    category: 'furniture',
    createdBy: 'customer-01',
    createdAt: timeOffset(10),
    updatedAt: timeOffset(8),
    submittedAt: timeOffset(8),
    status: 'installed',
    measurements: { unit: 'ft', wallHeight: 18, wallWidth: 9, floorDepth: 12 },
    photos: createPhotoSet('space', 'Compact', 3),
    recommendedLayoutIds: ['layout-open-concept', 'layout-atelier-grid'],
    layoutId: 'layout-open-concept',
    layoutName: 'Open Concept',
    layoutReason: 'Compact footprint benefits from a clean central island.',
    layoutElements: seedLayouts[2].elements,
    materialChoices: seedLayouts[2].elements.map((element) => ({
      elementId: element.id,
      elementName: element.name,
      materialId: 'material-01',
      materialName: 'Brushed Walnut',
      finish: 'Matte',
      swatch: '#7A5A43'
    })),
    vendorAssignment: {
      vendorId: 'vendor-01',
      vendorName: 'Asha Verma',
      teamName: 'Team Alpha',
      assignedAt: timeOffset(9)
    },
    proofPhotos: installationProofs,
    notes: 'Installed successfully with lighter material palette.',
    timeline: [
      ...timeline('rq-2031', 'Vikrant Rana', 8),
      {
        id: 'rq-2031-approved',
        type: 'approved',
        title: 'Approved',
        description: 'Approved for execution.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(8)
      },
      {
        id: 'rq-2031-assigned',
        type: 'assigned',
        title: 'Vendor assigned',
        description: 'Assigned to Team Alpha for execution.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(7)
      },
      {
        id: 'rq-2031-progress',
        type: 'progress',
        title: 'Execution started',
        description: 'Fixtures and seating installed on site.',
        actor: 'Asha Verma',
        createdAt: timeOffset(7)
      },
      {
        id: 'rq-2031-proof',
        type: 'proof_uploaded',
        title: 'Proof uploaded',
        description: 'Completion proof uploaded by vendor.',
        actor: 'Asha Verma',
        createdAt: timeOffset(6)
      },
      {
        id: 'rq-2031-installed',
        type: 'installed',
        title: 'Installed',
        description: 'Project marked as completed.',
        actor: 'Asha Verma',
        createdAt: timeOffset(5)
      }
    ]
  },
  {
    id: 'RQ-2028',
    storeId: 'store-03',
    storeName: 'Connaught Place',
    storeCode: 'DEL-076',
    city: 'New Delhi',
    category: 'fixture',
    createdBy: 'customer-01',
    createdAt: timeOffset(2, 6),
    updatedAt: timeOffset(1, 2),
    submittedAt: timeOffset(1, 2),
    status: 'assigned',
    measurements: { unit: 'ft', wallHeight: 28, wallWidth: 16, floorDepth: 22 },
    photos: createPhotoSet('space', 'Flagship', 4),
    recommendedLayoutIds: ['layout-atelier-grid', 'layout-perimeter-flow', 'layout-gallery-loop'],
    layoutId: 'layout-atelier-grid',
    layoutName: 'Atelier Grid',
    layoutReason: 'Large flagship floor supports denser display grids.',
    layoutElements: seedLayouts[0].elements,
    materialChoices: seedLayouts[0].elements.map((element) => ({
      elementId: element.id,
      elementName: element.name,
      materialId: 'material-01',
      materialName: 'Brushed Walnut',
      finish: 'Matte',
      swatch: '#7A5A43'
    })),
    vendorAssignment: {
      vendorId: 'vendor-01',
      vendorName: 'Asha Verma',
      teamName: 'Team Alpha',
      assignedAt: timeOffset(1, 3)
    },
    proofPhotos: [],
    notes: 'Coordinate install before weekend launch.',
    timeline: [
      ...timeline('rq-2028', 'Vikrant Rana', 1),
      {
        id: 'rq-2028-approved',
        type: 'approved',
        title: 'Approved',
        description: 'Approved and prioritized for execution.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(1, 5)
      },
      {
        id: 'rq-2028-assigned',
        type: 'assigned',
        title: 'Vendor assigned',
        description: 'Assigned to Team Alpha.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(1, 3)
      }
    ]
  },
  {
    id: 'RQ-2025',
    storeId: 'store-05',
    storeName: 'Koregaon Park',
    storeCode: 'PUN-015',
    city: 'Pune',
    category: 'fixture',
    createdBy: 'customer-01',
    createdAt: timeOffset(1, 8),
    updatedAt: timeOffset(0, 5),
    submittedAt: timeOffset(1, 7),
    status: 'in_progress',
    measurements: { unit: 'ft', wallHeight: 25, wallWidth: 12, floorDepth: 20 },
    photos: createPhotoSet('space', 'On Site', 4),
    recommendedLayoutIds: ['layout-atelier-grid', 'layout-open-concept'],
    layoutId: 'layout-atelier-grid',
    layoutName: 'Atelier Grid',
    layoutReason: 'Balanced display rhythm for standard-format setup.',
    layoutElements: seedLayouts[0].elements,
    materialChoices: seedLayouts[0].elements.map((element) => ({
      elementId: element.id,
      elementName: element.name,
      materialId: 'material-02',
      materialName: 'Powder-coated Steel',
      finish: 'Charcoal',
      swatch: '#3F424B'
    })),
    vendorAssignment: {
      vendorId: 'vendor-01',
      vendorName: 'Asha Verma',
      teamName: 'Team Alpha',
      assignedAt: timeOffset(0, 7)
    },
    proofPhotos: [],
    notes: 'Install underway. Customer requested same-day sign-off if possible.',
    timeline: [
      ...timeline('rq-2025', 'Vikrant Rana', 1),
      {
        id: 'rq-2025-approved',
        type: 'approved',
        title: 'Approved',
        description: 'Approved for immediate rollout.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(0, 9)
      },
      {
        id: 'rq-2025-assigned',
        type: 'assigned',
        title: 'Vendor assigned',
        description: 'Assigned to Team Alpha with priority handling.',
        actor: 'Meera Kapoor',
        createdAt: timeOffset(0, 7)
      },
      {
        id: 'rq-2025-progress',
        type: 'progress',
        title: 'Execution started',
        description: 'Vendor reached site and started installation.',
        actor: 'Asha Verma',
        createdAt: timeOffset(0, 5)
      }
    ]
  }
];

export function createSeedDatabase(): MockDatabase {
  return {
    users: seedUsers,
    stores: seedStores,
    vendors: seedVendors,
    layouts: seedLayouts,
    materials: seedMaterials,
    requests: seedRequests,
    notifications: seedNotifications
  };
}
