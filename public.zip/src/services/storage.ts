import type { MockDatabase, RequestDraft, User } from '@/types/models';

const DB_KEY = 'lumen-store-setup-db-v1';
const SESSION_KEY = 'lumen-store-setup-session-v1';
const DRAFT_KEY = 'lumen-store-setup-draft-v1';

function readJson<T>(key: string): T | null {
  if (typeof window === 'undefined') {
    return null;
  }

  const value = window.localStorage.getItem(key);
  return value ? (JSON.parse(value) as T) : null;
}

function writeJson<T>(key: string, value: T): void {
  if (typeof window === 'undefined') {
    return;
  }

  window.localStorage.setItem(key, JSON.stringify(value));
}

export function readDatabase(): MockDatabase | null {
  return readJson<MockDatabase>(DB_KEY);
}

export function writeDatabase(database: MockDatabase): void {
  writeJson(DB_KEY, database);
}

export function readSession(): User | null {
  return readJson<User>(SESSION_KEY);
}

export function writeSession(user: User | null): void {
  if (typeof window === 'undefined') {
    return;
  }

  if (!user) {
    window.localStorage.removeItem(SESSION_KEY);
    return;
  }

  writeJson(SESSION_KEY, user);
}

export function readDraft(): RequestDraft | null {
  return readJson<RequestDraft>(DRAFT_KEY);
}

export function writeDraft(draft: RequestDraft | null): void {
  if (typeof window === 'undefined') {
    return;
  }

  if (!draft) {
    window.localStorage.removeItem(DRAFT_KEY);
    return;
  }

  writeJson(DRAFT_KEY, draft);
}

