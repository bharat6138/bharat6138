import type { User } from '@/types/models';
import { createSeedDatabase } from '@/services/mockData';
import { readDatabase, readSession, writeDatabase, writeSession } from '@/services/storage';

function delay<T>(value: T): Promise<T> {
  return Promise.resolve(value);
}

export function ensureDatabase(): void {
  const existing = readDatabase();
  if (!existing) {
    writeDatabase(createSeedDatabase());
  }
}

export const authService = {
  async login(email: string, password: string): Promise<User> {
    ensureDatabase();
    const database = readDatabase();
    const user = database?.users.find(
      (candidate) => candidate.email.toLowerCase() === email.toLowerCase() && candidate.password === password
    );

    if (!user) {
      throw new Error('Invalid credentials. Try one of the seeded role accounts.');
    }

    writeSession(user);
    return delay(user);
  },

  async getSession(): Promise<User | null> {
    ensureDatabase();
    return delay(readSession());
  },

  async logout(): Promise<void> {
    writeSession(null);
    return delay(undefined);
  }
};

