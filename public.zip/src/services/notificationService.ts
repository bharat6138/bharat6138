import type { NotificationItem, UserRole } from '@/types/models';
import { ensureDatabase } from '@/services/authService';
import { readDatabase } from '@/services/storage';

function delay<T>(value: T): Promise<T> {
  return Promise.resolve(value);
}

export const notificationService = {
  async getForRole(role: UserRole): Promise<NotificationItem[]> {
    ensureDatabase();
    return delay(
      (readDatabase()?.notifications ?? []).filter(
        (notification) => notification.role === 'all' || notification.role === role
      )
    );
  }
};

