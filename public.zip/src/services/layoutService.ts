import { buildLayoutRecommendations } from '@/features/layouts/recommendationEngine';
import { storeService } from '@/services/storeService';
import { ensureDatabase } from '@/services/authService';
import { readDatabase } from '@/services/storage';
import type {
  LayoutRecommendation,
  MeasurementSet,
  RequestCategory
} from '@/types/models';

function delay<T>(value: T): Promise<T> {
  return Promise.resolve(value);
}

export const layoutService = {
  async getLayouts() {
    ensureDatabase();
    return delay(readDatabase()?.layouts ?? []);
  },

  async getRecommendations(input: {
    storeId: string;
    category: RequestCategory;
    measurements: MeasurementSet;
    photoCount: number;
  }): Promise<LayoutRecommendation[]> {
    ensureDatabase();
    const store = await storeService.getById(input.storeId);
    const database = readDatabase();

    if (!store || !database) {
      return [];
    }

    return delay(
      buildLayoutRecommendations({
        store,
        category: input.category,
        measurements: input.measurements,
        photoCount: input.photoCount,
        layouts: database.layouts
      })
    );
  }
};

