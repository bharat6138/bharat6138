import type { Store } from '@/types/models';
import { ensureDatabase } from '@/services/authService';
import { readDatabase } from '@/services/storage';

function delay<T>(value: T): Promise<T> {
  return Promise.resolve(value);
}

export const storeService = {
  async getAll(): Promise<Store[]> {
    ensureDatabase();
    return delay(readDatabase()?.stores ?? []);
  },

  async search(query: string): Promise<Store[]> {
    ensureDatabase();
    const stores = readDatabase()?.stores ?? [];
    const normalized = query.trim().toLowerCase();

    if (!normalized) {
      return delay(stores);
    }

    return delay(
      stores.filter((store) =>
        [store.name, store.city, store.code].some((field) => field.toLowerCase().includes(normalized))
      )
    );
  },

  async getById(id: string): Promise<Store | undefined> {
    ensureDatabase();
    return delay(readDatabase()?.stores.find((store) => store.id === id));
  }
};

