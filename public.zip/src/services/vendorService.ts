import type { Vendor } from '@/types/models';
import { ensureDatabase } from '@/services/authService';
import { readDatabase } from '@/services/storage';

function delay<T>(value: T): Promise<T> {
  return Promise.resolve(value);
}

export const vendorService = {
  async getAll(): Promise<Vendor[]> {
    ensureDatabase();
    return delay(readDatabase()?.vendors ?? []);
  },

  async getById(id: string): Promise<Vendor | undefined> {
    ensureDatabase();
    return delay(readDatabase()?.vendors.find((vendor) => vendor.id === id));
  }
};

