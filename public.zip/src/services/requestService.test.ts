import { ensureDatabase } from '@/services/authService';
import { requestService } from '@/services/requestService';
import { seedUsers } from '@/services/mockData';

describe('requestService.submitDraft', () => {
  it('creates and persists a submitted request', async () => {
    ensureDatabase();
    const before = await requestService.getAll();

    const created = await requestService.submitDraft(
      {
        step: 6,
        storeId: 'store-01',
        category: 'fixture',
        photos: [
          {
            id: 'photo-01',
            name: 'photo-01.png',
            dataUrl: 'data:image/png;base64,test',
            createdAt: new Date().toISOString(),
            kind: 'space'
          },
          {
            id: 'photo-02',
            name: 'photo-02.png',
            dataUrl: 'data:image/png;base64,test',
            createdAt: new Date().toISOString(),
            kind: 'space'
          },
          {
            id: 'photo-03',
            name: 'photo-03.png',
            dataUrl: 'data:image/png;base64,test',
            createdAt: new Date().toISOString(),
            kind: 'space'
          }
        ],
        measurements: {
          unit: 'ft',
          wallHeight: 31,
          wallWidth: 13,
          floorDepth: 23
        },
        recommendedLayoutIds: ['layout-atelier-grid', 'layout-perimeter-flow'],
        selectedLayoutId: 'layout-atelier-grid',
        materialChoices: [],
        notes: 'Test submission'
      },
      seedUsers[0]
    );

    const after = await requestService.getAll();

    expect(created.status).toBe('submitted');
    expect(after).toHaveLength(before.length + 1);
    expect(after.some((request) => request.id === created.id)).toBe(true);
  });
});

