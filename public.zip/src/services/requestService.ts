import { ensureDatabase } from '@/services/authService';
import { seedLayouts, seedMaterials } from '@/services/mockData';
import { readDatabase, writeDatabase } from '@/services/storage';
import { createId } from '@/utils/id';
import type {
  MaterialChoice,
  RequestDraft,
  RequestStatus,
  SetupRequest,
  UploadedPhoto,
  User,
  VendorAssignment
} from '@/types/models';

function delay<T>(value: T): Promise<T> {
  return Promise.resolve(value);
}

function appendTimelineEntry(
  request: SetupRequest,
  entry: SetupRequest['timeline'][number]
): SetupRequest {
  return {
    ...request,
    updatedAt: entry.createdAt,
    timeline: [...request.timeline, entry]
  };
}

function getMaterialChoiceFallbacks(layoutId: string): MaterialChoice[] {
  const layout = seedLayouts.find((candidate) => candidate.id === layoutId);
  const defaultMaterial = seedMaterials[0];

  return (
    layout?.elements.map((element) => ({
      elementId: element.id,
      elementName: element.name,
      materialId: defaultMaterial.id,
      materialName: defaultMaterial.name,
      finish: defaultMaterial.finish,
      swatch: defaultMaterial.swatch
    })) ?? []
  );
}

export const requestService = {
  async getAll(): Promise<SetupRequest[]> {
    ensureDatabase();
    const requests = readDatabase()?.requests ?? [];
    return delay([...requests].sort((left, right) => right.updatedAt.localeCompare(left.updatedAt)));
  },

  async getById(id: string): Promise<SetupRequest | undefined> {
    ensureDatabase();
    return delay(readDatabase()?.requests.find((request) => request.id === id));
  },

  async getForUser(user: User): Promise<SetupRequest[]> {
    const requests = await this.getAll();

    if (user.role === 'customer') {
      return requests.filter((request) => request.createdBy === user.id);
    }

    if (user.role === 'vendor') {
      return requests.filter((request) => request.vendorAssignment?.vendorId === user.id);
    }

    return requests;
  },

  async submitDraft(draft: RequestDraft, user: User): Promise<SetupRequest> {
    ensureDatabase();
    const database = readDatabase();

    if (!database || !draft.storeId || !draft.selectedLayoutId) {
      throw new Error('Draft is incomplete.');
    }

    const store = database.stores.find((candidate) => candidate.id === draft.storeId);
    const layout = database.layouts.find((candidate) => candidate.id === draft.selectedLayoutId);

    if (!store || !layout) {
      throw new Error('Selected store or layout could not be found.');
    }

    const now = new Date().toISOString();
    const nextId = `RQ-${2042 + database.requests.length}`;
    const request: SetupRequest = {
      id: nextId,
      storeId: store.id,
      storeName: store.name,
      storeCode: store.code,
      city: store.city,
      category: draft.category,
      createdBy: user.id,
      createdAt: now,
      updatedAt: now,
      submittedAt: now,
      status: 'submitted',
      measurements: draft.measurements,
      photos: draft.photos,
      recommendedLayoutIds: draft.recommendedLayoutIds,
      layoutId: layout.id,
      layoutName: layout.name,
      layoutReason: 'Selected from curated layout recommendations.',
      layoutElements: layout.elements,
      materialChoices:
        draft.materialChoices.length > 0 ? draft.materialChoices : getMaterialChoiceFallbacks(layout.id),
      vendorAssignment: undefined,
      proofPhotos: [],
      notes: draft.notes,
      timeline: [
        {
          id: createId('timeline'),
          type: 'created',
          title: 'Draft completed',
          description: 'Store measurements, photos, and layout selections were captured.',
          actor: user.name,
          createdAt: now
        },
        {
          id: createId('timeline'),
          type: 'submitted',
          title: 'Request submitted',
          description: 'Request entered the operations queue.',
          actor: user.name,
          createdAt: now
        }
      ]
    };

    writeDatabase({
      ...database,
      requests: [request, ...database.requests]
    });

    return delay(request);
  },

  async updateStatus(id: string, status: RequestStatus, actor: string, description: string): Promise<SetupRequest> {
    ensureDatabase();
    const database = readDatabase();

    if (!database) {
      throw new Error('Database unavailable.');
    }

    const request = database.requests.find((candidate) => candidate.id === id);

    if (!request) {
      throw new Error('Request not found.');
    }

    const now = new Date().toISOString();
    const type =
      status === 'in_review'
        ? 'review_started'
        : status === 'approved'
          ? 'approved'
          : status === 'rejected'
            ? 'rejected'
            : status === 'in_progress'
              ? 'progress'
              : status === 'installed'
                ? 'installed'
                : 'note';

    const updated = appendTimelineEntry(
      {
        ...request,
        status,
        updatedAt: now
      },
      {
        id: createId('timeline'),
        type,
        title: type === 'review_started' ? 'Review started' : status.replace('_', ' '),
        description,
        actor,
        createdAt: now
      }
    );

    writeDatabase({
      ...database,
      requests: database.requests.map((candidate) => (candidate.id === id ? updated : candidate))
    });

    return delay(updated);
  },

  async assignVendor(
    id: string,
    assignment: VendorAssignment,
    actor: string
  ): Promise<SetupRequest> {
    ensureDatabase();
    const database = readDatabase();

    if (!database) {
      throw new Error('Database unavailable.');
    }

    const request = database.requests.find((candidate) => candidate.id === id);

    if (!request) {
      throw new Error('Request not found.');
    }

    const now = new Date().toISOString();
    const updated = appendTimelineEntry(
      {
        ...request,
        status: 'assigned',
        vendorAssignment: assignment,
        updatedAt: now
      },
      {
        id: createId('timeline'),
        type: 'assigned',
        title: 'Vendor assigned',
        description: `${assignment.teamName} has been assigned to the request.`,
        actor,
        createdAt: now
      }
    );

    writeDatabase({
      ...database,
      requests: database.requests.map((candidate) => (candidate.id === id ? updated : candidate))
    });

    return delay(updated);
  },

  async uploadProof(id: string, photos: UploadedPhoto[], actor: string): Promise<SetupRequest> {
    ensureDatabase();
    const database = readDatabase();

    if (!database) {
      throw new Error('Database unavailable.');
    }

    const request = database.requests.find((candidate) => candidate.id === id);

    if (!request) {
      throw new Error('Request not found.');
    }

    const now = new Date().toISOString();
    const updated = appendTimelineEntry(
      {
        ...request,
        proofPhotos: [...request.proofPhotos, ...photos],
        updatedAt: now
      },
      {
        id: createId('timeline'),
        type: 'proof_uploaded',
        title: 'Proof uploaded',
        description: `${photos.length} proof photo(s) added.`,
        actor,
        createdAt: now
      }
    );

    writeDatabase({
      ...database,
      requests: database.requests.map((candidate) => (candidate.id === id ? updated : candidate))
    });

    return delay(updated);
  }
};

