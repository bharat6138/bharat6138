import { createTheme } from '@mui/material/styles';

export const appTheme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#141414'
    },
    secondary: {
      main: '#B8925A'
    },
    background: {
      default: '#F5F1EA',
      paper: '#FFFFFF'
    },
    text: {
      primary: '#141414',
      secondary: '#5E5A55'
    }
  },
  shape: {
    borderRadius: 28
  },
  typography: {
    fontFamily: '"Plus Jakarta Sans", "Segoe UI", sans-serif',
    h1: {
      fontSize: '2.4rem',
      fontWeight: 700,
      lineHeight: 1
    },
    h2: {
      fontSize: '1.9rem',
      fontWeight: 700
    },
    h3: {
      fontSize: '1.35rem',
      fontWeight: 700
    },
    button: {
      fontWeight: 700,
      textTransform: 'none'
    }
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        ':root': {
          colorScheme: 'light'
        },
        body: {
          margin: 0,
          background:
            'radial-gradient(circle at top left, rgba(184,146,90,0.22), transparent 26%), linear-gradient(180deg, #F7F4EF 0%, #F1ECE4 100%)'
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 28,
          boxShadow: '0 14px 34px rgba(20, 20, 20, 0.07)',
          border: '1px solid rgba(20,20,20,0.06)'
        }
      }
    },
    MuiButton: {
      defaultProps: {
        disableElevation: true
      },
      styleOverrides: {
        root: {
          borderRadius: 22,
          minHeight: 54,
          paddingInline: 22
        },
        containedPrimary: {
          background: '#141414',
          color: '#FFFFFF',
          '&:hover': {
            background: '#262626'
          }
        }
      }
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 999,
          fontWeight: 600
        }
      }
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: 24,
          backgroundColor: '#FFFFFF'
        }
      }
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 28
        }
      }
    }
  }
});

