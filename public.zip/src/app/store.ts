import { configureStore } from '@reduxjs/toolkit';
import authReducer from '@/features/auth/authSlice';
import requestsReducer from '@/features/requests/requestsSlice';
import wizardReducer from '@/features/wizard/wizardSlice';
import { writeDraft } from '@/services/storage';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    requests: requestsReducer,
    wizard: wizardReducer
  }
});

store.subscribe(() => {
  writeDraft(store.getState().wizard.draft);
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

