import { CssBaseline, ThemeProvider } from '@mui/material';
import { Provider } from 'react-redux';
import type { PropsWithChildren } from 'react';
import { store } from '@/app/store';
import { appTheme } from '@/theme/theme';

export function AppProviders({ children }: PropsWithChildren) {
  return (
    <Provider store={store}>
      <ThemeProvider theme={appTheme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </Provider>
  );
}

