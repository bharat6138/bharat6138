import { useEffect } from 'react';
import { BrowserRouter, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { AppShell } from '@/layouts/AppShell';
import { hydrateSession } from '@/features/auth/authSlice';
import { LoginPage } from '@/features/auth/LoginPage';
import { CustomerHomePage } from '@/features/customer/CustomerHomePage';
import { CustomerRequestsPage } from '@/features/customer/CustomerRequestsPage';
import { CustomerNewRequestPage } from '@/features/customer/CustomerNewRequestPage';
import { VendorHomePage } from '@/features/vendor/VendorHomePage';
import { VendorRequestsPage } from '@/features/vendor/VendorRequestsPage';
import { AdminHomePage } from '@/features/admin/AdminHomePage';
import { AdminRequestsPage } from '@/features/admin/AdminRequestsPage';
import { ProfilePage } from '@/features/profile/ProfilePage';
import { RequestDetailPage } from '@/features/requests/RequestDetailPage';
import type { UserRole } from '@/types/models';

function SessionBootstrap() {
  const dispatch = useAppDispatch();

  useEffect(() => {
    void dispatch(hydrateSession());
  }, [dispatch]);

  return null;
}

function AuthAwareLogin() {
  const user = useAppSelector((state) => state.auth.user);
  return user ? <Navigate to={`/${user.role}/home`} replace /> : <LoginPage />;
}

function ProtectedRoleLayout({ role }: { role: UserRole }) {
  const user = useAppSelector((state) => state.auth.user);
  const location = useLocation();

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (user.role !== role) {
    return <Navigate to={`/${user.role}/home`} replace />;
  }

  return (
    <AppShell role={role}>
      <Outlet />
    </AppShell>
  );
}

function DefaultRedirect() {
  const user = useAppSelector((state) => state.auth.user);
  return <Navigate to={user ? `/${user.role}/home` : '/login'} replace />;
}

export function AppRouter() {
  return (
    <BrowserRouter>
      <SessionBootstrap />
      <Routes>
        <Route path="/login" element={<AuthAwareLogin />} />

        <Route path="/customer" element={<ProtectedRoleLayout role="customer" />}>
          <Route index element={<Navigate to="home" replace />} />
          <Route path="home" element={<CustomerHomePage />} />
          <Route path="requests" element={<CustomerRequestsPage />} />
          <Route path="requests/:requestId" element={<RequestDetailPage />} />
          <Route path="new" element={<CustomerNewRequestPage />} />
          <Route path="profile" element={<ProfilePage />} />
        </Route>

        <Route path="/vendor" element={<ProtectedRoleLayout role="vendor" />}>
          <Route index element={<Navigate to="home" replace />} />
          <Route path="home" element={<VendorHomePage />} />
          <Route path="requests" element={<VendorRequestsPage />} />
          <Route path="requests/:requestId" element={<RequestDetailPage />} />
          <Route path="profile" element={<ProfilePage />} />
        </Route>

        <Route path="/admin" element={<ProtectedRoleLayout role="admin" />}>
          <Route index element={<Navigate to="home" replace />} />
          <Route path="home" element={<AdminHomePage />} />
          <Route path="requests" element={<AdminRequestsPage />} />
          <Route path="requests/:requestId" element={<RequestDetailPage />} />
          <Route path="profile" element={<ProfilePage />} />
        </Route>

        <Route path="*" element={<DefaultRedirect />} />
      </Routes>
    </BrowserRouter>
  );
}

