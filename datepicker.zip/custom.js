$(document).ready(function () {

  // Init datepickers
  const fromPicker = flatpickr("#fromDate", {
    dateFormat: "d M Y",
    defaultDate: new Date(),
    onChange: syncFromTo
  });

  const toPicker = flatpickr("#toDate", {
    dateFormat: "d M Y",
    defaultDate: new Date(),
    onChange: syncToFrom
  });

  // Generate 30-min interval times
  function generateTimeOptions(selectId) {
    let select = $(selectId);
    select.empty();

    for (let h = 0; h < 24; h++) {
      for (let m of [0, 30]) {
        let hour = h % 12 || 12;
        let ampm = h < 12 ? "AM" : "PM";
        let minute = m === 0 ? "00" : m;

        let value = `${("0" + h).slice(-2)}:${minute}`;
        let label = `${hour}:${minute} ${ampm}`;

        select.append(`<option value="${value}">${label}</option>`);
      }
    }
  }

  generateTimeOptions("#fromTime");
  generateTimeOptions("#toTime");

  // Helper: add minutes
  function addMinutes(time, mins) {
    let [h, m] = time.split(":").map(Number);
    let date = new Date();
    date.setHours(h, m);
    date.setMinutes(date.getMinutes() + mins);

    return formatTime(date);
  }

  function formatTime(date) {
    return ("0" + date.getHours()).slice(-2) + ":" +
           ("0" + date.getMinutes()).slice(-2);
  }

  function addHourToDate(dateStr, timeStr, mins) {
    let date = new Date(dateStr);
    let [h, m] = timeStr.split(":").map(Number);
    date.setHours(h, m);
    date.setMinutes(date.getMinutes() + mins);
    return date;
  }

  // 🔥 FROM → TO auto adjust
 function syncFromTo() {
  let fromDateObj = fromPicker.selectedDates[0];
  let fromTime = $("#fromTime").val();

  let toDateObj = toPicker.selectedDates[0];
  let toTime = $("#toTime").val();

  if (!fromDateObj || !fromTime) return;

  // Build FROM datetime
  let fromDateTime = new Date(fromDateObj);
  let [fh, fm] = fromTime.split(":").map(Number);
  fromDateTime.setHours(fh, fm);

  // Build TO datetime
  let toDateTime = null;
  if (toDateObj && toTime) {
    toDateTime = new Date(toDateObj);
    let [th, tm] = toTime.split(":").map(Number);
    toDateTime.setHours(th, tm);
  }

  // Default new TO = FROM + 1 hour
  let newTo = new Date(fromDateTime);
  newTo.setMinutes(newTo.getMinutes() + 60);

  // ✅ Only update if TO is missing or invalid
  if (!toDateTime || toDateTime < fromDateTime) {
    toPicker.setDate(newTo);
    $("#toTime").val(formatTime(newTo));
  }
}

//   // 🔥 TO → FROM reverse adjust
//   function syncToFrom() {
//     let toDate = $("#toDate").val();
//     let toTime = $("#toTime").val();

//     if (!toDate || !toTime) return;

//     let newDate = addHourToDate(toDate, toTime, -60);

//     fromPicker.setDate(newDate);
//     $("#fromTime").val(formatTime(newDate));
//   }


function syncToFrom() {
  let toDateObj = toPicker.selectedDates[0];
  let toTime = $("#toTime").val();

  let fromDateObj = fromPicker.selectedDates[0];
  let fromTime = $("#fromTime").val();

  if (!toDateObj || !toTime || !fromDateObj || !fromTime) return;

  // Create full datetime objects
  let toDateTime = new Date(toDateObj);
  let [th, tm] = toTime.split(":").map(Number);
  toDateTime.setHours(th, tm);

  let fromDateTime = new Date(fromDateObj);
  let [fh, fm] = fromTime.split(":").map(Number);
  fromDateTime.setHours(fh, fm);

  // Calculate new FROM = TO - 1 hour
  let newFrom = new Date(toDateTime);
  newFrom.setMinutes(newFrom.getMinutes() - 60);

  // ✅ ONLY update if valid
  if (newFrom <= toDateTime) {
    // Extra check: don't override if user already selected a valid earlier FROM
    if (fromDateTime > toDateTime || fromDateTime < newFrom) {
      fromPicker.setDate(newFrom);
      $("#fromTime").val(formatTime(newFrom));
    }
  }
}
  // Bind change events
  $("#fromTime").on("change", syncFromTo);
  $("#toTime").on("change", syncToFrom);

});