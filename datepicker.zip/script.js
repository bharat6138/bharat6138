$(document).ready(function () {

  // -----------------------
  // INIT DATE PICKERS
  // -----------------------
  const fromPicker = flatpickr("#fromDate", {
    dateFormat: "d M Y",
    defaultDate: new Date(),
    onChange: syncFromTo
  });

  const toPicker = flatpickr("#toDate", {
    dateFormat: "d M Y",
    defaultDate: new Date(),
    onChange: syncToFrom
  });

  // -----------------------
  // GENERATE TIME OPTIONS
  // -----------------------
  function generateTimeOptions(selectId) {
    let select = $(selectId);
    select.empty();

    for (let h = 0; h < 24; h++) {
      for (let m of [0, 30]) {
        let hour = h % 12 || 12;
        let ampm = h < 12 ? "AM" : "PM";
        let minute = m === 0 ? "00" : m;

        let value = `${("0" + h).slice(-2)}:${minute}`;
        let label = `${hour}:${minute} ${ampm}`;

        select.append(`<option value="${value}">${label}</option>`);
      }
    }
  }

  generateTimeOptions("#fromTime");
  generateTimeOptions("#toTime");

  // -----------------------
  // HELPERS
  // -----------------------
  function formatTime(date) {
    return ("0" + date.getHours()).slice(-2) + ":" +
           ("0" + date.getMinutes()).slice(-2);
  }

  function getRoundedTime(date = new Date()) {
    let mins = date.getMinutes();
    let rounded = mins < 15 ? 0 : mins < 45 ? 30 : 60;

    if (rounded === 60) {
      date.setHours(date.getHours() + 1);
      rounded = 0;
    }

    date.setMinutes(rounded);
    date.setSeconds(0);
    return date;
  }

  function buildDateTime(dateObj, timeStr) {
    let d = new Date(dateObj);
    let [h, m] = timeStr.split(":").map(Number);
    d.setHours(h, m, 0, 0);
    return d;
  }


// -----------------------
// FROM → TO (ALWAYS +1 HOUR)
// -----------------------
function syncFromTo() {
  let fromDateObj = fromPicker.selectedDates[0];
  let fromTime = $("#fromTime").val();

  if (!fromDateObj || !fromTime) return;

  let fromDT = buildDateTime(fromDateObj, fromTime);

  let newTo = new Date(fromDT);
  newTo.setMinutes(newTo.getMinutes() + 60);

  toPicker.setDate(newTo);
  $("#toTime").val(formatTime(newTo));
}

 // -----------------------
// TO → FROM (ALWAYS -1 HOUR)
// -----------------------
function syncToFrom() {
  let toDateObj = toPicker.selectedDates[0];
  let toTime = $("#toTime").val();

  if (!toDateObj || !toTime) return;

  let toDT = buildDateTime(toDateObj, toTime);

  let newFrom = new Date(toDT);
  newFrom.setMinutes(newFrom.getMinutes() - 60);

  fromPicker.setDate(newFrom);
  $("#fromTime").val(formatTime(newFrom));
}

  // -----------------------
  // BIND EVENTS
  // -----------------------
  $("#fromTime").on("change", syncFromTo);
  $("#toTime").on("change", syncToFrom);

  // -----------------------
  // DEFAULT INITIAL LOAD
  // -----------------------
  let now = getRoundedTime(new Date());

  let fromDT = new Date(now);
  let toDT = new Date(now);
  toDT.setMinutes(toDT.getMinutes() + 60);

  fromPicker.setDate(fromDT);
  toPicker.setDate(toDT);

  $("#fromTime").val(formatTime(fromDT));
  $("#toTime").val(formatTime(toDT));

});