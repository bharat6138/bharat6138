/* =====================================================
   HEALTH CHECK REPORT - JavaScript
   ===================================================== */

// Health Check Data
const healthCheckData = [
    { id: 1, service: 'API Gateway', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 08:15' },
    { id: 2, service: 'Web Server', cpu: 'pass', memory: 'pass', disk: 'warning', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 08:12' },
    { id: 3, service: 'Database Primary', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'warning', lastCheck: '07/19 08:10' },
    { id: 4, service: 'Cache Server', cpu: 'pass', memory: 'warning', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 08:08' },
    { id: 5, service: 'Load Balancer', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 08:05' },
    { id: 6, service: 'Storage Service', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'warning', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 08:03' },
    { id: 7, service: 'Email Service', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'warning', api: 'pass', security: 'pass', lastCheck: '07/19 08:00' },
    { id: 8, service: 'Authentication', cpu: 'warning', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 07:58' },
    { id: 9, service: 'Logging System', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 07:55' },
    { id: 10, service: 'Monitoring Agent', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 07:52' },
    { id: 11, service: 'Queue Service', cpu: 'pass', memory: 'pass', disk: 'warning', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 07:50' },
    { id: 12, service: 'Search Engine', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'warning', security: 'pass', lastCheck: '07/19 07:48' },
    { id: 13, service: 'CDN Service', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 07:45' },
    { id: 14, service: 'Backup Service', cpu: 'pass', memory: 'pass', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 07:42' },
    { id: 15, service: 'DNS Service', cpu: 'warning', memory: 'warning', disk: 'pass', network: 'pass', database: 'pass', api: 'pass', security: 'pass', lastCheck: '07/19 07:40' }
];

let dataTable;

// (activeFilters already declared at top)

// =====================================================
// Initialize on Document Ready
// =====================================================
$(document).ready(function() {
    initializeDataTable();
    initializeAccordion();
    attachEventListeners();
    populateTable();
});

// =====================================================
// DataTable Initialization
// =====================================================
function initializeDataTable() {
    // Custom filter function - ensure single active filter
    $.fn.dataTable.ext.search = [];
    $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
        // Try to get the original row object from the DataTable API first
        let row = null;
        try {
            if (window.dataTable && typeof window.dataTable.row === 'function') {
                row = window.dataTable.row(dataIndex).data();
            }
        } catch (e) {
            row = null;
        }

        // fallback to healthCheckData if needed
        if (!row) {
            row = healthCheckData[dataIndex];
        }

        if (!row) return true;

        // Service Name Filter
        if (activeFilters.service && !row.service.toLowerCase().includes(activeFilters.service)) {
            return false;
        }

        // CPU Filter
        if (activeFilters.cpu && row.cpu !== activeFilters.cpu) {
            return false;
        }

        // Memory Filter
        if (activeFilters.memory && row.memory !== activeFilters.memory) {
            return false;
        }

        // Disk Filter
        if (activeFilters.disk && row.disk !== activeFilters.disk) {
            return false;
        }

        // Network Filter
        if (activeFilters.network && row.network !== activeFilters.network) {
            return false;
        }

        // Database Filter
        if (activeFilters.database && row.database !== activeFilters.database) {
            return false;
        }

        // API Filter
        if (activeFilters.api && row.api !== activeFilters.api) {
            return false;
        }

        // Security Filter
        if (activeFilters.security && row.security !== activeFilters.security) {
            return false;
        }

        // Last Check Filter
        if (activeFilters.lastCheck && !row.lastCheck.toLowerCase().includes(activeFilters.lastCheck)) {
            return false;
        }

        return true;
    });
    
    dataTable = $('#healthTable').DataTable({
        pageLength: 10,
        ordering: true,
        searching: true,
        paging: true,
        info: true,
        responsive: true,
        language: {
            search: '_INPUT_',
            searchPlaceholder: 'Search services...',
            lengthMenu: 'Show _MENU_ records',
            info: 'Showing _START_ to _END_ of _TOTAL_ records',
            infoEmpty: 'No records found',
            paginate: {
                first: '<i class="bi bi-chevron-bar-left"></i>',
                last: '<i class="bi bi-chevron-bar-right"></i>',
                next: '<i class="bi bi-chevron-right"></i>',
                previous: '<i class="bi bi-chevron-left"></i>'
            }
        },
        dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
             '<"row"<"col-sm-12"tr>>' +
             '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
        columns: [
            { data: 'service' },
            { data: 'cpu', render: renderCheckIcon },
            { data: 'memory', render: renderCheckIcon },
            { data: 'disk', render: renderCheckIcon },
            { data: 'network', render: renderCheckIcon },
            { data: 'database', render: renderCheckIcon },
            { data: 'api', render: renderCheckIcon },
            { data: 'security', render: renderCheckIcon },
            { data: 'lastCheck' },
            { data: null, render: renderActions }
        ],
        createdRow: function(row, data, index) {
            $(row).addClass('health-row').attr('data-id', data.id);
        }
    });
    // Expose DataTable API globally for filter callback
    window.dataTable = dataTable;
}

// =====================================================
// Render Check Icons
// =====================================================
function renderCheckIcon(data, type, row) {
    if (data === 'pass') {
        return '<span class="check-icon pass" title="Healthy"><i class="bi bi-check-circle-fill"></i></span>';
    } else if (data === 'warning') {
        return '<span class="check-icon warning" title="Warning"><i class="bi bi-exclamation-triangle-fill"></i></span>';
    } else {
        return '<span class="check-icon fail" title="Failed"><i class="bi bi-x-circle-fill"></i></span>';
    }
}

// =====================================================
// Populate Table with Data
// =====================================================
function populateTable() {
    dataTable.clear();
    healthCheckData.forEach(item => {
        dataTable.row.add(item);
    });
    dataTable.draw();
}
function renderActions(data, type, row) {
    return `
        <div class="btn-group btn-group-sm" role="group">
            <button class="btn btn-sm btn-info" title="View Details" onclick="viewServiceDetails(${row.id})">
                <i class="bi bi-eye"></i>
            </button>
            <button class="btn btn-sm btn-warning" title="Run Check" onclick="runHealthCheck(${row.id})">
                <i class="bi bi-arrow-repeat"></i>
            </button>
        </div>
    `;
}

// =====================================================
// Event Listeners
// =====================================================
function attachEventListeners() {
    $('#tableTabNav').on('click', switchToTableView);
    $('#cardTabNav').on('click', switchToCardView);
    $('#tableSearch').on('keyup', function() {
        dataTable.search($(this).val()).draw();
    });
    $('#exportBtn').on('click', exportHealthReport);
    $('#refreshBtn').on('click', refreshHealthData);
    
    // Column Filter Event Listeners
    $('#filter-service').on('keyup', filterTable);
    $('#filter-cpu').on('change', filterTable);
    $('#filter-memory').on('change', filterTable);
    $('#filter-disk').on('change', filterTable);
    $('#filter-network').on('change', filterTable);
    $('#filter-database').on('change', filterTable);
    $('#filter-api').on('change', filterTable);
    $('#filter-security').on('change', filterTable);
    $('#filter-lastcheck').on('keyup', filterTable);
    
    // Clear Filters Button
    $('#clearFiltersBtn').on('click', clearAllFilters);
}

// Store filter values globally
let activeFilters = {
    service: '',
    cpu: '',
    memory: '',
    disk: '',
    network: '',
    database: '',
    api: '',
    security: '',
    lastCheck: ''
};

// =====================================================
// Column-wise Filter Function
// =====================================================
function filterTable() {
    // Update active filters
    activeFilters.service = $('#filter-service').val().toLowerCase();
    activeFilters.cpu = $('#filter-cpu').val();
    activeFilters.memory = $('#filter-memory').val();
    activeFilters.disk = $('#filter-disk').val();
    activeFilters.network = $('#filter-network').val();
    activeFilters.database = $('#filter-database').val();
    activeFilters.api = $('#filter-api').val();
    activeFilters.security = $('#filter-security').val();
    activeFilters.lastCheck = $('#filter-lastcheck').val().toLowerCase();
    
    dataTable.draw();
}

// =====================================================
// Clear All Filters
// =====================================================
function clearAllFilters() {
    // Clear all filter inputs
    $('#filter-service').val('');
    $('#filter-cpu').val('');
    $('#filter-memory').val('');
    $('#filter-disk').val('');
    $('#filter-network').val('');
    $('#filter-database').val('');
    $('#filter-api').val('');
    $('#filter-security').val('');
    $('#filter-lastcheck').val('');
    
    // Reset active filters
    activeFilters = {
        service: '',
        cpu: '',
        memory: '',
        disk: '',
        network: '',
        database: '',
        api: '',
        security: '',
        lastCheck: ''
    };
    
    // Reset DataTable search
    $('#tableSearch').val('');
    
    dataTable.search('').draw();
    
    showAlert('All filters cleared', 'info');
}

// =====================================================
// Service Actions
// =====================================================
function viewServiceDetails(id) {
    const service = healthCheckData.find(s => s.id === id);
    if (service) {
        const statusClass = (status) => {
            if (status === 'pass') return 'text-success';
            if (status === 'warning') return 'text-warning';
            return 'text-danger';
        };

        const modalBody = `
            <div class="health-details">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6 class="text-muted mb-2"><i class="bi bi-server"></i> Service Information</h6>
                        <p><strong>Service Name:</strong> ${service.service}</p>
                        <p><strong>Service ID:</strong> ${String(service.id).padStart(2, '0')}</p>
                        <p><strong>Last Check:</strong> <span class="badge bg-info">${service.lastCheck}</span></p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted mb-2"><i class="bi bi-gear"></i> Configuration</h6>
                        <p><strong>Status Page:</strong> <a href="#" class="text-decoration-none">View Status</a></p>
                        <p><strong>Metrics:</strong> <a href="#" class="text-decoration-none">View Metrics</a></p>
                        <p><strong>Logs:</strong> <a href="#" class="text-decoration-none">View Logs</a></p>
                    </div>
                </div>
                <hr>
                <h6 class="text-muted mb-3"><i class="bi bi-heart-pulse"></i> Health Status Details</h6>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="health-badge ${statusClass(service.cpu)}">
                            <i class="bi bi-cpu"></i> CPU: <strong>${service.cpu.toUpperCase()}</strong>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="health-badge ${statusClass(service.memory)}">
                            <i class="bi bi-memory"></i> Memory: <strong>${service.memory.toUpperCase()}</strong>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="health-badge ${statusClass(service.disk)}">
                            <i class="bi bi-hdd"></i> Disk: <strong>${service.disk.toUpperCase()}</strong>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="health-badge ${statusClass(service.network)}">
                            <i class="bi bi-wifi"></i> Network: <strong>${service.network.toUpperCase()}</strong>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="health-badge ${statusClass(service.database)}">
                            <i class="bi bi-database"></i> Database: <strong>${service.database.toUpperCase()}</strong>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="health-badge ${statusClass(service.api)}">
                            <i class="bi bi-arrow-left-right"></i> API: <strong>${service.api.toUpperCase()}</strong>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="health-badge ${statusClass(service.security)}">
                            <i class="bi bi-shield"></i> Security: <strong>${service.security.toUpperCase()}</strong>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#modalBody').html(modalBody);
        const modal = new bootstrap.Modal(document.getElementById('detailModal'));
        modal.show();
    }
}

function runHealthCheck(id) {
    const service = healthCheckData.find(s => s.id === id);
    if (service) {
        showAlert(`Running health check for ${service.service}...`, 'info');
        
        // Simulate health check
        setTimeout(() => {
            showAlert(`Health check completed for ${service.service}`, 'success');
        }, 2000);
    }
}

// =====================================================
// Tab Switching
// =====================================================
function switchToTableView(e) {
    e.preventDefault();
    $('#tableView').show();
    $('#cardView').hide();
    $('#tableTabNav').addClass('active').parent().siblings().find('a').removeClass('active');
}

function switchToCardView(e) {
    e.preventDefault();
    $('#tableView').hide();
    $('#cardView').show();
    $('#cardTabNav').addClass('active').parent().siblings().find('a').removeClass('active');
}

// =====================================================
// Accordion Generation
// =====================================================
function initializeAccordion() {
    generateAccordion();
}

function generateAccordion() {
    const container = $('#accordionContainer');
    container.empty();
    
    healthCheckData.forEach((item, index) => {
        const accordionItem = createAccordionItem(item, index);
        container.append(accordionItem);
    });
}

function createAccordionItem(data, index) {
    const getStatusClass = (status) => {
        if (status === 'pass') return 'text-success';
        if (status === 'warning') return 'text-warning';
        return 'text-danger';
    };

    const getStatusIcon = (status) => {
        if (status === 'pass') return '<i class="bi bi-check-circle-fill"></i>';
        if (status === 'warning') return '<i class="bi bi-exclamation-triangle-fill"></i>';
        return '<i class="bi bi-x-circle-fill"></i>';
    };

    return `
        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" 
                        data-bs-target="#collapse${index}">
                    <span class="badge bg-primary me-3">${String(data.id).padStart(2, '0')}</span>
                    <strong>${data.service}</strong>
                </button>
            </h2>
            <div id="collapse${index}" class="accordion-collapse collapse" data-bs-parent="#accordionContainer">
                <div class="accordion-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="health-check-item mb-3">
                                <label class="fw-bold text-muted d-block mb-2">
                                    ${getStatusIcon(data.cpu)} CPU Check
                                </label>
                                <p class="${getStatusClass(data.cpu)}">${data.cpu.toUpperCase()}</p>
                            </div>
                            <div class="health-check-item mb-3">
                                <label class="fw-bold text-muted d-block mb-2">
                                    ${getStatusIcon(data.memory)} Memory Check
                                </label>
                                <p class="${getStatusClass(data.memory)}">${data.memory.toUpperCase()}</p>
                            </div>
                            <div class="health-check-item mb-3">
                                <label class="fw-bold text-muted d-block mb-2">
                                    ${getStatusIcon(data.disk)} Disk Check
                                </label>
                                <p class="${getStatusClass(data.disk)}">${data.disk.toUpperCase()}</p>
                            </div>
                            <div class="health-check-item">
                                <label class="fw-bold text-muted d-block mb-2">
                                    ${getStatusIcon(data.network)} Network Check
                                </label>
                                <p class="${getStatusClass(data.network)}">${data.network.toUpperCase()}</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="health-check-item mb-3">
                                <label class="fw-bold text-muted d-block mb-2">
                                    ${getStatusIcon(data.database)} Database Check
                                </label>
                                <p class="${getStatusClass(data.database)}">${data.database.toUpperCase()}</p>
                            </div>
                            <div class="health-check-item mb-3">
                                <label class="fw-bold text-muted d-block mb-2">
                                    ${getStatusIcon(data.api)} API Status
                                </label>
                                <p class="${getStatusClass(data.api)}">${data.api.toUpperCase()}</p>
                            </div>
                            <div class="health-check-item mb-3">
                                <label class="fw-bold text-muted d-block mb-2">
                                    ${getStatusIcon(data.security)} Security Scan
                                </label>
                                <p class="${getStatusClass(data.security)}">${data.security.toUpperCase()}</p>
                            </div>
                            <div class="health-check-item">
                                <label class="fw-bold text-muted d-block mb-2">
                                    <i class="bi bi-clock"></i> Last Check
                                </label>
                                <p class="text-secondary">${data.lastCheck}</p>
                            </div>
                        </div>
                    </div>
                    <div class="border-top pt-3 mt-3">
                        <button class="btn btn-sm btn-primary" onclick="viewServiceDetails(${data.id})">
                            <i class="bi bi-eye"></i> View Details
                        </button>
                        <button class="btn btn-sm btn-warning ms-2" onclick="runHealthCheck(${data.id})">
                            <i class="bi bi-arrow-repeat"></i> Run Check
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// =====================================================
// Export Functionality
// =====================================================
function exportHealthReport() {
    let csv = 'Service Name,CPU,Memory,Disk,Network,Database,API,Security,Last Check\n';
    healthCheckData.forEach(row => {
        csv += `"${row.service}","${row.cpu}","${row.memory}","${row.disk}","${row.network}","${row.database}","${row.api}","${row.security}","${row.lastCheck}"\n`;
    });

    const link = document.createElement('a');
    link.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    link.download = `health_check_report_${new Date().getTime()}.csv`;
    link.click();

    showAlert('Health report exported successfully', 'success');
}

function refreshHealthData() {
    showAlert('Refreshing health data...', 'info');
    
    setTimeout(() => {
        populateTable();
        generateAccordion();
        showAlert('Health data refreshed', 'success');
    }, 1500);
}

// =====================================================
// Alert Helper
// =====================================================
function showAlert(message, type = 'info') {
    const alertDiv = $(`
        <div class="alert alert-${type} alert-dismissible fade show position-fixed" 
             role="alert" style="top: 80px; right: 20px; min-width: 350px; z-index: 1050;">
            ${getAlertIcon(type)} ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);

    $('body').append(alertDiv);

    setTimeout(() => {
        alertDiv.alert('close');
    }, 4000);
}

function getAlertIcon(type) {
    const icons = {
        'info': '<i class="bi bi-info-circle"></i>',
        'success': '<i class="bi bi-check-circle"></i>',
        'warning': '<i class="bi bi-exclamation-circle"></i>',
        'danger': '<i class="bi bi-exclamation-triangle"></i>'
    };
    return icons[type] || icons['info'];
}

// Initialize on load
console.log('Health Check Report initialized with ' + healthCheckData.length + ' services');
