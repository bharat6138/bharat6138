export type Severity = 'critical' | 'warning' | 'info' | 'passed';
export interface Finding { severity: Severity; category: string; title: string; detail: string; url?: string; recommendation: string }
export interface PageResult { url: string; title: string; status: number | null; loadMs: number; linksFound: number; consoleErrors: string[] }
export interface ScanReport { target: string; startedAt: string; finishedAt: string; durationMs: number; score: number; summary: { pages: number; passed: number; warnings: number; critical: number }; findings: Finding[]; pages: PageResult[]; limitations: string[] }
