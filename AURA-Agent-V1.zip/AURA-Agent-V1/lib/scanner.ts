import { chromium, type Browser } from 'playwright';
import type { Finding, PageResult, ScanReport } from './types';

const MAX_PAGES = 15;
const TIMEOUT = 20000;
export function normalizeTarget(input: string) {
  const value = input.trim();
  const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Only HTTP and HTTPS URLs are supported.');
  url.hash = '';
  return url;
}
export async function scanApplication(input: string): Promise<ScanReport> {
  const target = normalizeTarget(input); const started = Date.now(); const findings: Finding[] = []; const pages: PageResult[] = [];
  let browser: Browser | undefined;
  try {
    browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({ ignoreHTTPSErrors: false, userAgent: 'AURA-Agent-V1/1.0' });
    const queue = [target.href]; const seen = new Set<string>();
    while (queue.length && pages.length < MAX_PAGES) {
      const url = queue.shift()!; if (seen.has(url)) continue; seen.add(url);
      const page = await context.newPage(); const consoleErrors: string[] = [];
      page.on('console', m => { if (m.type() === 'error' && consoleErrors.length < 10) consoleErrors.push(m.text()); });
      const began = Date.now(); let status: number | null = null; let title = ''; let links: string[] = [];
      try {
        const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: TIMEOUT }); status = response?.status() ?? null;
        title = await page.title();
        links = await page.locator('a[href]').evaluateAll((els) => els.map(a => (a as HTMLAnchorElement).href));
        const h1 = await page.locator('h1').count(); const description = await page.locator('meta[name="description"]').getAttribute('content');
        const imagesMissingAlt = await page.locator('img:not([alt]), img[alt=""]').count();
        if (!title.trim()) findings.push(f('warning','SEO','Missing page title',`No title was found on ${url}.`,url,'Add a concise, unique document title.'));
        if (!description?.trim()) findings.push(f('info','SEO','Missing meta description',`No meta description was found on ${url}.`,url,'Add a useful summary for search and link previews.'));
        if (h1 === 0) findings.push(f('warning','Structure','Missing H1',`The page has no primary heading.`,url,'Add one clear H1 describing the page.'));
        if (imagesMissingAlt) findings.push(f('warning','Accessibility','Images missing alt text',`${imagesMissingAlt} image(s) have no useful alt attribute.`,url,'Add meaningful alt text; use empty alt only for decorative images.'));
        if ((status ?? 0) >= 400) findings.push(f('critical','Availability',`HTTP ${status}`,`The page returned an error status.`,url,'Fix the route or redirect users to a working page.'));
        const loadMs = Date.now() - began; if (loadMs > 4000) findings.push(f('warning','Performance','Slow initial load',`DOM content loaded in ${(loadMs/1000).toFixed(1)} seconds.`,url,'Profile server response and critical resources.'));
        if (consoleErrors.length) findings.push(f('warning','Runtime','Browser console errors',`${consoleErrors.length} console error(s) appeared while loading.`,url,'Review the page details and resolve runtime errors.'));
        pages.push({ url, title: title || '(untitled)', status, loadMs, linksFound: links.length, consoleErrors });
        for (const raw of links) { try { const link = new URL(raw); link.hash=''; if (link.origin === target.origin && !seen.has(link.href) && queue.length < MAX_PAGES * 3) queue.push(link.href); } catch {} }
      } catch (error) {
        findings.push(f('critical','Availability','Page could not be loaded',error instanceof Error ? error.message : 'Unknown navigation error',url,'Confirm the URL, network access, TLS certificate, and server availability.'));
        pages.push({ url, title: '(unavailable)', status, loadMs: Date.now()-began, linksFound: 0, consoleErrors });
      } finally { await page.close(); }
    }
    await context.close();
  } finally { await browser?.close(); }
  const critical = findings.filter(x=>x.severity==='critical').length, warnings = findings.filter(x=>x.severity==='warning').length;
  const score = Math.max(0, Math.min(100, 100 - critical*20 - warnings*6 - findings.filter(x=>x.severity==='info').length*2));
  if (!findings.length) findings.push(f('passed','Overview','No common issues detected','AURA completed its V1 checks without identifying an issue.',target.href,'Continue deeper functional, security, and accessibility testing.'));
  const finished=Date.now(); return { target:target.href, startedAt:new Date(started).toISOString(), finishedAt:new Date(finished).toISOString(), durationMs:finished-started, score, summary:{pages:pages.length, passed:Math.max(0,pages.length-critical-warnings),warnings,critical}, findings, pages, limitations:['V1 inspects public pages reachable without authentication.','Results are heuristic and do not replace security, accessibility, load, or compliance audits.','Client-rendered links are followed only when present after DOMContentLoaded.'] };
}
function f(severity: Finding['severity'],category:string,title:string,detail:string,url:string,recommendation:string):Finding { return {severity,category,title,detail,url,recommendation}; }
