# AURA Agent V1

Application Unified Runtime Analyzer — **Intelligent Application Health Inspector**.

See [PROJECT_GUIDE.md](PROJECT_GUIDE.md) for architecture, setup, packaging, limitations, and demo instructions.
