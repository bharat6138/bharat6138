# Global AI Agents Pack

This folder is designed to be copied directly as `.agents/` into the location used by your AI coding setup.

## Structure

- `agents/` — specialist agent definitions
- `skills/` — reusable skills; each skill contains `SKILL.md`
- `workflows/` — orchestration flows for project initialization, page/component building, package integration, review, and context sync
- `templates/` — templates used to create a local `.project-ai/` knowledge layer in each project
- `PRE_PROMPT.md` — persistent pre-prompt for automatic build/update mode and manual review/audit mode

## First use in an existing project

Tell the AI:

`Initialize this existing project using .agents/workflows/initialize-project.md and create/update .project-ai without changing product code.`

## Build a new page

You can keep the request short:

`Create Employee Performance page from the attached Excel. Use the existing project UI/UX, theme, components and interaction patterns. Decide the layout and suitable controls from the data.`

## Manual page review

`Review the User Management page against the rest of the project. Fix UI/UX, theme consistency, component reuse, responsiveness, states and accessibility issues without changing business behavior.`

The PRE_PROMPT contains the detailed rules for both modes.
