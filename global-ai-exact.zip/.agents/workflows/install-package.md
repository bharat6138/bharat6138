# Workflow: Dependency Integration

Capability gap → Existing component search → Installed package search → Native/framework option → Package evaluation → Install → Wrapper/adaptation → Theme/state/accessibility integration → Test → Registries update.
