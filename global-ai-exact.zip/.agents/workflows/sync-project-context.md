# Workflow: Sync Project Context

Review changed files and update only durable project knowledge.

Do not mutate global agents/skills just because one project changed.
