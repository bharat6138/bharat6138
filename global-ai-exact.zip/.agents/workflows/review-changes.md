# Workflow: Manual Page Review

Target page → Project context → Closest good references → UI/UX/theme/component/dependency/accessibility/code audit → Fix allowed issues → Review → Test → Context sync.
