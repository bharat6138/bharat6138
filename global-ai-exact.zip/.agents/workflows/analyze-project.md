# Workflow: Analyze Project

1. Read package/config files.
2. Map architecture.
3. Map routes/pages/layouts.
4. Identify reusable UI.
5. Identify theme and visual tokens.
6. Identify interactions.
7. Identify dependencies and wrappers.
8. Identify API/state conventions.
9. Record concise project knowledge in `.project-ai/`.
