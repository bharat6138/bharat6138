# Workflow: Build Page

Requirement → Manager → Project Analyzer → Reference-page selection → Frontend implementation → Dependency evaluation if needed → Theme adaptation → Reviewer → Tester → Project context sync.
