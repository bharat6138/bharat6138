# Workflow: Initialize Project

Use this workflow the first time the global AI system is used in an existing repository.

1. Inspect the repository root, package manifests, source folders, routing, theme files, shared components, state/API conventions, test setup, and build configuration.
2. Determine framework, language, versions, styling system, theme mechanism, component libraries, icon libraries, chart libraries, form libraries, table libraries, animation libraries, state management, and testing tools.
3. Identify representative pages: dashboard, listing/table, form/create-edit, detail, analytics, settings/admin, and any visually mature pages.
4. Create `.project-ai/` from the templates in `.agents/templates/` when it does not exist.
5. Populate project context, architecture, design system, theme, component registry, dependency registry, page patterns, interaction patterns, and initial decisions.
6. Do not change product code during initialization unless the user explicitly asks for fixes.
7. Mark the context as current after analysis.
