# Workflow: Build Component

Requirement → Manager → Project Analyzer → Component registry check → Existing dependency check → Build or integrate → Theme adaptation → Accessibility → Reviewer → Tester → Context sync.

Rules:
- Prefer an existing component or variant before creating another abstraction.
- If new behavior is generic and reusable, create a shared project component.
- If a third-party library is needed, integrate it behind a project-owned wrapper when practical.
- Match the current theme, visual language, responsive behavior, states, and interaction patterns.
- Register reusable new components and dependencies in `.project-ai/`.
