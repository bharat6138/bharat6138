---
name: api-skill
description: Integrates frontend/backend APIs using the project's current client, auth, error, loading, caching, typing, and data transformation conventions.
---

# API Skill
- Reuse the current API client.
- Preserve base URL and environment handling.
- Preserve auth/token conventions.
- Follow existing error response handling.
- Follow current query/cache/state library.
- Keep request/response transformation consistent.
- Do not invent mock contracts when real project contracts exist.
