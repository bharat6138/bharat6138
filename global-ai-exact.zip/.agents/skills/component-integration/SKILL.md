---
name: component-integration-skill
description: Integrates a genuinely new component into project architecture, theme, APIs, accessibility, and reuse conventions.
---

# Component Integration Skill
When a new reusable component is justified:
1. Pick correct project location.
2. Define a clean API consistent with existing components.
3. Integrate theme and modes.
4. Cover states and accessibility.
5. Avoid leaking third-party implementation details where possible.
6. Add examples/tests where project convention supports them.
7. Register it in `.project-ai/component-registry.md`.
