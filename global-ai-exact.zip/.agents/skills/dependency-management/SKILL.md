---
name: dependency-management-skill
description: Prevents dependency sprawl and guides safe package selection, installation, and lifecycle decisions.
---

# Dependency Management Skill
Before adding:
- search installed dependencies
- search existing wrappers
- compare native/project options
- verify compatibility
- avoid overlapping libraries
- prefer actively maintained, appropriately licensed, accessible solutions

After adding:
- integrate through project conventions
- record purpose and wrapper path
- remove unused experimentation
