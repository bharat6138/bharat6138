---
name: react-skill
description: Project-aware React implementation guidance for components, hooks, state, rendering, reuse, and maintainability.
---

# React Skill
- Follow the React version and conventions already in the project.
- Do not convert JS to TS or vice versa without requirement.
- Prefer existing components/hooks/utilities.
- Keep state close to where it is needed.
- Avoid unnecessary effects and derived-state duplication.
- Preserve routing/state/form libraries already selected by the project.
- Prevent needless re-renders where real impact exists.
- Keep page components composable and readable.
