---
name: code-review-skill
description: Reviews changes for correctness, consistency, reuse, maintainability, architecture, and unintended regressions.
---

# Code Review Skill
Review requirement completeness, architectural consistency, unnecessary duplication, component reuse, hardcoding, edge cases, error handling, readability, dead code, risky package additions, and unnecessary complexity.
