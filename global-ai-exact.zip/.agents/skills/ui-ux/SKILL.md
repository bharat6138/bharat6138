---
name: ui-ux-skill
description: Infers page hierarchy, controls, interactions, and UX states from requirements while preserving the current product's established UI language.
---

# UI/UX Skill
For new pages:
- find comparable existing pages
- preserve visual hierarchy and interaction grammar
- infer suitable controls from data semantics
- prioritize clarity and task completion
- include loading, empty, error, validation, and disabled states
- keep navigation and action placement consistent
- do not redesign globally to make one new page look fashionable

For review:
- identify inconsistency before proposing novelty
- fix hierarchy, density, spacing, alignment, feedback, and interaction issues
