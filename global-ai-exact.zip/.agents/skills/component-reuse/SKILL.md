---
name: component-reuse-skill
description: Finds and reuses existing project components and patterns before creating new equivalents.
---

# Component Reuse Skill
Search before creating.

Check shared/common components, feature-level reusable components, design-system/primitives, hooks/utilities, and existing wrappers around third-party packages.

If an existing component satisfies most needs, extend it safely instead of cloning it.
Do not over-generalize a one-off component prematurely.
