---
name: security-skill
description: Applies project-appropriate secure coding checks to frontend, APIs, dependencies, auth, data exposure, and untrusted input handling.
---

# Security Skill
Check secrets, auth/permission assumptions, untrusted input, unsafe HTML/eval patterns, sensitive data exposure, dependency additions, and API validation/authorization boundaries.
