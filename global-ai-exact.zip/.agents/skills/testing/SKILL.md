---
name: testing-skill
description: Uses the current project's test tools to validate UI and application behavior without introducing unnecessary test infrastructure.
---

# Testing Skill
Prioritize changed behavior, critical user interactions, validation, theme/responsive regressions, accessibility basics, and error/empty/loading states.

Use existing unit/component/e2e tooling first.
