---
name: theme-awareness-skill
description: Detects and respects the project's current theme system, tokens, modes, typography, spacing, color semantics, radii, and shadows.
---

# Theme Awareness Skill
Detect CSS variables, theme provider, Tailwind/design token configuration, component variants, dark/light mode mechanism, semantic colors, typography, spacing/radius/shadow conventions.

Never bypass these with arbitrary hardcoded styling.
