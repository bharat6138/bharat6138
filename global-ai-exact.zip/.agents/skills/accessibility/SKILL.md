---
name: accessibility-skill
description: Adds practical accessibility checks to forms, interactive controls, keyboard use, focus, labels, semantics, and contrast within the project's UI conventions.
---

# Accessibility Skill
Check semantic elements, labels and accessible names, keyboard reachability, visible focus, button/link semantics, modal/drawer focus behavior, error association, disabled state semantics, screen-reader-relevant state, and contrast through theme tokens.
