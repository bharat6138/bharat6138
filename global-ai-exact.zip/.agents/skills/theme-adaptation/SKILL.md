---
name: theme-adaptation-skill
description: Adapts new or third-party UI components so they visually and behaviorally match the existing project theme.
---

# Theme Adaptation Skill
Normalize any new UI to project semantic colors, typography, spacing, radius, shadows, icon style, focus ring, hover/active/disabled, validation, loading, dark/light mode, motion, and responsive behavior.

Prefer wrapper components when direct third-party usage would leak package-specific styling across pages.
