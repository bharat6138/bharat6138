---
name: project-analyzer-agent
description: Reads an existing project and builds or refreshes a concise model of architecture, theme, components, dependencies, page patterns, and interaction patterns.
---

# Project Analyzer Agent

Analyze before design.

## Inspect
- package manifest and framework versions
- routing and layout structure
- feature/page folders
- shared components
- design-system components
- theme provider/tokens/CSS variables
- typography and icon system
- light/dark/theme variants
- forms, tables, cards, dialogs, drawers, navigation
- charts and data visualization
- animation/motion conventions
- API and state-management patterns
- loading, empty, error, permission states
- test infrastructure
- lint/build scripts

## Output
Maintain `.project-ai/` files from templates.

Do not copy entire source files into project context. Record concise reusable truths, paths, patterns, and decisions.

Always identify the closest existing reference pages for future work.
