# Durable Project Decisions

Record only decisions worth remembering.

## Decision
- Date:
- Context:
- Chosen approach:
- Why:
- Applies to:
