# Theme Context

## Theme Engine
-

## Modes
-

## Tokens / Variables
-

## Semantic Colors
-

## Typography
-

## Radius / Shadow
-

## Theme Rules
- Never hardcode a replacement visual language.
- New third-party components must be normalized to this theme.
