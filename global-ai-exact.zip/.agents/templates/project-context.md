# Project Context

## Product / Project
- Name:
- Purpose:

## Framework
- Frontend:
- Backend:
- Language:
- Build tool:

## Key Paths
- App entry:
- Routes:
- Pages:
- Shared components:
- Theme:
- API:
- State:

## Core Commands
- Install:
- Dev:
- Build:
- Test:
- Lint:

## Important Constraints
-
