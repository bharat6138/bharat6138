# Component Registry

For each reusable component record:

## Component Name
- Path:
- Purpose:
- Main props/capabilities:
- Used by:
- Theme behavior:
- Reuse rule:
