# Architecture Context

## Folder Architecture
-

## Routing / Layout
-

## State Management
-

## API Layer
-

## Forms
-

## Error Handling
-

## Testing
-

## Naming / File Conventions
-
