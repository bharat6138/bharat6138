# Page Patterns

For each important page family record:

## Pattern Name
- Reference pages:
- Header:
- Actions:
- Filters:
- Cards:
- Main content:
- Editing pattern:
- Responsive behavior:
- Notes:
