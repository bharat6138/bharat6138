# Interaction Patterns

## Create
-

## Edit
-

## Delete / Confirmation
-

## Filters
-

## Search
-

## Table actions
-

## Drawer / Dialog
-

## Notifications
-

## Loading / Empty / Error
-

## Motion
-
