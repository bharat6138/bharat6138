# Dependency Registry

For each important dependency record:

## Package
- Version:
- Purpose:
- Wrapper/component paths:
- Where used:
- Why retained:
- Do not duplicate with:
